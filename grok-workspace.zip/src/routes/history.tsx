import { createFileRoute } from "@tanstack/react-router";
import { Inbox } from "lucide-react";
import { NumberOrb } from "@/components/number-orb";
import { SignalCard } from "@/components/signal-card";
import { useLiveTable } from "@/hooks/use-live-table";
import { formatRelativeTime, numberColor } from "@/lib/roulette";

export const Route = createFileRoute("/history")({ component: HistoryPage });

function HistoryPage() {
  const { spins, signals, source } = useLiveTable();
  const colorLabel = (number: number) => {
    const tone = numberColor(number);
    if (tone === "green") return "Verde";
    if (tone === "red") return "Vermelho";
    return "Preto";
  };

  return (
    <div className="flex flex-col gap-5">
      <div>
        <p className="text-[10px] font-semibold tracking-[0.16em] text-subtle uppercase">Dados da mesa</p>
        <h1 className="font-display mt-1 text-2xl font-semibold tracking-tight">Histórico</h1>
      </div>

      <section className="grid grid-cols-3 gap-3 rounded-[var(--radius-xl)] border border-border bg-surface p-4">
        <div>
          <p className="text-[10px] font-semibold tracking-[0.1em] text-subtle uppercase">Capturado</p>
          <p className="mt-1 font-display text-2xl font-semibold tabular">{spins.length}</p>
        </div>
        <div>
          <p className="text-[10px] font-semibold tracking-[0.1em] text-subtle uppercase">Sinais</p>
          <p className="mt-1 font-display text-2xl font-semibold text-teal tabular">{signals.length}</p>
        </div>
        <div>
          <p className="text-[10px] font-semibold tracking-[0.1em] text-subtle uppercase">Status</p>
          <p className="mt-2 text-sm font-medium">{source.status === "online" ? "Online" : source.status === "connecting" ? "Conectando" : "Indisponível"}</p>
        </div>
      </section>

      <p className="text-xs leading-5 text-muted">
        {source.origin} · {source.message}
      </p>

      <section className="flex flex-col gap-3">
        <h2 className="font-display text-lg font-semibold">Sinais recentes</h2>
        {signals.length === 0 ? (
          <p className="rounded-[var(--radius-lg)] border border-border bg-surface px-4 py-5 text-sm text-muted">
            Nenhum sinal gerado nesta sessão da mesa.
          </p>
        ) : (
          signals.map((signal) => <SignalCard key={signal.id} signal={signal} compact />)
        )}
      </section>

      <section className="flex flex-col gap-2">
        <h2 className="font-display text-lg font-semibold">Giros recentes</h2>
        {spins.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-12 text-center">
            <Inbox className="size-7 text-muted" />
            <p className="font-medium">Nenhum giro capturado</p>
            <p className="max-w-xs text-sm text-muted">Os resultados aparecem aqui assim que a mesa for monitorada.</p>
          </div>
        ) : (
          <ul className="divide-y divide-border rounded-[var(--radius-xl)] border border-border bg-surface">
            {spins.slice(0, 80).map((spin) => (
              <li key={spin.id} className="flex min-h-[68px] items-center gap-3 px-3">
                <NumberOrb number={spin.number} />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Resultado {spin.number}</p>
                  <p className="text-xs text-muted">
                    {formatRelativeTime(spin.createdAt)} · {colorLabel(spin.number)}
                    {spin.multiplier ? ` · x${spin.multiplier}` : ""}
                  </p>
                </div>
                {spin.totalWinners ? (
                  <span className="text-[11px] text-subtle tabular">{spin.totalWinners} ganhadores</span>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
