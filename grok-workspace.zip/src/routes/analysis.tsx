import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, Cell, ResponsiveContainer, XAxis, YAxis } from "recharts";
import { NumberOrb } from "@/components/number-orb";
import { RouletteWheel } from "@/components/roulette-wheel";
import { WindowPills } from "@/components/window-pills";
import { useLiveTable } from "@/hooks/use-live-table";
import { computeWindowStats, type AnalysisWindow } from "@/lib/roulette";
import { useRoletaStore } from "@/lib/store";

export const Route = createFileRoute("/analysis")({ component: AnalysisPage });

function Meter({
  label,
  value,
  total,
  tone,
}: {
  label: string;
  value: number;
  total: number;
  tone: "red" | "black" | "green" | "teal" | "blue" | "coral";
}) {
  const pct = total === 0 ? 0 : Math.round((value / total) * 100);
  const fill = {
    red: "bg-pocket-red",
    black: "bg-muted",
    green: "bg-pocket-green",
    teal: "bg-accent",
    blue: "bg-blue",
    coral: "bg-coral",
  }[tone];
  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between text-xs">
        <span className="text-muted">{label}</span>
        <span className="font-medium tabular">
          {value} · {pct}%
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-surface-2">
        <div className={`h-full rounded-full ${fill}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function AnalysisPage() {
  const { spins, currentSignal, analysisWindow } = useLiveTable();
  const setAnalysisWindow = useRoletaStore((state) => state.setAnalysisWindow);
  const stats = computeWindowStats(spins, analysisWindow);
  const last = spins[0]?.number;
  const chartData = stats.terminals.map((item) => ({
    name: `T${item.terminal}`,
    count: item.count,
  }));

  return (
    <div className="flex flex-col gap-5">
      <div>
        <p className="text-[10px] font-semibold tracking-[0.16em] text-subtle uppercase">Distribuição</p>
        <h1 className="font-display mt-1 text-2xl font-semibold tracking-tight">Análise</h1>
      </div>

      <WindowPills value={analysisWindow} onChange={(value: AnalysisWindow) => setAnalysisWindow(value)} />

      <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-4">
        <RouletteWheel lastNumber={last} targets={currentSignal?.targets ?? []} />
        <p className="mt-3 text-center text-xs text-subtle">
          Contorno teal = último giro. Contorno coral = alvos do sinal ativo.
        </p>
      </section>

      <section className="grid gap-3 sm:grid-cols-2">
        <article className="rounded-[var(--radius-xl)] border border-border bg-surface p-4">
          <h2 className="text-sm font-semibold">Cor e paridade</h2>
          <div className="mt-4 flex flex-col gap-3">
            <Meter label="Vermelho" value={stats.red} total={stats.total} tone="red" />
            <Meter label="Preto" value={stats.black} total={stats.total} tone="black" />
            <Meter label="Zero" value={stats.green} total={stats.total} tone="green" />
            <Meter label="Par" value={stats.even} total={stats.total} tone="teal" />
            <Meter label="Ímpar" value={stats.odd} total={stats.total} tone="blue" />
          </div>
        </article>
        <article className="rounded-[var(--radius-xl)] border border-border bg-surface p-4">
          <h2 className="text-sm font-semibold">Dúzias e colunas</h2>
          <div className="mt-4 flex flex-col gap-3">
            <Meter label="Dúzia 1" value={stats.dozens[0]} total={stats.total} tone="teal" />
            <Meter label="Dúzia 2" value={stats.dozens[1]} total={stats.total} tone="blue" />
            <Meter label="Dúzia 3" value={stats.dozens[2]} total={stats.total} tone="coral" />
            <Meter label="Coluna 1" value={stats.columns[0]} total={stats.total} tone="teal" />
            <Meter label="Coluna 2" value={stats.columns[1]} total={stats.total} tone="blue" />
            <Meter label="Coluna 3" value={stats.columns[2]} total={stats.total} tone="coral" />
          </div>
        </article>
      </section>

      <section className="grid gap-3 sm:grid-cols-2">
        <article className="rounded-[var(--radius-xl)] border border-border bg-surface p-4">
          <h2 className="text-sm font-semibold">Quentes</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {stats.hot.length === 0 ? (
              <p className="text-sm text-muted">Sem amostra ainda.</p>
            ) : (
              stats.hot.map((item) => (
                <div key={item.number} className="flex flex-col items-center gap-1">
                  <NumberOrb number={item.number} size="sm" />
                  <span className="text-[10px] text-subtle tabular">{item.count}x</span>
                </div>
              ))
            )}
          </div>
        </article>
        <article className="rounded-[var(--radius-xl)] border border-border bg-surface p-4">
          <h2 className="text-sm font-semibold">Frios</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {stats.cold.length === 0 ? (
              <p className="text-sm text-muted">Sem amostra ainda.</p>
            ) : (
              stats.cold.map((item) => (
                <div key={item.number} className="flex flex-col items-center gap-1">
                  <NumberOrb number={item.number} size="sm" dim={item.count === 0} />
                  <span className="text-[10px] text-subtle tabular">{item.count}x</span>
                </div>
              ))
            )}
          </div>
        </article>
      </section>

      <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-4">
        <h2 className="text-sm font-semibold">Terminais</h2>
        <div className="mt-3 h-40">
          {stats.total === 0 ? (
            <p className="py-10 text-center text-sm text-muted">Aguardando giros para montar o gráfico.</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} barCategoryGap={8}>
                <XAxis dataKey="name" tick={{ fill: "#91A29F", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {chartData.map((entry) => (
                    <Cell key={entry.name} fill="#90D6CA" />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </section>
    </div>
  );
}
