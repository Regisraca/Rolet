import { createFileRoute } from "@tanstack/react-router";
import { Crosshair, Shield } from "lucide-react";
import { FilterPanel } from "@/components/filter-panel";
import { Switch } from "@/components/ui/switch";
import { Panel } from "@/components/ui/panel";
import { useLiveTable } from "@/hooks/use-live-table";
import { APP_VERSION, DISCLAIMER } from "@/lib/config/app";
import { TABLES } from "@/lib/config/tables";
import { playwrightUnsupportedReason } from "@/lib/coleta/playwright";
import { connectorLabel } from "@/lib/analise/roulette";
import { useRoletaStore } from "@/lib/state/store";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const { source, tableId, runtime } = useLiveTable();
  const settings = useRoletaStore((state) => state.settings);
  const toggleSetting = useRoletaStore((state) => state.toggleSetting);
  const table = TABLES[tableId];

  return (
    <div className="flex flex-col gap-5">
      <div>
        <p className="text-micro text-subtle">Controle do monitor</p>
        <h1 className="font-display mt-1 text-2xl font-semibold tracking-tight">Ajustes</h1>
      </div>

      <section className="flex items-center gap-3 rounded-[var(--radius-xl)] bg-surface-2 p-4">
        <div className="flex size-12 items-center justify-center rounded-[16px] bg-ember text-primary-fg">
          <Crosshair className="size-5" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="font-display text-lg font-semibold">{table.label}</p>
          <p className="text-sm text-accent">{table.providerLabel} · {connectorLabel(runtime.status)}</p>
        </div>
      </section>

      <Panel className="px-4 py-0">
        <label className="flex min-h-[78px] items-center gap-3">
          <div className="min-w-0 flex-1 py-4">
            <p className="text-sm font-medium">Alertas sonoros</p>
            <p className="mt-1 text-xs text-muted">Toca um tom curto quando um sinal novo aparece.</p>
          </div>
          <Switch checked={settings.sound} onCheckedChange={() => toggleSetting("sound")} />
        </label>
      </Panel>

      <FilterPanel />

      <Panel className="px-4 py-2">
        <Row label="Versão" value={APP_VERSION} />
        <Row label="Fonte de dados" value={source.origin} />
        <Row label="Mesa" value={source.table} />
        <Row label="Provedor" value={table.providerLabel} />
        <Row label="Estado" value={source.message} />
      </Panel>

      <Panel>
        <div className="flex items-start gap-3">
          <Shield className="mt-0.5 size-4 text-warn" />
          <div className="text-sm leading-6 text-muted">
            <p className="font-medium text-fg">Responsabilidade e coleta</p>
            <p className="mt-1">{table.description}</p>
            <p className="mt-2">{DISCLAIMER}</p>
            <p className="mt-2">{playwrightUnsupportedReason()}</p>
          </div>
        </div>
      </Panel>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex min-h-12 items-center justify-between gap-4">
      <span className="text-sm text-muted">{label}</span>
      <span className="max-w-[60%] text-right text-sm font-medium">{value}</span>
    </div>
  );
}
