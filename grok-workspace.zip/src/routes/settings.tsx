import { createFileRoute } from "@tanstack/react-router";
import { Crosshair, Shield } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { useLiveTable } from "@/hooks/use-live-table";
import { TABLES } from "@/lib/tables";
import { useRoletaStore } from "@/lib/store";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const { source, tableId } = useLiveTable();
  const settings = useRoletaStore((state) => state.settings);
  const toggleSetting = useRoletaStore((state) => state.toggleSetting);
  const table = TABLES[tableId];
  const statusLabel = source.status === "online" ? "Online" : source.status === "connecting" ? "Conectando" : "Indisponível";

  return (
    <div className="flex flex-col gap-5">
      <div>
        <p className="text-[10px] font-semibold tracking-[0.16em] text-subtle uppercase">Controle do monitor</p>
        <h1 className="font-display mt-1 text-2xl font-semibold tracking-tight">Ajustes</h1>
      </div>

      <section className="flex items-center gap-3 rounded-[var(--radius-xl)] bg-surface-2 p-4">
        <div className="flex size-12 items-center justify-center rounded-[16px] bg-coral text-primary-fg">
          <Crosshair className="size-5" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="font-display text-lg font-semibold">{table.label}</p>
          <p className="text-sm text-accent">{table.providerLabel} · sessão ativa</p>
        </div>
        <span className="rounded-full bg-surface px-2.5 py-1 text-[10px] font-semibold tracking-[0.1em] uppercase">
          {statusLabel}
        </span>
      </section>

      <section className="rounded-[var(--radius-xl)] border border-border bg-surface px-4">
        <label className="flex min-h-[78px] items-center gap-3 border-b border-border">
          <div className="min-w-0 flex-1 py-4">
            <p className="text-sm font-medium">Atualização automática</p>
            <p className="mt-1 text-xs text-muted">Consulta a mesa a cada 2,5 segundos.</p>
          </div>
          <Switch checked={settings.autoRefresh} onCheckedChange={() => toggleSetting("autoRefresh")} />
        </label>
        <label className="flex min-h-[78px] items-center gap-3">
          <div className="min-w-0 flex-1 py-4">
            <p className="text-sm font-medium">Alertas sonoros</p>
            <p className="mt-1 text-xs text-muted">Toca um tom curto quando um sinal novo aparece.</p>
          </div>
          <Switch checked={settings.sound} onCheckedChange={() => toggleSetting("sound")} />
        </label>
      </section>

      <section className="rounded-[var(--radius-xl)] border border-border bg-surface px-4 py-2">
        <Row label="Versão" value="1.1.0" />
        <Row label="Fonte de dados" value={source.origin} />
        <Row label="Mesa" value={source.table} />
        <Row label="Provedor" value={table.providerLabel} />
        <Row label="Estado" value={source.message} />
      </section>

      <section className="rounded-[var(--radius-xl)] border border-border px-4 py-4">
        <div className="flex items-start gap-3">
          <Shield className="mt-0.5 size-4 text-warn" />
          <div className="text-sm leading-6 text-muted">
            <p className="font-medium text-fg">Sobre responsabilidade e dados</p>
            <p className="mt-1">
              {table.description} Os números vêm da API pública da CasinoScores. O app organiza leituras
              estatísticas da mesa. Nenhuma análise garante resultados futuros e o app não executa apostas.
              Na próxima versão você poderá fixar uma única casa.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex min-h-12 items-center justify-between gap-4">
      <span className="text-sm text-muted">{label}</span>
      <span className="max-w-[60%] text-right text-sm font-medium">{value}</span>
    </div>
  );
}
