import { createFileRoute, Link } from "@tanstack/react-router";
import { Info, PauseCircle, Radio } from "lucide-react";
import { HistoryStrip } from "@/components/history-strip";
import { NumberOrb } from "@/components/number-orb";
import { RouletteWheel } from "@/components/roulette-wheel";
import { SignalCard } from "@/components/signal-card";
import { StatusStrip } from "@/components/status-strip";
import { StrategyBoard } from "@/components/strategy-board";
import { TableControls } from "@/components/table-controls";
import { WindowPills } from "@/components/window-pills";
import { Panel } from "@/components/ui/panel";
import { useLiveTable } from "@/hooks/use-live-table";
import { DISCLAIMER, type AnalysisWindow } from "@/lib/config/app";
import { colorLabel, formatRelativeTime, isRed } from "@/lib/analise/roulette";
import { useRoletaStore } from "@/lib/state/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { spins, source, currentSignal, analysisWindow, runtime, engineSnapshot } = useLiveTable();
  const setAnalysisWindow = useRoletaStore((state) => state.setAnalysisWindow);
  const lastSpin = spins[0];
  const connected =
    runtime.status === "connected" || runtime.status === "capturing" || runtime.status === "paused";
  const missing = engineSnapshot ? Math.max(0, engineSnapshot.requiredSpins - engineSnapshot.availableSpins) : 0;

  let emptyTitle = "Sem sinal";
  let emptyCopy = connected
    ? "Observando. Score ou consenso abaixo do limiar — nenhum sinal inventado."
    : "Conecte a mesa e inicie a varredura para avaliar o motor.";
  if (engineSnapshot?.insufficient) {
    emptyTitle = "DADOS INSUFICIENTES";
    emptyCopy = `O motor precisa de ${engineSnapshot.requiredSpins} giros. Há ${engineSnapshot.availableSpins}. Faltam ${missing}.`;
  } else if (engineSnapshot?.phase === "CONFIRMACAO") {
    emptyTitle = "Confirmação";
    emptyCopy = "O padrão passou no filtro e aguarda persistir no próximo giro antes de virar sinal ativo.";
  } else if (engineSnapshot?.phase === "CANDIDATO") {
    emptyTitle = "Candidato";
    emptyCopy = "Há candidatos, mas o filtro de qualidade (score / consenso) ainda não liberou o sinal.";
  }

  return (
    <div className="flex flex-col gap-5">
      {runtime.status === "error" ? (
        <div className="flex gap-3 rounded-[var(--radius-lg)] border border-danger/40 bg-danger/8 px-4 py-3">
          <Radio className="mt-0.5 size-4 text-danger" />
          <div>
            <p className="text-sm font-semibold text-danger">Falha na conexão</p>
            <p className="mt-1 text-sm text-muted">{source.message}</p>
          </div>
        </div>
      ) : null}

      <StatusStrip />
      <TableControls />
      <WindowPills value={analysisWindow} onChange={(value: AnalysisWindow) => setAnalysisWindow(value)} />

      <Panel className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-micro text-subtle">Último resultado</p>
            <p className="mt-1 text-sm text-muted">
              {lastSpin ? formatRelativeTime(lastSpin.createdAt) : "aguardando conexão"}
            </p>
          </div>
          {lastSpin?.multiplier ? (
            <span className="rounded-full bg-ember/15 px-2.5 py-1 text-micro text-ember">
              x{lastSpin.multiplier}
            </span>
          ) : null}
        </div>

        <div className="mt-5 flex items-center gap-4">
          {lastSpin ? (
            <NumberOrb number={lastSpin.number} size="xl" />
          ) : (
            <div className="flex h-20 w-20 items-center justify-center rounded-[24px] bg-surface-2">
              <Radio className="size-7 text-muted" />
            </div>
          )}
          <div className="min-w-0">
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              {lastSpin ? `Número ${lastSpin.number}` : "Mesa desconectada"}
            </h2>
            <p className="mt-1 text-sm text-muted">
              {lastSpin
                ? `${colorLabel(lastSpin.number)} · ${lastSpin.parity} · ${lastSpin.highLow === "zero" ? "zero" : lastSpin.highLow} · T${lastSpin.terminal}`
                : "Conecte a mesa para capturar giros reais. Nada é inventado aqui."}
            </p>
            {lastSpin?.luckyNumbers.length ? (
              <p className="mt-2 text-xs text-subtle">
                Sortudos {lastSpin.luckyNumbers.map((item) => item.number).join(" · ")}
              </p>
            ) : null}
          </div>
        </div>

        <div className="mt-5 flex flex-wrap items-end justify-between gap-4 border-t border-border pt-4">
          <div>
            <p className="text-micro text-subtle">Giros lidos</p>
            <p className="mt-1 font-display text-xl font-semibold tabular">{spins.length}</p>
          </div>
          <div>
            <p className="text-micro text-subtle">Vermelhos / {analysisWindow}</p>
            <p className="mt-1 font-display text-xl font-semibold tabular">
              {spins.slice(0, analysisWindow).filter((spin) => isRed(spin.number)).length}
            </p>
          </div>
        </div>
      </Panel>

      {engineSnapshot ? <StrategyBoard snapshot={engineSnapshot} /> : null}

      <section className="flex flex-col gap-3">
        <div className="flex items-baseline justify-between">
          <h2 className="font-display text-xl font-semibold tracking-tight">Sinal atual</h2>
          <Link to="/history" className="text-sm text-accent hover:opacity-80">
            Ver histórico
          </Link>
        </div>
        {currentSignal ? (
          <SignalCard signal={currentSignal} />
        ) : (
          <div className="flex min-h-[92px] items-center gap-3 rounded-[var(--radius-xl)] border border-border bg-surface px-4 py-4">
            <div className="flex size-11 items-center justify-center rounded-[14px] bg-surface-2">
              <PauseCircle className="size-5 text-muted" />
            </div>
            <div>
              <p className="text-sm font-semibold tracking-wide uppercase">{emptyTitle}</p>
              <p className="mt-1 text-sm text-muted">{emptyCopy}</p>
            </div>
          </div>
        )}
      </section>

      <Panel>
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="font-display text-lg font-semibold">Últimos giros</h2>
          <Link to="/history" className="text-sm text-accent hover:opacity-80">
            Abrir lista
          </Link>
        </div>
        <HistoryStrip spins={spins} />
      </Panel>

      <details className="rounded-[var(--radius-xl)] border border-border bg-surface p-4">
        <summary className="cursor-pointer font-display text-lg font-semibold">Roda europeia</summary>
        <div className="mt-4">
          <RouletteWheel lastNumber={lastSpin?.number} targets={currentSignal?.targets ?? []} />
          <p className="mt-3 text-center text-xs text-subtle">
            Contorno pedra = último giro. Contorno ember = alvos do sinal ativo.
          </p>
        </div>
      </details>

      <p className="flex gap-2 text-xs leading-5 text-subtle">
        <Info className="mt-0.5 size-3.5 shrink-0 text-warn" />
        {DISCLAIMER}
      </p>
    </div>
  );
}
