import { createFileRoute, Link } from "@tanstack/react-router";
import { Info, PauseCircle, Radio, RefreshCw } from "lucide-react";
import { NumberOrb } from "@/components/number-orb";
import { SignalCard } from "@/components/signal-card";
import { Button } from "@/components/ui/button";
import { WindowPills } from "@/components/window-pills";
import { useLiveTable } from "@/hooks/use-live-table";
import { formatRelativeTime, isRed, type AnalysisWindow } from "@/lib/roulette";
import { useRoletaStore } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { spins, source, currentSignal, analysisWindow, isFetching, refresh } = useLiveTable();
  const setAnalysisWindow = useRoletaStore((state) => state.setAnalysisWindow);
  const lastSpin = spins[0];
  const recent = spins.slice(0, 10);
  const windowSpins = spins.slice(0, analysisWindow);
  const redCount = windowSpins.filter((spin) => isRed(spin.number)).length;

  return (
    <div className="flex flex-col gap-5">
      {source.status === "error" || source.status === "unavailable" ? (
        <div className="flex gap-3 rounded-[var(--radius-lg)] border border-danger/40 bg-danger/8 px-4 py-3">
          <Radio className="mt-0.5 size-4 text-danger" />
          <div>
            <p className="text-sm font-semibold text-danger">Fonte de resultados indisponível</p>
            <p className="mt-1 text-sm text-muted">{source.message}</p>
          </div>
        </div>
      ) : null}

      <WindowPills value={analysisWindow} onChange={(value: AnalysisWindow) => setAnalysisWindow(value)} />

      <section className="rounded-[var(--radius-xl)] border border-border bg-surface p-5 shadow-panel">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-[10px] font-semibold tracking-[0.16em] text-subtle uppercase">Último resultado</p>
            <p className="mt-1 text-sm text-muted">{lastSpin ? formatRelativeTime(lastSpin.createdAt) : "aguardando fonte"}</p>
          </div>
          {lastSpin?.multiplier ? (
            <span className="rounded-full bg-coral/15 px-2.5 py-1 text-[10px] font-semibold tracking-[0.12em] text-coral uppercase">
              x{lastSpin.multiplier}
            </span>
          ) : null}
        </div>

        <div className="mt-5 flex items-center gap-4">
          {lastSpin ? (
            <NumberOrb number={lastSpin.number} size="xl" />
          ) : (
            <div className="flex h-[88px] w-[88px] items-center justify-center rounded-[28px] bg-surface-2">
              <Radio className="size-7 text-muted" />
            </div>
          )}
          <div className="min-w-0">
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              {lastSpin ? `Número ${lastSpin.number}` : "Aguardando resultado"}
            </h2>
            <p className="mt-1 text-sm text-muted">
              {lastSpin
                ? lastSpin.number === 0
                  ? "Zero · verde"
                  : `${isRed(lastSpin.number) ? "Vermelho" : "Preto"} · ${lastSpin.number % 2 === 0 ? "par" : "ímpar"}`
                : "O próximo giro autorizado aparece aqui."}
            </p>
            {lastSpin?.luckyNumbers.length ? (
              <p className="mt-2 text-xs text-subtle">
                Sortudos {lastSpin.luckyNumbers.map((item) => item.number).join(" · ")}
              </p>
            ) : null}
            <p className="mt-2 text-xs font-medium text-accent">{source.status === "online" ? "Leitura atualizada" : source.message}</p>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap items-end justify-between gap-4 border-t border-border pt-4">
          <div>
            <p className="text-[10px] font-semibold tracking-[0.12em] text-subtle uppercase">Giros lidos</p>
            <p className="mt-1 font-display text-xl font-semibold tabular">{spins.length}</p>
          </div>
          <div>
            <p className="text-[10px] font-semibold tracking-[0.12em] text-subtle uppercase">Vermelhos / {analysisWindow}</p>
            <p className="mt-1 font-display text-xl font-semibold tabular">{redCount}</p>
          </div>
          <Button size="sm" onClick={() => void refresh()} disabled={isFetching} className="ml-auto">
            <RefreshCw className={isFetching ? "size-3.5 animate-spin" : "size-3.5"} />
            Atualizar
          </Button>
        </div>
      </section>

      <section className="flex flex-col gap-3">
        <div className="flex items-baseline justify-between">
          <h2 className="font-display text-xl font-semibold tracking-tight">Sinal em foco</h2>
          <Link to="/history" className="text-sm text-accent hover:opacity-80">
            Ver histórico
          </Link>
        </div>
        {currentSignal ? (
          <SignalCard signal={currentSignal} />
        ) : (
          <div className="flex min-h-[92px] items-center gap-3 rounded-[var(--radius-xl)] border border-border bg-surface px-4 py-4">
            <div className="flex size-11 items-center justify-center rounded-[14px] bg-surface-2">
              <PauseCircle className="size-5 text-muted" />
            </div>
            <div>
              <p className="text-sm font-semibold tracking-[0.08em] uppercase">Sem sinal</p>
              <p className="mt-1 text-sm text-muted">Condições insuficientes. Aguardando nova sequência.</p>
            </div>
          </div>
        )}
      </section>

      <section className="flex flex-col gap-3">
        <div className="flex items-baseline justify-between">
          <h2 className="font-display text-xl font-semibold tracking-tight">Últimos giros</h2>
          <Link to="/history" className="text-sm text-accent hover:opacity-80">
            Abrir lista
          </Link>
        </div>
        <div className="rounded-[var(--radius-xl)] border border-border bg-surface p-4">
          {recent.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted">Os resultados aparecem assim que a mesa responder.</p>
          ) : (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {recent.map((spin) => (
                <div key={spin.id} className="flex min-w-12 flex-col items-center gap-1.5">
                  <NumberOrb number={spin.number} />
                  <span className="text-[10px] text-subtle">{formatRelativeTime(spin.createdAt)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <p className="flex gap-2 text-xs leading-5 text-subtle">
        <Info className="mt-0.5 size-3.5 shrink-0 text-warn" />
        Análises estatísticas não garantem resultados. Use o app apenas para leitura de dados. Jogue com responsabilidade.
      </p>
    </div>
  );
}
