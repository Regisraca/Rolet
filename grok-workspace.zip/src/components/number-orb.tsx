import { cn } from "@/lib/utils";
import { numberColor, type PocketColor } from "@/lib/roulette";

const toneClass: Record<PocketColor, string> = {
  green: "bg-pocket-green text-fg",
  red: "bg-pocket-red text-fg",
  black: "bg-pocket-black text-fg ring-1 ring-border-strong",
};

export function NumberOrb({
  number,
  size = "md",
  dim = false,
  active = false,
  className,
}: {
  number: number;
  size?: "sm" | "md" | "lg" | "xl";
  dim?: boolean;
  active?: boolean;
  className?: string;
}) {
  const tone = numberColor(number);
  return (
    <span
      className={cn(
        "inline-flex items-center justify-center font-display font-semibold tabular leading-none",
        toneClass[tone],
        size === "sm" && "size-8 rounded-[10px] text-xs",
        size === "md" && "size-10 rounded-[12px] text-sm",
        size === "lg" && "size-14 rounded-[16px] text-xl",
        size === "xl" && "h-[88px] w-[88px] rounded-[28px] text-4xl tracking-tight",
        dim && "opacity-40",
        active && "ring-2 ring-accent",
        className,
      )}
    >
      {number}
    </span>
  );
}
