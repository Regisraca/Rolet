import type { AnalysisWindow } from "@/lib/roulette";
import { cn } from "@/lib/utils";

const WINDOWS: AnalysisWindow[] = [20, 50, 100];

export function WindowPills({
  value,
  onChange,
}: {
  value: AnalysisWindow;
  onChange: (value: AnalysisWindow) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <p className="text-[10px] font-semibold tracking-[0.14em] text-subtle uppercase">Janela de análise</p>
      <div className="flex gap-1 rounded-[var(--radius-md)] bg-surface-2 p-1">
        {WINDOWS.map((window) => (
          <button
            key={window}
            type="button"
            onClick={() => onChange(window)}
            className={cn(
              "min-h-9 min-w-11 rounded-[8px] px-2.5 text-xs font-semibold tabular transition-colors",
              value === window ? "bg-surface text-fg" : "text-muted hover:text-fg",
            )}
          >
            {window}
          </button>
        ))}
      </div>
    </div>
  );
}
