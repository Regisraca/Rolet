import { WHEEL_ORDER, numberColor } from "@/lib/roulette";
import { cn } from "@/lib/utils";

const FILL: Record<string, string> = {
  green: "#1F8A5B",
  red: "#C4453C",
  black: "#1A2221",
};

export function RouletteWheel({
  lastNumber,
  targets = [],
  className,
}: {
  lastNumber?: number;
  targets?: number[];
  className?: string;
}) {
  const size = 280;
  const cx = size / 2;
  const cy = size / 2;
  const outer = 132;
  const inner = 78;
  const count = WHEEL_ORDER.length;
  const targetSet = new Set(targets);

  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      className={cn("mx-auto size-full max-w-[280px]", className)}
      role="img"
      aria-label="Roda europeia"
    >
      <circle cx={cx} cy={cy} r={outer + 6} fill="#0e1413" stroke="#2a3937" strokeWidth="2" />
      {WHEEL_ORDER.map((number, index) => {
        const start = (index / count) * Math.PI * 2 - Math.PI / 2;
        const end = ((index + 1) / count) * Math.PI * 2 - Math.PI / 2;
        const large = 0;
        const x1 = cx + Math.cos(start) * outer;
        const y1 = cy + Math.sin(start) * outer;
        const x2 = cx + Math.cos(end) * outer;
        const y2 = cy + Math.sin(end) * outer;
        const ix1 = cx + Math.cos(end) * inner;
        const iy1 = cy + Math.sin(end) * inner;
        const ix2 = cx + Math.cos(start) * inner;
        const iy2 = cy + Math.sin(start) * inner;
        const mid = start + (end - start) / 2;
        const tx = cx + Math.cos(mid) * ((outer + inner) / 2);
        const ty = cy + Math.sin(mid) * ((outer + inner) / 2);
        const isLast = number === lastNumber;
        const isTarget = targetSet.has(number);
        return (
          <g key={number}>
            <path
              d={`M ${x1} ${y1} A ${outer} ${outer} 0 ${large} 1 ${x2} ${y2} L ${ix1} ${iy1} A ${inner} ${inner} 0 ${large} 0 ${ix2} ${iy2} Z`}
              fill={FILL[numberColor(number)]}
              stroke={isLast ? "#90D6CA" : isTarget ? "#F06C61" : "#111717"}
              strokeWidth={isLast || isTarget ? 2.2 : 0.6}
            />
            <text
              x={tx}
              y={ty}
              textAnchor="middle"
              dominantBaseline="middle"
              fill="#F4F7F7"
              fontSize={isLast ? 9.5 : 8}
              fontWeight={isLast ? 700 : 500}
              fontFamily="IBM Plex Sans, sans-serif"
            >
              {number}
            </text>
          </g>
        );
      })}
      <circle cx={cx} cy={cy} r={inner - 8} fill="#161e1d" stroke="#2a3937" />
      <text
        x={cx}
        y={cy - 8}
        textAnchor="middle"
        fill="#91A29F"
        fontSize="9"
        letterSpacing="1.6"
        fontFamily="IBM Plex Sans, sans-serif"
      >
        ÚLTIMO
      </text>
      <text
        x={cx}
        y={cy + 16}
        textAnchor="middle"
        fill="#F4F7F7"
        fontSize="28"
        fontWeight="600"
        fontFamily="Syne, sans-serif"
      >
        {lastNumber ?? "—"}
      </text>
    </svg>
  );
}
