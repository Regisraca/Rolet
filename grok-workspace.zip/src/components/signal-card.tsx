import { Activity, BarChart3, Crosshair } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { NumberOrb } from "@/components/number-orb";
import type { Signal, SignalTone } from "@/lib/roulette";
import { cn } from "@/lib/utils";

const toneMeta: Record<SignalTone, { badge: "coral" | "teal" | "blue"; icon: typeof Crosshair }> = {
  coral: { badge: "coral", icon: Crosshair },
  teal: { badge: "teal", icon: Activity },
  blue: { badge: "blue", icon: BarChart3 },
};

export function SignalBadge({ signal, compact = false }: { signal: Signal; compact?: boolean }) {
  const meta = toneMeta[signal.tone];
  const Icon = meta.icon;
  return (
    <Badge tone={meta.badge} className={compact ? "px-2 py-0.5" : undefined}>
      <Icon className={compact ? "size-3" : "size-3.5"} strokeWidth={2} />
      {signal.type}
    </Badge>
  );
}

export function TargetPills({
  targets,
  limit = 7,
  highlight,
}: {
  targets: number[];
  limit?: number;
  highlight?: number;
}) {
  const visible = targets.slice(0, limit);
  return (
    <div className="flex flex-wrap gap-1.5">
      {visible.map((target) => (
        <NumberOrb key={target} number={target} size="sm" active={target === highlight} />
      ))}
      {targets.length > limit ? (
        <span className="inline-flex h-8 min-w-8 items-center justify-center rounded-[10px] bg-surface-2 px-2 text-xs text-muted">
          +{targets.length - limit}
        </span>
      ) : null}
    </div>
  );
}

export function SignalCard({
  signal,
  compact = false,
}: {
  signal: Signal;
  compact?: boolean;
}) {
  const resultTone =
    signal.result === "GREEN" ? "text-teal" : signal.result === "RED" ? "text-danger" : "text-warn";
  return (
    <article
      className={cn(
        "rounded-[var(--radius-xl)] border border-border bg-surface-2 p-4 shadow-panel",
        compact && "p-3.5",
      )}
    >
      <div className="flex items-center justify-between gap-3">
        <SignalBadge signal={signal} compact={compact} />
        <span className={cn("text-[10px] font-semibold tracking-[0.12em] uppercase", resultTone)}>
          {signal.result === "PENDING" ? "Sinal detectado" : signal.result}
        </span>
      </div>
      <h3 className="font-display mt-3 text-lg font-semibold tracking-tight text-fg">{signal.title}</h3>
      <p className="mt-1 text-sm text-muted">{signal.trigger}</p>
      <div className="mt-3">
        <TargetPills targets={signal.targets} limit={compact ? 5 : 8} highlight={signal.resolvedNumber} />
      </div>
      <dl className="mt-4 grid grid-cols-3 gap-3">
        <div>
          <dt className="text-[10px] font-semibold tracking-[0.12em] text-subtle uppercase">Confiança</dt>
          <dd className="mt-1 font-display text-lg font-semibold text-teal tabular">{signal.confidence}%</dd>
        </div>
        <div>
          <dt className="text-[10px] font-semibold tracking-[0.12em] text-subtle uppercase">Greens</dt>
          <dd className="mt-1 font-display text-lg font-semibold tabular">
            {signal.greens}
            <span className="text-sm text-muted"> / {signal.greens + signal.reds}</span>
          </dd>
        </div>
        <div>
          <dt className="text-[10px] font-semibold tracking-[0.12em] text-subtle uppercase">Gale</dt>
          <dd className="mt-1 font-display text-lg font-semibold tabular">G0–G{signal.maxGales}</dd>
        </div>
      </dl>
    </article>
  );
}
