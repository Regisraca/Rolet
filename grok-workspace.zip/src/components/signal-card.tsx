import { Activity, BarChart3, Crosshair, Hexagon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { NumberOrb } from "@/components/number-orb";
import type { Signal, SignalPhase, SignalTone } from "@/lib/analise/roulette";
import { cn } from "@/lib/utils";

const toneMeta: Record<
  SignalTone,
  { badge: "ember" | "sage" | "blue" | "stone"; icon: typeof Crosshair }
> = {
  ember: { badge: "ember", icon: Crosshair },
  sage: { badge: "sage", icon: Activity },
  blue: { badge: "blue", icon: BarChart3 },
  stone: { badge: "stone", icon: Hexagon },
};

export function phaseLabel(phase: SignalPhase, galeHit?: 0 | 1 | 2) {
  if (phase === "GREEN") return galeHit === 1 ? "Green G1" : galeHit === 2 ? "Green G2" : "Green G0";
  if (phase === "RED") return "Red";
  if (phase === "G0") return "G0";
  if (phase === "G1") return "G1";
  if (phase === "G2") return "G2";
  if (phase === "SINAL_ATIVO") return "Sinal ativo";
  if (phase === "CONFIRMACAO") return "Confirmação";
  if (phase === "CANDIDATO") return "Candidato";
  return "Observando";
}

export function SignalBadge({ signal, compact = false }: { signal: Signal; compact?: boolean }) {
  const meta = toneMeta[signal.tone] ?? toneMeta.stone;
  const Icon = meta.icon;
  return (
    <Badge tone={meta.badge} className={compact ? "px-2 py-0.5" : undefined}>
      <Icon className={compact ? "size-3" : "size-3.5"} strokeWidth={2} />
      {signal.type}
    </Badge>
  );
}

export function TargetPills({
  targets,
  limit = 8,
  highlight,
}: {
  targets: number[];
  limit?: number;
  highlight?: number;
}) {
  const visible = targets.slice(0, limit);
  return (
    <div className="flex flex-wrap gap-1.5">
      {visible.map((target) => (
        <NumberOrb key={target} number={target} size="sm" active={target === highlight} />
      ))}
      {targets.length > limit ? (
        <span className="inline-flex h-8 min-w-8 items-center justify-center rounded-[10px] bg-surface-2 px-2 text-xs text-muted">
          +{targets.length - limit}
        </span>
      ) : null}
    </div>
  );
}

function statusCopy(signal: Signal) {
  const label = phaseLabel(signal.phase ?? (signal.result === "PENDING" ? "SINAL_ATIVO" : signal.result), signal.galeHit);
  if (signal.result === "GREEN") return { label, className: "text-sage" };
  if (signal.result === "RED") return { label, className: "text-danger" };
  if (signal.phase === "G0" || signal.phase === "G1" || signal.phase === "G2") {
    return { label, className: "text-warn" };
  }
  return { label, className: "text-warn" };
}

export function SignalCard({
  signal,
  compact = false,
}: {
  signal: Signal;
  compact?: boolean;
}) {
  const status = statusCopy(signal);
  const explanation = signal.explanation ?? [];
  return (
    <article
      className={cn(
        "rounded-[var(--radius-xl)] border border-border bg-surface-2 p-4 shadow-panel",
        compact && "p-3.5",
      )}
    >
      <div className="flex items-center justify-between gap-3">
        <SignalBadge signal={signal} compact={compact} />
        <span className={cn("text-micro", status.className)}>{status.label}</span>
      </div>
      <h3 className="font-display mt-3 text-lg font-semibold tracking-tight text-fg">{signal.title}</h3>
      <p className="mt-1 text-sm text-muted">{signal.trigger}</p>
      <div className="mt-3">
        <p className="mb-2 text-micro text-subtle">Alvos</p>
        <TargetPills targets={signal.targets} limit={compact ? 5 : 8} highlight={signal.resolvedNumber} />
      </div>
      <dl className="mt-4 grid grid-cols-3 gap-3">
        <div>
          <dt className="text-micro text-subtle">Score</dt>
          <dd className="mt-1 font-display text-lg font-semibold text-accent tabular">{signal.score}</dd>
        </div>
        <div>
          <dt className="text-micro text-subtle">Força</dt>
          <dd className="mt-1 font-display text-lg font-semibold tabular">{signal.strength}</dd>
        </div>
        <div>
          <dt className="text-micro text-subtle">Consenso</dt>
          <dd className="mt-1 font-display text-lg font-semibold tabular">
            {signal.consensus ?? 0}/{signal.consensusTotal ?? 3}
          </dd>
        </div>
      </dl>
      {explanation.length > 0 ? (
        <ul className="mt-4 flex flex-col gap-2">
          {explanation.map((item) => (
            <li key={item.strategy} className="flex items-start justify-between gap-3 text-xs text-muted">
              <span>
                <span className="font-medium text-fg">{item.strategy}</span>
                {" · "}
                {item.summary}
              </span>
              <span className="shrink-0 font-medium text-fg tabular">+{item.weighted.toFixed(1)}</span>
            </li>
          ))}
        </ul>
      ) : signal.filters.length > 0 ? (
        <ul className="mt-4 flex flex-col gap-1.5">
          {signal.filters.map((filter) => (
            <li key={filter.id} className="flex items-start gap-2 text-xs text-muted">
              <span className="mt-0.5 size-1.5 shrink-0 rounded-full bg-sage" />
              <span>
                <span className="font-medium text-fg">{filter.name}</span>
                {" · "}
                {filter.reason}
              </span>
            </li>
          ))}
        </ul>
      ) : null}
      <p className="mt-3 text-xs text-subtle">
        Score, força e consenso descrevem evidência histórica. Não são probabilidade de acerto.
      </p>
    </article>
  );
}
