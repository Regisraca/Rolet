import { Link, useRouterState } from "@tanstack/react-router";
import { Activity, Crosshair, History, Settings } from "lucide-react";
import { LiveIngest, useLiveTable } from "@/hooks/use-live-table";
import { TableSwitcher } from "@/components/table-switcher";
import { useRoletaStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Visão", icon: Crosshair },
  { to: "/history", label: "Histórico", icon: History },
  { to: "/analysis", label: "Análise", icon: Activity },
  { to: "/settings", label: "Ajustes", icon: Settings },
] as const;

function statusCopy(status: string) {
  if (status === "online") return { label: "Monitorando", className: "bg-teal" };
  if (status === "connecting") return { label: "Conectando", className: "bg-warn" };
  return { label: "Indisponível", className: "bg-danger" };
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const { source } = useLiveTable();
  const tableId = useRoletaStore((state) => state.tableId);
  const setTableId = useRoletaStore((state) => state.setTableId);
  const status = statusCopy(source.status);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <LiveIngest />
      <div className="mx-auto flex min-h-dvh max-w-6xl">
        <aside className="sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border px-4 py-6 md:flex">
          <div className="px-2">
            <p className="text-[10px] font-semibold tracking-[0.18em] text-accent uppercase">Ao vivo</p>
            <h1 className="font-display mt-1 text-xl font-semibold tracking-tight">Roleta Signal</h1>
          </div>
          <nav className="mt-8 flex flex-1 flex-col gap-1">
            {NAV.map((item) => {
              const active = pathname === item.to;
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex min-h-11 items-center gap-3 rounded-[var(--radius-md)] px-3 text-sm font-medium transition-colors",
                    active ? "bg-surface-2 text-fg" : "text-muted hover:bg-surface hover:text-fg",
                  )}
                >
                  <Icon className="size-4" strokeWidth={1.8} />
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <p className="px-2 text-[11px] leading-5 text-subtle">
            Leitura estatística. Não executa apostas e não garante resultado.
          </p>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col pb-20 md:pb-0">
          <header className="sticky top-0 z-20 border-b border-border bg-bg/92 px-4 py-3 backdrop-blur-sm md:px-6">
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="flex items-center gap-2 text-[10px] font-semibold tracking-[0.16em] text-muted uppercase">
                    <span className={cn("size-1.5 rounded-full", status.className)} />
                    {status.label}
                  </p>
                  <p className="truncate text-sm text-fg">
                    {source.provider} · {source.table}
                  </p>
                </div>
                <p className="hidden text-right text-xs text-subtle md:block">Fonte CasinoScores</p>
              </div>
              <TableSwitcher value={tableId} onChange={setTableId} />
            </div>
          </header>
          <main className="flex-1 px-4 py-5 md:px-6 md:py-6">{children}</main>
        </div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/95 backdrop-blur-sm md:hidden">
        <div className="grid grid-cols-4">
          {NAV.map((item) => {
            const active = pathname === item.to;
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex min-h-14 flex-col items-center justify-center gap-1 text-[10px] font-medium tracking-[0.04em] uppercase",
                  active ? "text-fg" : "text-subtle",
                )}
              >
                <Icon className="size-4" strokeWidth={1.8} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
