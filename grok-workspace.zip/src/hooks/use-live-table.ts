import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { emptyState, getRouletteState } from "@/lib/roulette-state";
import { playSignalTone } from "@/lib/sound";
import { useRoletaStore } from "@/lib/store";

export function useRouletteQuery() {
  const tableId = useRoletaStore((state) => state.tableId);
  const autoRefresh = useRoletaStore((state) => state.settings.autoRefresh);

  return useQuery({
    queryKey: ["roulette-state", tableId],
    queryFn: () => getRouletteState({ data: { tableId } }),
    refetchInterval: autoRefresh ? 2500 : false,
    staleTime: 800,
    placeholderData: emptyState(tableId),
  });
}

export function LiveIngest() {
  const tableId = useRoletaStore((state) => state.tableId);
  const sound = useRoletaStore((state) => state.settings.sound);
  const ingestSpins = useRoletaStore((state) => state.ingestSpins);
  const query = useRouletteQuery();
  const lastSignalId = useRef<string | null>(null);
  const spins = query.data?.spins ?? [];

  useEffect(() => {
    lastSignalId.current = null;
  }, [tableId]);

  useEffect(() => {
    if (!spins.length) return;
    const created = ingestSpins(tableId, spins);
    if (created && created.id !== lastSignalId.current) {
      lastSignalId.current = created.id;
      if (sound) void playSignalTone();
    }
  }, [ingestSpins, sound, spins, tableId]);

  return null;
}

export function useLiveTable() {
  const tableId = useRoletaStore((state) => state.tableId);
  const analysisWindow = useRoletaStore((state) => state.analysisWindow);
  const signals = useRoletaStore((state) => state.signals);
  const query = useRouletteQuery();
  const state = query.data ?? emptyState(tableId);

  return {
    tableId,
    analysisWindow,
    spins: state.spins,
    source: state.source,
    signals,
    currentSignal: signals.find((signal) => signal.result === "PENDING") ?? null,
    isFetching: query.isFetching,
    isError: query.isError || state.source.status === "error",
    refresh: query.refetch,
  };
}
