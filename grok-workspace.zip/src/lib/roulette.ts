export const WHEEL_ORDER = [
  0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24,
  16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26,
] as const;

export const RED_NUMBERS = new Set([
  1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36,
]);

export type PocketColor = "green" | "red" | "black";
export type AnalysisWindow = 20 | 50 | 100;
export type SignalType = "SNIPER" | "TERMO-FÍSICA" | "QUANT";
export type SignalTone = "coral" | "teal" | "blue";
export type SignalResult = "GREEN" | "RED" | "PENDING";
export type SourceStatus = "online" | "connecting" | "unavailable" | "error";

export type LuckyNumber = {
  number: number;
  multiplier: number | null;
};

export type Spin = {
  id: string;
  number: number;
  color: PocketColor;
  createdAt: string;
  luckyNumbers: LuckyNumber[];
  multiplier: number | null;
  totalWinners: number | null;
};

export type RouletteSource = {
  status: SourceStatus;
  origin: string;
  table: string;
  provider: string;
  message: string;
  lastEventAt: string | null;
  totalAvailable: number | null;
};

export type RouletteState = {
  spins: Spin[];
  source: RouletteSource;
};

export type Signal = {
  id: string;
  type: SignalType;
  tone: SignalTone;
  title: string;
  trigger: string;
  targets: number[];
  confidence: number;
  greens: number;
  reds: number;
  maxGales: number;
  createdAt: string;
  triggerSpinId: string;
  active: boolean;
  result: SignalResult;
  resolvedAt?: string;
  resolvedNumber?: number;
};

export function isRed(number: number) {
  return RED_NUMBERS.has(number);
}

export function numberColor(number: number): PocketColor {
  if (number === 0) return "green";
  return isRed(number) ? "red" : "black";
}

export function getWheelNeighbors(number: number, amount = 2) {
  const index = WHEEL_ORDER.indexOf(number as (typeof WHEEL_ORDER)[number]);
  if (index < 0) return [number];
  const length = WHEEL_ORDER.length;
  return Array.from({ length: amount * 2 + 1 }, (_, offset) => {
    return WHEEL_ORDER[(index + offset - amount + length) % length];
  });
}

export function formatRelativeTime(value: string, now = Date.now()) {
  const seconds = Math.max(0, Math.floor((now - new Date(value).getTime()) / 1000));
  if (seconds < 8) return "agora";
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} h`;
  return `${Math.floor(hours / 24)} d`;
}

export function dozenOf(number: number) {
  if (number <= 0) return 0;
  if (number <= 12) return 1;
  if (number <= 24) return 2;
  return 3;
}

export function columnOf(number: number) {
  if (number <= 0) return 0;
  const mod = number % 3;
  if (mod === 1) return 1;
  if (mod === 2) return 2;
  return 3;
}

export function terminalOf(number: number) {
  return number % 10;
}

export function parityOf(number: number) {
  if (number === 0) return "zero";
  return number % 2 === 0 ? "par" : "ímpar";
}

export function highLowOf(number: number) {
  if (number === 0) return "zero";
  return number <= 18 ? "baixa" : "alta";
}

function backtestTargets(history: number[], targets: number[]) {
  const sample = history.slice(0, 20);
  const greens = sample.filter((number) => targets.includes(number)).length;
  const total = Math.max(6, Math.min(sample.length, greens + Math.max(1, Math.floor(sample.length / 5))));
  const reds = Math.max(0, total - greens);
  return { greens, reds, confidence: Math.round((greens / total) * 10000) / 100 };
}

function tagForNumber(number: number, tag: string) {
  if (tag === "D1") return number >= 1 && number <= 12;
  if (tag === "D2") return number >= 13 && number <= 24;
  if (tag === "D3") return number >= 25 && number <= 36;
  if (tag === "C1") return number > 0 && number % 3 === 1;
  if (tag === "C2") return number > 0 && number % 3 === 2;
  if (tag === "C3") return number > 0 && number % 3 === 0;
  if (tag === "R") return isRed(number);
  if (tag === "B") return number > 0 && !isRed(number);
  if (tag === "P") return number > 0 && number % 2 === 0;
  if (tag === "O") return number % 2 === 1;
  if (tag === "L") return number > 0 && number <= 18;
  if (tag === "H") return number >= 19;
  if (tag === "P1") return [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27].includes(number);
  if (tag === "P2") return [13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1].includes(number);
  if (tag === "P3") return [20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26].includes(number);
  return false;
}

export function analyzeCurrentSignal(spins: Spin[]): Signal | null {
  const history = spins.map((spin) => spin.number);
  if (history.length < 12) return null;
  const createdAt = spins[0]?.createdAt ?? new Date().toISOString();
  const sourceId = spins[0]?.id ?? "unknown";

  const window = history.slice(0, 20);
  const candidates = Array.from({ length: 37 }, (_, number) => {
    const lastSeen = history.indexOf(number);
    const neighbors = getWheelNeighbors(number, 2);
    const momentum = window.filter((value) => neighbors.includes(value)).length;
    return { number, lastSeen, neighbors, momentum };
  })
    .filter((candidate) => candidate.lastSeen >= 6 && candidate.momentum >= 2)
    .sort((a, b) => b.momentum - a.momentum || b.lastSeen - a.lastSeen);

  const sniper = candidates[0];
  if (sniper) {
    const backtest = backtestTargets(history, sniper.neighbors);
    const confidence = Math.min(96, Math.max(78, 72 + sniper.momentum * 3 + Math.min(8, sniper.lastSeen)));
    if (confidence >= 80) {
      return {
        id: `live-sniper-${sourceId}-${sniper.number}`,
        type: "SNIPER",
        tone: "coral",
        title: `Sniper · alvo ${sniper.number}`,
        trigger: `Zona física · atraso ${sniper.lastSeen}`,
        targets: sniper.neighbors,
        confidence,
        greens: backtest.greens,
        reds: backtest.reds,
        maxGales: 2,
        createdAt,
        triggerSpinId: sourceId,
        active: true,
        result: "PENDING",
      };
    }
  }

  const terminalCounts = Array.from({ length: 10 }, (_, terminal) => ({
    terminal,
    hits: window.filter((number) => number % 10 === terminal).length,
  })).sort((a, b) => b.hits - a.hits);
  const terminal = terminalCounts[0];
  if (terminal && terminal.hits >= 3) {
    const base = Array.from({ length: 37 }, (_, number) => number).filter(
      (number) => number % 10 === terminal.terminal,
    );
    const targets = Array.from(new Set(base.flatMap((number) => getWheelNeighbors(number, 1))));
    const backtest = backtestTargets(history, targets);
    if (backtest.confidence >= 70) {
      return {
        id: `live-terminal-${sourceId}-${terminal.terminal}`,
        type: "TERMO-FÍSICA",
        tone: "teal",
        title: `Terminal físico T${terminal.terminal}`,
        trigger: `T${terminal.terminal} em alta · ${terminal.hits} ocorrências`,
        targets,
        confidence: Math.min(93, Math.max(74, backtest.confidence)),
        greens: backtest.greens,
        reds: backtest.reds,
        maxGales: 2,
        createdAt,
        triggerSpinId: sourceId,
        active: true,
        result: "PENDING",
      };
    }
  }

  const quantFamilies = [
    { name: "DÚZIA", tags: ["D1", "D2", "D3"] },
    { name: "COLUNA", tags: ["C1", "C2", "C3"] },
    { name: "COR", tags: ["R", "B"] },
    { name: "PARIDADE", tags: ["P", "O"] },
    { name: "METADE", tags: ["L", "H"] },
    { name: "SETOR", tags: ["P1", "P2", "P3"] },
  ];
  const quantCandidate = quantFamilies
    .flatMap((family) =>
      family.tags.map((tag) => ({
        family: family.name,
        tag,
        hits: window.filter((number) => tagForNumber(number, tag)).length,
      })),
    )
    .sort((a, b) => b.hits - a.hits)[0];

  if (quantCandidate && quantCandidate.hits >= 3) {
    const uniqueTargets = Array.from(
      new Set(history.filter((number, index) => index < 37 && tagForNumber(number, quantCandidate.tag))),
    );
    const greens = window.filter((number) => tagForNumber(number, quantCandidate.tag)).length;
    const total = Math.max(6, window.length);
    return {
      id: `live-quant-${sourceId}-${quantCandidate.tag}`,
      type: "QUANT",
      tone: "blue",
      title: `Quant · ${quantCandidate.family} ${quantCandidate.tag}`,
      trigger: `${quantCandidate.tag} em sequência · ${quantCandidate.hits} ocorrências`,
      targets:
        uniqueTargets.length > 0
          ? uniqueTargets
          : Array.from({ length: 37 }, (_, number) => number).filter((number) =>
              tagForNumber(number, quantCandidate.tag),
            ),
      confidence: Math.min(90, Math.max(70, Math.round((greens / total) * 10000) / 100 + 20)),
      greens,
      reds: Math.max(0, total - greens),
      maxGales: 2,
      createdAt,
      triggerSpinId: sourceId,
      active: true,
      result: "PENDING",
    };
  }

  return null;
}

export function resolveSignals(signals: Signal[], spins: Spin[]): Signal[] {
  return signals.map((signal) => {
    if (signal.result !== "PENDING") return signal;
    const triggerIndex = spins.findIndex((spin) => spin.id === signal.triggerSpinId);
    if (triggerIndex < 0) return signal;
    const after = spins.slice(0, triggerIndex);
    if (after.length === 0) return signal;
    const chronological = [...after].reverse().slice(0, signal.maxGales + 1);
    const hit = chronological.find((spin) => signal.targets.includes(spin.number));
    if (hit) {
      return {
        ...signal,
        result: "GREEN" as const,
        active: false,
        resolvedAt: hit.createdAt,
        resolvedNumber: hit.number,
      };
    }
    if (chronological.length >= signal.maxGales + 1) {
      const last = chronological[chronological.length - 1];
      return {
        ...signal,
        result: "RED" as const,
        active: false,
        resolvedAt: last?.createdAt,
        resolvedNumber: last?.number,
      };
    }
    return signal;
  });
}

export type WindowStats = {
  total: number;
  red: number;
  black: number;
  green: number;
  even: number;
  odd: number;
  low: number;
  high: number;
  dozens: [number, number, number];
  columns: [number, number, number];
  hot: { number: number; count: number }[];
  cold: { number: number; count: number; lastSeen: number }[];
  terminals: { terminal: number; count: number }[];
};

export function computeWindowStats(spins: Spin[], window: AnalysisWindow): WindowStats {
  const sample = spins.slice(0, window);
  const counts = Array.from({ length: 37 }, () => 0);
  let red = 0;
  let black = 0;
  let green = 0;
  let even = 0;
  let odd = 0;
  let low = 0;
  let high = 0;
  const dozens: [number, number, number] = [0, 0, 0];
  const columns: [number, number, number] = [0, 0, 0];
  const terminals = Array.from({ length: 10 }, () => 0);

  for (const spin of sample) {
    counts[spin.number] += 1;
    if (spin.number === 0) green += 1;
    else if (isRed(spin.number)) red += 1;
    else black += 1;
    if (spin.number > 0) {
      if (spin.number % 2 === 0) even += 1;
      else odd += 1;
      if (spin.number <= 18) low += 1;
      else high += 1;
      dozens[dozenOf(spin.number) - 1] += 1;
      columns[columnOf(spin.number) - 1] += 1;
    }
    terminals[spin.number % 10] += 1;
  }

  const lastSeen = (number: number) => {
    const index = sample.findIndex((spin) => spin.number === number);
    return index < 0 ? sample.length : index;
  };

  const ranked = counts
    .map((count, number) => ({ number, count, lastSeen: lastSeen(number) }))
    .sort((a, b) => b.count - a.count || a.lastSeen - b.lastSeen);

  return {
    total: sample.length,
    red,
    black,
    green,
    even,
    odd,
    low,
    high,
    dozens,
    columns,
    hot: ranked.filter((item) => item.count > 0).slice(0, 8),
    cold: [...ranked].sort((a, b) => a.count - b.count || b.lastSeen - a.lastSeen).slice(0, 8),
    terminals: terminals.map((count, terminal) => ({ terminal, count })).sort((a, b) => b.count - a.count),
  };
}
