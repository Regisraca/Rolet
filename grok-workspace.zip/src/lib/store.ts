import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { AnalysisWindow, Signal, Spin } from "@/lib/roulette";
import { analyzeCurrentSignal, resolveSignals } from "@/lib/roulette";
import { TABLE_IDS, type TableId } from "@/lib/tables";

type Settings = {
  autoRefresh: boolean;
  sound: boolean;
};

type RoletaStore = {
  tableId: TableId;
  analysisWindow: AnalysisWindow;
  settings: Settings;
  signals: Signal[];
  setTableId: (tableId: TableId) => void;
  setAnalysisWindow: (window: AnalysisWindow) => void;
  toggleSetting: (key: keyof Settings) => void;
  ingestSpins: (tableId: TableId, spins: Spin[]) => Signal | null;
};

const MAX_SIGNALS = 40;

export const useRoletaStore = create<RoletaStore>()(
  persist(
    (set, get) => ({
      tableId: "auto-roulette",
      analysisWindow: 20,
      settings: { autoRefresh: true, sound: false },
      signals: [],
      setTableId: (tableId) => set({ tableId, signals: [] }),
      setAnalysisWindow: (analysisWindow) => set({ analysisWindow }),
      toggleSetting: (key) =>
        set((state) => ({ settings: { ...state.settings, [key]: !state.settings[key] } })),
      ingestSpins: (tableId, spins) => {
        if (tableId !== get().tableId) return null;
        const current = analyzeCurrentSignal(spins);
        let created: Signal | null = null;
        set((state) => {
          const resolved = resolveSignals(state.signals, spins);
          const already = current ? resolved.some((signal) => signal.id === current.id) : false;
          const next = already || !current ? resolved : [current, ...resolved];
          if (current && !already) created = current;
          return { signals: next.slice(0, MAX_SIGNALS) };
        });
        return created;
      },
    }),
    {
      name: "roleta-signal-v1",
      partialize: (state) => ({
        tableId: state.tableId,
        analysisWindow: state.analysisWindow,
        settings: state.settings,
        signals: state.signals,
      }),
    },
  ),
);

export function rememberTable(tableId: string): TableId {
  return (TABLE_IDS as readonly string[]).includes(tableId) ? (tableId as TableId) : "auto-roulette";
}
