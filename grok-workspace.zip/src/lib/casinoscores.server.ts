import type { LuckyNumber, PocketColor, RouletteState, Spin } from "@/lib/roulette";
import { numberColor } from "@/lib/roulette";
import { TABLES, type TableId } from "@/lib/tables";

const API_BASE = "https://api-cs.casino.org/svc-evolution-game-events/api";
const CACHE_TTL_MS = 2_200;
const FETCH_TIMEOUT_MS = 12_000;

type RawLucky = {
  number?: number;
  roundedMultiplier?: number;
  multiplier?: number;
};

type RawEvent = {
  id?: string;
  totalWinners?: number;
  data?: {
    id?: string;
    startedAt?: string;
    settledAt?: string;
    status?: string;
    table?: { id?: string; name?: string };
    result?: {
      outcome?: { number?: number; type?: string; color?: string };
      luckyNumbersList?: RawLucky[];
      lightningMultiplier?: number;
      superBoost?: boolean;
    };
  };
};

type CacheEntry = { at: number; state: RouletteState };

const cache = new Map<string, CacheEntry>();

function asColor(value: string | undefined, number: number): PocketColor {
  const normalized = value?.toLowerCase();
  if (normalized === "red") return "red";
  if (normalized === "black") return "black";
  if (normalized === "green") return "green";
  return numberColor(number);
}

function parseLucky(list: RawLucky[] | undefined, lightning: number | undefined): LuckyNumber[] {
  if (!list?.length) return [];
  return list
    .filter((item) => typeof item.number === "number" && item.number >= 0 && item.number <= 36)
    .map((item) => ({
      number: item.number as number,
      multiplier: item.roundedMultiplier ?? item.multiplier ?? lightning ?? null,
    }));
}

function parseEvents(raw: unknown): Spin[] {
  if (!Array.isArray(raw)) return [];
  const spins: Spin[] = [];
  for (const event of raw as RawEvent[]) {
    const number = event.data?.result?.outcome?.number;
    if (typeof number !== "number" || number < 0 || number > 36) continue;
    const settledAt = event.data?.settledAt;
    if (!settledAt) continue;
    const lightning = event.data?.result?.lightningMultiplier ?? null;
    const luckyNumbers = parseLucky(event.data?.result?.luckyNumbersList, lightning ?? undefined);
    const matched = luckyNumbers.find((item) => item.number === number);
    spins.push({
      id: String(event.id ?? event.data?.id ?? `${settledAt}-${number}`),
      number,
      color: asColor(event.data?.result?.outcome?.color, number),
      createdAt: settledAt,
      luckyNumbers,
      multiplier: lightning ?? matched?.multiplier ?? null,
      totalWinners: typeof event.totalWinners === "number" ? event.totalWinners : null,
    });
  }
  return spins;
}

async function fetchTable(tableId: TableId): Promise<RouletteState> {
  const table = TABLES[tableId];
  const url = `${API_BASE}/${table.apiPath}?page=0&size=100&sort=data.settledAt,desc&duration=${table.duration}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        Accept: "application/json",
        Origin: "https://www.casino.org",
        Referer: table.pageUrl,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
      },
    });
    if (!response.ok) {
      return {
        spins: [],
        source: {
          status: "error",
          origin: "CasinoScores",
          table: table.label,
          provider: table.providerLabel,
          message: `A fonte respondeu ${response.status}. Tente atualizar em instantes.`,
          lastEventAt: null,
          totalAvailable: null,
        },
      };
    }
    const totalHeader = response.headers.get("x-total-count");
    const totalAvailable = totalHeader ? Number(totalHeader) : null;
    const payload: unknown = await response.json();
    const spins = parseEvents(payload);
    if (spins.length === 0) {
      return {
        spins: [],
        source: {
          status: "error",
          origin: "CasinoScores",
          table: table.label,
          provider: table.providerLabel,
          message: "Mesa conectada, mas nenhum giro foi encontrado no histórico.",
          lastEventAt: null,
          totalAvailable: Number.isFinite(totalAvailable) ? totalAvailable : null,
        },
      };
    }
    return {
      spins,
      source: {
        status: "online",
        origin: "CasinoScores · API pública",
        table: table.label,
        provider: table.providerLabel,
        message: "Recebendo resultados ao vivo.",
        lastEventAt: spins[0]?.createdAt ?? null,
        totalAvailable: Number.isFinite(totalAvailable) ? totalAvailable : spins.length,
      },
    };
  } catch (error) {
    const aborted = error instanceof Error && error.name === "AbortError";
    return {
      spins: [],
      source: {
        status: "error",
        origin: "CasinoScores",
        table: table.label,
        provider: table.providerLabel,
        message: aborted
          ? "A leitura da mesa excedeu o tempo limite."
          : "Não foi possível consultar a fonte de resultados.",
        lastEventAt: null,
        totalAvailable: null,
      },
    };
  } finally {
    clearTimeout(timer);
  }
}

export async function readTableState(tableId: TableId): Promise<RouletteState> {
  const cached = cache.get(tableId);
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) return cached.state;
  const state = await fetchTable(tableId);
  if (state.source.status === "online") {
    cache.set(tableId, { at: Date.now(), state });
  }
  return state;
}
