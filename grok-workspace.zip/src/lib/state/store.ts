import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { AnalysisWindow } from "@/lib/config/app";
import { DEFAULT_MAX_GALES, DEFAULT_MIN_SCORE, DEFAULT_WINDOW, MAX_SIGNALS } from "@/lib/config/app";
import type { ConnectorStatus, Signal } from "@/lib/analise/roulette";
import { emptyEngineState, evaluateEngine, runSignalCycle, type V19EngineState } from "@/lib/engine/signal-engine";
import { TABLE_IDS, type TableId } from "@/lib/config/tables";
import type { EngineSnapshot } from "@/lib/types/strategy";
import type { EstrategiaV19 } from "@/lib/v19/classify";
import { DEFAULT_V19 } from "@/lib/v19/constants";
import { padraoParaEstrategia, type PadraoMinerado } from "@/lib/v19/quant";
import { emptyBanca, defaultRuntime, type BancaState, type V19RuntimeConfig } from "@/lib/v19/live";
import type { Spin } from "@/lib/analise/roulette";

type Settings = {
  sound: boolean;
};

export type TableRuntime = {
  status: ConnectorStatus;
  sessionId: string | null;
  error: string | null;
};

function hydrateSignal(signal: Signal): Signal {
  return {
    ...signal,
    phase: signal.phase ?? (signal.result === "PENDING" ? "SINAL_ATIVO" : signal.result),
    consensus: signal.consensus ?? 1,
    consensusTotal: signal.consensusTotal ?? 1,
    explanation: signal.explanation ?? [],
    galeAtual: signal.galeAtual ?? signal.galeStep ?? 0,
  };
}

type RoletaStore = {
  tableId: TableId;
  analysisWindow: AnalysisWindow;
  minScore: number;
  maxGales: number;
  atrasoMin: number;
  vizinhosSniper: number;
  momentumMin: number;
  termHits: number;
  termViz: number;
  fichaBase: number;
  bancaInicial: number;
  sniperEnabled: boolean;
  termoEnabled: boolean;
  settings: Settings;
  signals: Signal[];
  engine: V19EngineState;
  snapshot: EngineSnapshot | null;
  estrategias: EstrategiaV19[];
  banca: BancaState;
  runtime: Record<TableId, TableRuntime>;
  setTableId: (tableId: TableId) => void;
  setAnalysisWindow: (window: AnalysisWindow) => void;
  setMinScore: (value: number) => void;
  setMaxGales: (value: number) => void;
  setAtrasoMin: (value: number) => void;
  setVizinhosSniper: (value: number) => void;
  setMomentumMin: (value: number) => void;
  setTermHits: (value: number) => void;
  setTermViz: (value: number) => void;
  setFichaBase: (value: number) => void;
  setBancaInicial: (value: number) => void;
  setSniperEnabled: (value: boolean) => void;
  setTermoEnabled: (value: boolean) => void;
  toggleSetting: (key: keyof Settings) => void;
  setRuntime: (tableId: TableId, patch: Partial<TableRuntime>) => void;
  addEstrategia: (est: EstrategiaV19) => void;
  removeEstrategia: (index: number) => void;
  applyQuant: (padrao: PadraoMinerado) => void;
  clearEstrategias: () => void;
  zerarDia: () => void;
  ingestSpins: (tableId: TableId, spins: Spin[]) => Signal | null;
};

function emptyRuntime(): Record<TableId, TableRuntime> {
  return {
    "auto-roulette": { status: "disconnected", sessionId: null, error: null },
    "immersive-roulette": { status: "disconnected", sessionId: null, error: null },
    "mega-fire-blaze": { status: "disconnected", sessionId: null, error: null },
    "mega-roulette": { status: "disconnected", sessionId: null, error: null },
  };
}

export function runtimeFromStore(state: {
  analysisWindow: number;
  minScore: number;
  maxGales: number;
  atrasoMin: number;
  vizinhosSniper: number;
  momentumMin: number;
  termHits: number;
  termViz: number;
  fichaBase: number;
  sniperEnabled: boolean;
  termoEnabled: boolean;
}): V19RuntimeConfig {
  return {
    ...defaultRuntime(),
    amostra: state.analysisWindow,
    minAssertividade: state.minScore,
    maxGales: state.maxGales,
    atrasoMin: state.atrasoMin,
    vizinhosSniper: state.vizinhosSniper,
    momentumMin: state.momentumMin,
    termHits: state.termHits,
    termViz: state.termViz,
    fichaBase: state.fichaBase,
    sniperEnabled: state.sniperEnabled,
    termoEnabled: state.termoEnabled,
  };
}

export const useRoletaStore = create<RoletaStore>()(
  persist(
    (set, get) => ({
      tableId: "auto-roulette",
      analysisWindow: DEFAULT_WINDOW,
      minScore: DEFAULT_MIN_SCORE,
      maxGales: DEFAULT_MAX_GALES,
      atrasoMin: DEFAULT_V19.atrasoMin,
      vizinhosSniper: DEFAULT_V19.vizinhosSniper,
      momentumMin: DEFAULT_V19.momentumMin,
      termHits: DEFAULT_V19.termHits,
      termViz: DEFAULT_V19.termViz,
      fichaBase: DEFAULT_V19.fichaBase,
      bancaInicial: DEFAULT_V19.bancaInicial,
      sniperEnabled: true,
      termoEnabled: true,
      settings: { sound: false },
      signals: [],
      engine: emptyEngineState(),
      snapshot: null,
      estrategias: [],
      banca: emptyBanca(DEFAULT_V19.bancaInicial),
      runtime: emptyRuntime(),
      setTableId: (tableId) => set({ tableId }),
      setAnalysisWindow: (analysisWindow) => set({ analysisWindow }),
      setMinScore: (minScore) => set({ minScore }),
      setMaxGales: (maxGales) => set({ maxGales }),
      setAtrasoMin: (atrasoMin) => set({ atrasoMin }),
      setVizinhosSniper: (vizinhosSniper) => set({ vizinhosSniper }),
      setMomentumMin: (momentumMin) => set({ momentumMin }),
      setTermHits: (termHits) => set({ termHits }),
      setTermViz: (termViz) => set({ termViz }),
      setFichaBase: (fichaBase) => set({ fichaBase }),
      setBancaInicial: (bancaInicial) => set({ bancaInicial, banca: { ...get().banca, bancaInicial } }),
      setSniperEnabled: (sniperEnabled) => set({ sniperEnabled }),
      setTermoEnabled: (termoEnabled) => set({ termoEnabled }),
      toggleSetting: (key) => set((state) => ({ settings: { ...state.settings, [key]: !state.settings[key] } })),
      setRuntime: (tableId, patch) =>
        set((state) => ({
          runtime: { ...state.runtime, [tableId]: { ...state.runtime[tableId], ...patch } },
        })),
      addEstrategia: (est) => set((state) => ({ estrategias: [...state.estrategias, est] })),
      removeEstrategia: (index) =>
        set((state) => ({ estrategias: state.estrategias.filter((_, i) => i !== index) })),
      applyQuant: (padrao) =>
        set((state) => ({
          estrategias: [padraoParaEstrategia(padrao), ...state.estrategias],
        })),
      clearEstrategias: () => set({ estrategias: [] }),
      zerarDia: () => {
        const bancaInicial = get().bancaInicial;
        set({
          banca: emptyBanca(bancaInicial),
          signals: [],
          engine: emptyEngineState(),
        });
      },
      ingestSpins: (tableId, spins) => {
        if (tableId !== get().tableId) return null;
        const state = get();
        const config = runtimeFromStore(state);
        const cycle = runSignalCycle({
          spins,
          state: {
            ...state.engine,
            signals: (state.engine.signals.length ? state.engine.signals : state.signals).map(hydrateSignal),
            banca: state.banca,
          },
          config,
          estrategias: state.estrategias,
        });
        set({
          signals: cycle.state.signals.slice(0, MAX_SIGNALS),
          engine: cycle.state,
          snapshot: cycle.snapshot,
          banca: cycle.state.banca,
          estrategias: cycle.state.candidate?.est_obj
            ? state.estrategias.map((est) => (est === cycle.state.candidate?.est_obj ? cycle.state.candidate.est_obj! : est))
            : state.estrategias,
        });
        return cycle.created;
      },
    }),
    {
      name: "regis-cunha-roleta-v19",
      partialize: (state) => ({
        tableId: state.tableId,
        analysisWindow: state.analysisWindow,
        minScore: state.minScore,
        maxGales: state.maxGales,
        atrasoMin: state.atrasoMin,
        vizinhosSniper: state.vizinhosSniper,
        momentumMin: state.momentumMin,
        termHits: state.termHits,
        termViz: state.termViz,
        fichaBase: state.fichaBase,
        bancaInicial: state.bancaInicial,
        sniperEnabled: state.sniperEnabled,
        termoEnabled: state.termoEnabled,
        settings: state.settings,
        signals: state.signals,
        estrategias: state.estrategias,
        banca: state.banca,
      }),
      merge: (persisted, current) => {
        const incoming = (persisted ?? {}) as Partial<RoletaStore>;
        const signals = (incoming.signals ?? current.signals).map(hydrateSignal);
        return {
          ...current,
          ...incoming,
          signals,
          engine: emptyEngineState(signals),
          banca: incoming.banca ?? current.banca,
          estrategias: incoming.estrategias ?? current.estrategias,
        };
      },
    },
  ),
);

export function rememberTable(tableId: string): TableId {
  return (TABLE_IDS as readonly string[]).includes(tableId) ? (tableId as TableId) : "auto-roulette";
}

export function peekEngine(spins: Spin[]) {
  const state = useRoletaStore.getState();
  return evaluateEngine(spins, runtimeFromStore(state), state.estrategias);
}
