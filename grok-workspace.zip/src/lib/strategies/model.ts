import type { ModelParams, StrategyWeights } from "@/lib/config/strategies";
import type { RankedCandidate, StrategyContext, StrategyId, StrategyOutput, StrategyReason } from "@/lib/types/strategy";
import { emptyStrategy, round1, statusFromScore } from "@/lib/strategies/helpers";

const BASE_STRATEGIES: StrategyId[] = ["SNIPER", "TERMO", "QUANT"];

export function rankByAgreement(
  outputs: StrategyOutput[],
  weights: StrategyWeights,
  limit: number,
): RankedCandidate[] {
  const scores = Array.from({ length: 37 }, () => 0);
  const votes: StrategyId[][] = Array.from({ length: 37 }, () => []);

  for (const output of outputs) {
    if (output.strategy === "MODELO") continue;
    if (output.status === "DADOS_INSUFICIENTES") continue;
    const weight =
      output.strategy === "SNIPER" ? weights.sniper : output.strategy === "TERMO" ? weights.termo : weights.quant;
    const peak = output.candidates[0]?.score || 1;
    for (const candidate of output.candidates) {
      const share = peak > 0 ? candidate.score / peak : 0;
      scores[candidate.number] += share * output.score * weight;
      if (!votes[candidate.number].includes(output.strategy)) {
        votes[candidate.number].push(output.strategy);
      }
    }
  }

  return scores
    .map((score, number) => ({
      number,
      score: round1(score + Math.max(0, votes[number].length - 1) * 2.4),
      votes: votes[number],
    }))
    .filter((item) => item.votes.length > 0)
    .sort((a, b) => b.votes.length - a.votes.length || b.score - a.score || a.number - b.number)
    .slice(0, limit);
}

export function runModelo(
  ctx: StrategyContext,
  params: ModelParams,
  peers: StrategyOutput[],
  weights: StrategyWeights,
): StrategyOutput {
  const available = Math.max(...peers.map((item) => item.availableSpins), ctx.history.length);
  const required = Math.max(...peers.map((item) => item.requiredSpins), params.minScore > 0 ? 24 : 24);
  const ready = peers.filter((item) => item.strategy !== "MODELO" && item.status !== "DADOS_INSUFICIENTES");

  if (ready.length === 0) {
    return emptyStrategy("MODELO", "DADOS_INSUFICIENTES", available, required, ctx.window, ctx.timestamp, [
      { code: "history", text: "MODELO espera o resultado das outras estratégias." },
    ]);
  }

  const ranking = rankByAgreement(ready, weights, params.maxCandidates);
  const triples = ranking.filter((item) => item.votes.length >= 3);
  const doubles = ranking.filter((item) => item.votes.length >= 2);
  const maxVotes = ranking[0]?.votes.length ?? 0;
  const reasons: StrategyReason[] = [];

  let score = 0;
  if (triples.length > 0) {
    score += 5 + triples.length * 2;
    reasons.push({
      code: "triple",
      text: `Convergência 3/3 em ${triples.map((item) => item.number).slice(0, 4).join(", ")}`,
    });
  }
  if (doubles.length > 0) {
    score += Math.min(5, doubles.length * 1.4);
    reasons.push({
      code: "double",
      text: `${doubles.length} números com acordo de pelo menos 2 estratégias`,
    });
  }
  if (maxVotes >= 3) {
    score += 5;
    reasons.push({
      code: "consensus",
      text: `Maior consenso: ${maxVotes}/3 em ${ranking[0]?.number}`,
    });
  } else if (maxVotes >= 2) {
    score += 2;
    reasons.push({
      code: "consensus",
      text: `Maior consenso: ${maxVotes}/3 em ${ranking[0]?.number}`,
    });
  } else if (ranking[0]) {
    reasons.push({
      code: "diverge",
      text: "Estratégias divergem — sem interseção relevante",
    });
  }

  const candidates = ranking.filter((item) => item.votes.length >= params.minAgreement);
  const shown = candidates.length > 0 ? candidates : ranking.slice(0, Math.min(3, ranking.length));
  const finalScore = round1(Math.min(18, score));
  const hasAgreement = maxVotes >= params.minAgreement;
  const status = !hasAgreement
    ? ranking.length > 0
      ? "CANDIDATO"
      : "OBSERVANDO"
    : statusFromScore(finalScore, params.minScore, shown.length > 0 && maxVotes >= params.minAgreement);

  return {
    strategy: "MODELO",
    candidates: shown.map((item) => ({ ...item, votes: item.votes })),
    score: finalScore,
    reasons: reasons.slice(0, 4),
    window: ctx.window,
    timestamp: ctx.timestamp,
    status,
    requiredSpins: required,
    availableSpins: available,
  };
}
