import type { Signal, SignalPhase, Spin } from "@/lib/analise/roulette";
import { MAX_SIGNALS } from "@/lib/config/app";
import { classificarNumero, expandirAlvos } from "@/lib/v19/classify";
import type { EstrategiaV19 } from "@/lib/v19/classify";
import {
  candidateToSignal,
  chronologicalFromSpins,
  detectarSinal,
  emptyBanca,
  galeLabel,
  phaseFromGale,
  resolverSinalAtivo,
  type BancaState,
  type CandidateSignal,
  type MesaInfo,
  type V19RuntimeConfig,
  defaultRuntime,
} from "@/lib/v19/live";
import { analisarNumerosPlenosSniper } from "@/lib/v19/sniper";
import { analisarTerminaisDinamicos } from "@/lib/v19/termo";
import { minerarPadroesAoVivo } from "@/lib/v19/quant";
import { backtestEstrategias } from "@/lib/v19/backtest";
import type { EngineSnapshot, SignalEngineState, StrategyOutput } from "@/lib/types/strategy";

export type V19EngineState = SignalEngineState & {
  candidate: CandidateSignal | null;
  mesa: MesaInfo;
  banca: BancaState;
};

export function emptyMesa(): MesaInfo {
  return {
    historico: [],
    cooldownSniper: 0,
    ultimoAlvoSniper: null,
    cooldownTerm: 0,
    ultimoAlvoTerm: null,
  };
}

export function emptyEngineState(signals: Signal[] = []): V19EngineState {
  return {
    signals,
    confirmation: null,
    lastProcessedSpinId: null,
    lastResolvedSpinId: null,
    candidate: null,
    mesa: emptyMesa(),
    banca: emptyBanca(),
  };
}

export function phaseOfPending(spinsSince: number, galeAtual: number): SignalPhase {
  if (spinsSince <= 0) return "SINAL_ATIVO";
  return phaseFromGale(galeAtual, true);
}

export function advanceSignal(signal: Signal, spins: Spin[]): Signal {
  const triggerIndex = spins.findIndex((spin) => spin.id === signal.triggerSpinId);
  const spinsSince = triggerIndex < 0 ? signal.spinsSince : triggerIndex;
  if (signal.result !== "PENDING") {
    return { ...signal, spinsSince, phase: signal.result, active: false };
  }
  if (triggerIndex < 0) return { ...signal, spinsSince };
  const after = spins.slice(0, triggerIndex);
  if (after.length === 0) {
    return { ...signal, spinsSince: 0, phase: "SINAL_ATIVO", galeAtual: 0, galeStep: 0, active: true };
  }
  const chronological = [...after].reverse().slice(0, (signal.maxGales ?? 2) + 1);
  const tokens = (signal.apostaStr ?? signal.targets.join(" ")).replace(/,/g, " ").split(/\s+/).filter(Boolean);
  const expanded = expandirAlvos(tokens);
  const hitIndex = chronological.findIndex((spin) => {
    const tags = classificarNumero(spin.number);
    return expanded.includes(String(spin.number)) || tokens.some((token) => tags.includes(token));
  });
  if (hitIndex >= 0) {
    const hit = chronological[hitIndex];
    return {
      ...signal,
      result: "GREEN",
      active: false,
      phase: "GREEN",
      resolvedAt: hit.createdAt,
      resolvedNumber: hit.number,
      resolvedSpinId: hit.id,
      galeHit: Math.min(hitIndex, 2) as 0 | 1 | 2,
      galeStep: Math.min(hitIndex, 2) as 0 | 1 | 2,
      galeAtual: hitIndex,
      spinsSince,
    };
  }
  if (chronological.length >= (signal.maxGales ?? 2) + 1) {
    const last = chronological[chronological.length - 1];
    return {
      ...signal,
      result: "RED",
      active: false,
      phase: "RED",
      resolvedAt: last?.createdAt,
      resolvedNumber: last?.number,
      resolvedSpinId: last?.id,
      galeStep: Math.min(Math.max(0, chronological.length - 1), 2) as 0 | 1 | 2,
      galeAtual: Math.max(0, chronological.length - 1),
      spinsSince,
    };
  }
  const galeAtual = Math.max(0, chronological.length - 1);
  return {
    ...signal,
    spinsSince,
    phase: phaseFromGale(galeAtual, true),
    galeStep: Math.min(galeAtual, 2) as 0 | 1 | 2,
    galeAtual,
    active: true,
  };
}

export function resolveSignals(signals: Signal[], spins: Spin[]): Signal[] {
  return signals.map((signal) => advanceSignal(signal, spins));
}

function statusOf(ready: boolean, available: number, required: number): StrategyOutput["status"] {
  if (available < required) return "DADOS_INSUFICIENTES";
  if (ready) return "PRONTO";
  return "OBSERVANDO";
}

export function evaluateEngine(
  spins: Spin[],
  config: V19RuntimeConfig = defaultRuntime(),
  estrategias: EstrategiaV19[] = [],
): EngineSnapshot {
  const historico = chronologicalFromSpins(spins);
  const available = historico.length;
  const required = config.amostra;
  const sniper = config.sniperEnabled
    ? analisarNumerosPlenosSniper(historico, {
        janelaAmostra: config.amostra,
        atrasoMin: config.atrasoMin,
        qtdVizinhos: config.vizinhosSniper,
        momentumMin: config.momentumMin,
        minMeta: config.minAssertividade,
        maxGales: config.maxGales,
      })
    : null;
  const termo = config.termoEnabled
    ? analisarTerminaisDinamicos(historico, {
        janelaAmostra: config.amostra,
        minHits: config.termHits,
        qtdVizinhos: config.termViz,
        minMeta: config.minAssertividade,
        maxGales: config.maxGales,
      })
    : null;
  const mined = minerarPadroesAoVivo(historico, config.maxGales);
  const ranked = backtestEstrategias(historico, estrategias);
  const leader = [...ranked].filter((est) => (est.greens ?? 0) + (est.reds ?? 0) >= 3).sort((a, b) => (b.pct ?? 0) - (a.pct ?? 0))[0];
  const at = spins[0]?.createdAt ?? new Date().toISOString();
  const strategies: StrategyOutput[] = [
    {
      strategy: "SNIPER",
      candidates: sniper ? sniper.alvos.map((n) => ({ number: Number(n), score: sniper.pct, votes: ["SNIPER"] })) : [],
      score: sniper?.pct ?? 0,
      reasons: sniper
        ? [{ code: "sniper", text: `${sniper.nome} · ${sniper.pct.toFixed(1)}% · ${galeLabel(0)}` }]
        : [{ code: "watch", text: "Sem zona física com atraso + momentum e assertividade mínima." }],
      window: config.amostra,
      timestamp: at,
      status: statusOf(Boolean(sniper), available, required),
      requiredSpins: required,
      availableSpins: available,
    },
    {
      strategy: "TERMO",
      candidates: termo ? termo.alvos.map((n) => ({ number: Number(n), score: termo.pct, votes: ["TERMO"] })) : [],
      score: termo?.pct ?? 0,
      reasons: termo
        ? [{ code: "termo", text: termo.gatilho_str }]
        : [{ code: "watch", text: "Nenhum terminal com hits e assertividade suficientes." }],
      window: config.amostra,
      timestamp: at,
      status: statusOf(Boolean(termo), available, required),
      requiredSpins: required,
      availableSpins: available,
    },
    {
      strategy: "QUANT",
      candidates: mined[0]
        ? expandirAlvos(mined[0].alvos_expandidos)
            .map((n) => Number(n))
            .filter((n) => n >= 0 && n <= 36)
            .map((number) => ({ number, score: mined[0].assertividade, votes: ["QUANT" as const] }))
        : [],
      score: mined[0]?.assertividade ?? 0,
      reasons: mined.length
        ? [{ code: "quant", text: `${mined.length} padrões · ${mined[0].nome}` }]
        : [{ code: "watch", text: available < 20 ? `Coletando base (${available}/20).` : "Nenhuma assimetria passou no filtro de Wilson." }],
      window: config.amostra,
      timestamp: at,
      status: statusOf(mined.length > 0, available, 20),
      requiredSpins: 20,
      availableSpins: available,
    },
    {
      strategy: "MODELO",
      candidates: [],
      score: leader?.pct ?? 0,
      reasons: leader
        ? [{ code: "leader", text: `Líder do backtest: ${leader.nome ?? leader.gatilho_str} (${(leader.pct ?? 0).toFixed(1)}%)` }]
        : [{ code: "watch", text: "MODELO avalia as estratégias ativas. Sem amostra suficiente." }],
      window: config.amostra,
      timestamp: at,
      status: statusOf(Boolean(leader), available, 10),
      requiredSpins: 10,
      availableSpins: available,
    },
  ];

  const ready = strategies.filter((item) => item.status === "PRONTO");
  let phase: SignalPhase = "OBSERVANDO";
  if (available < 20) phase = "OBSERVANDO";
  else if (ready.length) phase = "CANDIDATO";

  return {
    at,
    triggerSpinId: spins[0]?.id ?? null,
    availableSpins: available,
    requiredSpins: required,
    insufficient: available < 20,
    phase,
    strategies,
    consensus: {
      ranking: ready.flatMap((item) => item.candidates).slice(0, 8),
      score: Math.max(0, ...ready.map((item) => item.score)),
      consensus: ready.length,
      consensusTotal: 3,
      reasons: strategies.flatMap((item) => item.reasons).slice(0, 4),
      contributions: strategies.map((item) => ({
        strategy: item.strategy,
        score: item.score,
        weight: 1,
        weighted: item.score,
        summary: item.reasons[0]?.text ?? "",
        candidates: item.candidates.map((c) => c.number),
      })),
      status: ready.length ? "PRONTO" : available < 20 ? "DADOS_INSUFICIENTES" : "OBSERVANDO",
      requiredSpins: required,
      availableSpins: available,
    },
  };
}

export function runSignalCycle(args: {
  spins: Spin[];
  state: SignalEngineState | V19EngineState;
  config?: V19RuntimeConfig;
  estrategias?: EstrategiaV19[];
}): { state: V19EngineState; created: Signal | null; snapshot: EngineSnapshot } {
  const config = args.config ?? defaultRuntime();
  const estrategias = args.estrategias ?? [];
  const spins = args.spins;
  const prev = args.state as V19EngineState;
  const snapshot = evaluateEngine(spins, config, estrategias);
  const newestId = spins[0]?.id ?? null;
  let signals = resolveSignals(prev.signals ?? [], spins).slice(0, MAX_SIGNALS);
  let banca = prev.banca ?? emptyBanca();
  let mesa: MesaInfo = prev.mesa ?? emptyMesa();
  let candidate = prev.candidate ?? null;
  const historico = chronologicalFromSpins(spins);
  mesa = { ...mesa, historico };

  if (!newestId) {
    return { state: { ...emptyEngineState(signals), banca, mesa, candidate }, created: null, snapshot };
  }

  if (newestId === prev.lastProcessedSpinId) {
    const active = signals.find((signal) => signal.result === "PENDING");
    return {
      state: { signals, confirmation: null, lastProcessedSpinId: newestId, lastResolvedSpinId: prev.lastResolvedSpinId ?? null, candidate, mesa, banca },
      created: null,
      snapshot: { ...snapshot, phase: active?.phase ?? snapshot.phase },
    };
  }

  if (mesa.cooldownSniper > 0) mesa = { ...mesa, cooldownSniper: mesa.cooldownSniper - 1 };
  if (mesa.cooldownTerm > 0) mesa = { ...mesa, cooldownTerm: mesa.cooldownTerm - 1 };

  const pendingUi = signals.find((signal) => signal.result === "PENDING");
  if (candidate && spins[0]) {
    const tags = classificarNumero(spins[0].number);
    const hora = new Date(spins[0].createdAt).toISOString().slice(11, 19);
    const resolved = resolverSinalAtivo({
      sinal: candidate,
      numero: spins[0].number,
      tags,
      banca,
      config,
      hora,
    });
    banca = resolved.banca;
    if (resolved.resolved) {
      if (candidate.is_termo) {
        mesa = { ...mesa, ultimoAlvoTerm: String(candidate.alvo_central ?? ""), cooldownTerm: config.cooldown };
      } else if (candidate.alvo_central !== undefined && typeof candidate.alvo_central === "number") {
        mesa = { ...mesa, ultimoAlvoSniper: candidate.alvo_central, cooldownSniper: config.cooldown };
      }
      candidate = null;
    } else {
      candidate = resolved.sinal;
    }
  }

  const stillPending = signals.some((signal) => signal.result === "PENDING");
  let created: Signal | null = null;
  if (!stillPending && !candidate) {
    const detected = detectarSinal({ historico, estrategias, config, mesa });
    if (detected) {
      created = candidateToSignal(detected, spins[0]);
      created = { ...created, apostaStr: detected.aposta_str, galeAtual: 0, isTermo: detected.is_termo, alvoCentral: detected.alvo_central };
      candidate = detected;
      signals = [created, ...signals].slice(0, MAX_SIGNALS);
    }
  }

  const justResolved = signals.find(
    (signal) =>
      (signal.result === "GREEN" || signal.result === "RED") &&
      signal.resolvedSpinId &&
      !(prev.signals ?? []).find((item) => item.id === signal.id && item.result !== "PENDING"),
  );

  return {
    state: {
      signals,
      confirmation: null,
      lastProcessedSpinId: newestId,
      lastResolvedSpinId: justResolved?.resolvedSpinId ?? prev.lastResolvedSpinId ?? null,
      candidate,
      mesa,
      banca,
    },
    created,
    snapshot: {
      ...snapshot,
      phase: created ? "SINAL_ATIVO" : pendingUi?.phase ?? (candidate ? "G0" : snapshot.phase),
    },
  };
}

export function passesQuality() {
  return false;
}
