import type { Spin } from "@/lib/analise/roulette";
import { buildEngineConfig, type StrategyEngineConfig } from "@/lib/config/strategies";
import { runModelo, runQuant, runSniper, runTermo } from "@/lib/strategies";
import type { StrategyContext, StrategyOutput } from "@/lib/types/strategy";

export function makeContext(spins: Spin[], window: number, timestamp?: string): StrategyContext {
  return {
    spins,
    history: spins.map((spin) => spin.number),
    window,
    timestamp: timestamp ?? spins[0]?.createdAt ?? new Date().toISOString(),
  };
}

export function runIndependentStrategies(spins: Spin[], config: StrategyEngineConfig = buildEngineConfig()): StrategyOutput[] {
  const window = Math.max(config.sniper.window, config.quant.window, config.termo.longWindow);
  const ctx = makeContext(spins, window);
  const sniper = runSniper(ctx, config.sniper);
  const termo = runTermo(ctx, config.termo);
  const quant = runQuant(ctx, config.quant);
  const modelo = runModelo(ctx, config.model, [sniper, termo, quant], config.weights);
  return [sniper, termo, quant, modelo];
}
