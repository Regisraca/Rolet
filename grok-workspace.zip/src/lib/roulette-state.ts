import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { isTableId, TABLE_IDS, TABLES } from "@/lib/tables";
import type { RouletteState } from "@/lib/roulette";

const InputSchema = z.object({
  tableId: z.enum(TABLE_IDS),
});

export const getRouletteState = createServerFn({ method: "GET" })
  .validator((data: unknown) => InputSchema.parse(data))
  .handler(async ({ data }): Promise<RouletteState> => {
    const { readTableState } = await import("@/lib/casinoscores.server");
    return readTableState(data.tableId);
  });

export function emptyState(tableId: string): RouletteState {
  const table = isTableId(tableId) ? TABLES[tableId] : TABLES["auto-roulette"];
  return {
    spins: [],
    source: {
      status: "connecting",
      origin: "CasinoScores",
      table: table.label,
      provider: table.providerLabel,
      message: "Conectando à mesa...",
      lastEventAt: null,
      totalAvailable: null,
    },
  };
}
