import type { Signal, SignalType, Spin } from "@/lib/analise/roulette";

export type StrategyId = SignalType;

export type StrategyStatus =
  | "OBSERVANDO"
  | "CANDIDATO"
  | "PRONTO"
  | "DADOS_INSUFICIENTES";

export type SignalPhase =
  | "OBSERVANDO"
  | "CANDIDATO"
  | "CONFIRMACAO"
  | "SINAL_ATIVO"
  | "G0"
  | "G1"
  | "G2"
  | "GREEN"
  | "RED";

export type StrategyReason = {
  code: string;
  text: string;
};

export type RankedCandidate = {
  number: number;
  score: number;
  votes: StrategyId[];
};

export type StrategyOutput = {
  strategy: StrategyId;
  candidates: RankedCandidate[];
  score: number;
  reasons: StrategyReason[];
  window: number;
  timestamp: string;
  status: StrategyStatus;
  requiredSpins: number;
  availableSpins: number;
};

export type StrategyContribution = {
  strategy: StrategyId;
  score: number;
  weight: number;
  weighted: number;
  summary: string;
  candidates: number[];
};

export type ConsensusOutput = {
  ranking: RankedCandidate[];
  score: number;
  consensus: number;
  consensusTotal: number;
  reasons: StrategyReason[];
  contributions: StrategyContribution[];
  status: StrategyStatus;
  requiredSpins: number;
  availableSpins: number;
};

export type EngineSnapshot = {
  at: string;
  triggerSpinId: string | null;
  availableSpins: number;
  requiredSpins: number;
  insufficient: boolean;
  phase: SignalPhase;
  strategies: StrategyOutput[];
  consensus: ConsensusOutput;
};

export type ConfirmationState = {
  count: number;
  fingerprint: string;
  spinId: string;
} | null;

export type SignalEngineState = {
  signals: Signal[];
  confirmation: ConfirmationState;
  lastProcessedSpinId: string | null;
  lastResolvedSpinId: string | null;
};

export type StrategyContext = {
  spins: Spin[];
  history: number[];
  window: number;
  timestamp: string;
};
