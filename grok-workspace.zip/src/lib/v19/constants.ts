export const APP_NOME = "RÉGIS CUNHA ROLETA";
export const APP_VERSAO = "v19.0";

export const TIMEOUT_SEM_LEITURA = 180;
export const MAX_ENTRADAS_HISTORICO = 300;
export const MAX_PONTOS_GRAFICO = 60;

export const RODA_EUROPEIA = [
  0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7,
  28, 12, 35, 3, 26,
] as const;

export const VERMELHOS = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);

export const SETORES_FISICOS: Record<"P1" | "P2" | "P3", number[]> = {
  P1: [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27],
  P2: [13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1],
  P3: [20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26],
};

export const TERMINAIS_MAP: Record<string, string[]> = {
  T0: ["0", "10", "20", "30"],
  T1: ["1", "11", "21", "31"],
  T2: ["2", "12", "22", "32"],
  T3: ["3", "13", "23", "33"],
  T4: ["4", "14", "24", "34"],
  T5: ["5", "15", "25", "35"],
  T6: ["6", "16", "26", "36"],
  T7: ["7", "17", "27"],
  T8: ["8", "18", "28"],
  T9: ["9", "19", "29"],
};

export const TAGS_VALIDAS = new Set<string>([
  "R",
  "B",
  "D1",
  "D2",
  "D3",
  "C1",
  "C2",
  "C3",
  "P",
  "O",
  "L",
  "H",
  "N",
  "P1",
  "P2",
  "P3",
  "T0",
  "T1",
  "T2",
  "T3",
  "T4",
  "T5",
  "T6",
  "T7",
  "T8",
  "T9",
  ...Array.from({ length: 37 }, (_, i) => String(i)),
]);

export const DEFAULT_V19 = {
  amostra: 60,
  atrasoMin: 30,
  vizinhosSniper: 5,
  momentumMin: 3,
  minAssertividade: 80,
  maxGales: 2,
  termHits: 8,
  termViz: 1,
  cooldown: 5,
  fichaBase: 1,
  bancaInicial: 200,
  stopWin: 15,
  stopLoss: 25,
  maxReds: 2,
  profundidade: 250,
  multsGales: ["2x", "4x"] as string[],
  sniperEnabled: true,
  termoEnabled: true,
};

export type V19Defaults = typeof DEFAULT_V19;
export type PadraoFamilia = "DÚZIA" | "COLUNA" | "COR" | "PARIDADE" | "METADE" | "SETOR" | "TERMINAL" | "PLENO";
