import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { classificarNumero, expandirAlvos, limiteInferiorWilson, numerosCobertos, verificarGatilho, vizinhosRoda, obterVizinhosCilindro } from "./classify.ts";
import { minerarPadroesAoVivo } from "./quant.ts";
import { analisarNumerosPlenosSniper } from "./sniper.ts";
import { analisarTerminaisDinamicos } from "./termo.ts";
import { simularEstrategia } from "./backtest.ts";
import { raioXDaMesa } from "./raiox.ts";
import { fixtureHistory } from "./fixture.ts";
import { RODA_EUROPEIA } from "./constants.ts";

type Oracle = {
  tags_0: string[];
  tags_17: string[];
  tags_32: string[];
  expand_P1: string[];
  expand_T2: string[];
  vizinhos_17: string[];
  cobertos_T2: number;
  cobertos_D2D3: number;
  cobertos_P2P3: number;
  wilson_8_10: number;
  wilson_3_3: number;
  history: number[];
  mine_count: number;
  mined: Array<Record<string, unknown>>;
  sniper: Record<string, unknown> | null;
  termo: Record<string, unknown> | null;
  backtest_d3: Record<string, unknown>;
  raiox: Record<string, unknown>;
  gatilho_d3: boolean;
  gatilho_rr: boolean;
  roda: number[];
};

function loadOracle(): Oracle {
  const raw = execFileSync("python3", ["scripts/v19_reference.py", "dump"], {
    cwd: "/workspace",
    encoding: "utf8",
  });
  return JSON.parse(raw) as Oracle;
}

function close(actual: number, expected: number, eps = 1e-9) {
  assert.ok(Math.abs(actual - expected) < eps, `${actual} != ${expected}`);
}

describe("paridade v19.0 com o Python original", () => {
  const oracle = loadOracle();
  const hist = fixtureHistory(120);

  it("usa a mesma roda europeia", () => {
    assert.deepEqual([...RODA_EUROPEIA], oracle.roda);
  });

  it("classifica 0, 17 e 32 como o Python", () => {
    assert.deepEqual(classificarNumero(0), oracle.tags_0);
    assert.deepEqual(classificarNumero(17), oracle.tags_17);
    assert.deepEqual(classificarNumero(32), oracle.tags_32);
  });

  it("expande setores e terminais para números reais", () => {
    assert.deepEqual(expandirAlvos(["P1"]), oracle.expand_P1);
    assert.deepEqual(expandirAlvos(["T2"]), oracle.expand_T2);
    assert.equal(numerosCobertos(expandirAlvos(["T2"])), oracle.cobertos_T2);
    assert.equal(numerosCobertos(expandirAlvos(["D2", "D3"])), oracle.cobertos_D2D3);
    assert.equal(numerosCobertos(expandirAlvos(["P2", "P3"])), oracle.cobertos_P2P3);
  });

  it("vizinhos físicos do 17", () => {
    assert.deepEqual(vizinhosRoda(17, 2), oracle.vizinhos_17);
    assert.deepEqual(obterVizinhosCilindro(17, 5), [19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36]);
  });

  it("Wilson 95% em porcentagem", () => {
    close(limiteInferiorWilson(8, 10), oracle.wilson_8_10);
    close(limiteInferiorWilson(3, 3), oracle.wilson_3_3);
  });

  it("histórico de fixture idêntico", () => {
    assert.deepEqual(hist, oracle.history);
  });

  it("Quant Lab minera os mesmos candidatos", () => {
    const mined = minerarPadroesAoVivo(hist);
    assert.equal(mined.length, oracle.mine_count);
    const names = mined.map((item) => item.nome);
    assert.deepEqual(names, oracle.mined.map((item) => item.nome));
    mined.forEach((item, index) => {
      const expected = oracle.mined[index];
      assert.equal(item.familia, expected.familia);
      assert.equal(item.greens, expected.greens);
      assert.equal(item.reds, expected.reds);
      assert.equal(item.numeros_cobertos, expected.numeros_cobertos);
      assert.equal(item.max_drawdown, expected.max_drawdown);
      close(item.assertividade as number, expected.assertividade as number);
      close(item.confianca as number, expected.confianca as number);
      close(item.aleatorio as number, expected.aleatorio as number);
      close(item.vantagem as number, expected.vantagem as number);
      close(item.vantagem_conf as number, expected.vantagem_conf as number);
      close(item.score as number, expected.score as number);
    });
  });

  it("Sniper físico coincide", () => {
    const sniper = analisarNumerosPlenosSniper(hist);
    if (!oracle.sniper) {
      assert.equal(sniper, null);
      return;
    }
    assert.ok(sniper);
    assert.equal(sniper.nome, oracle.sniper.nome);
    assert.equal(sniper.alvo_central, oracle.sniper.alvo_central);
    assert.deepEqual(sniper.alvos, oracle.sniper.alvos);
    assert.equal(sniper.greens, oracle.sniper.greens);
    assert.equal(sniper.reds, oracle.sniper.reds);
    close(sniper.pct, oracle.sniper.pct as number);
  });

  it("Termo-física coincide", () => {
    const termo = analisarTerminaisDinamicos(hist);
    assert.deepEqual(termo, oracle.termo);
  });

  it("Backtest D3 → T1 T2 T3 coincide", () => {
    const result = simularEstrategia(hist, ["D3"], expandirAlvos(["T1", "T2", "T3"]), 2);
    assert.equal(result.total_entradas, oracle.backtest_d3.total_entradas);
    assert.equal(result.greens, oracle.backtest_d3.greens);
    assert.equal(result.reds, oracle.backtest_d3.reds);
    assert.equal(result.max_drawdown, oracle.backtest_d3.max_drawdown);
    close(result.assertividade, oracle.backtest_d3.assertividade as number);
    assert.deepEqual(result.alvos, oracle.backtest_d3.alvos);
  });

  it("Raio-X da mesa coincide", () => {
    const raio = raioXDaMesa(hist, 60);
    assert.ok(raio);
    assert.equal(raio.total, oracle.raiox.total);
    // Top 3 have unique counts and must match. Remaining ties of count=2 follow
    // first-seen order here; CPython set() iteration order can differ on ties.
    const expectedPlenos = oracle.raiox.plenos as { n: number; c: number }[];
    assert.deepEqual(raio.plenos.slice(0, 3), expectedPlenos.slice(0, 3));
    assert.equal(raio.plenos[3]?.c, expectedPlenos[3]?.c);
    assert.equal(raio.plenos[4]?.c, expectedPlenos[4]?.c);
    assert.deepEqual(raio.terminais, oracle.raiox.terminais);
    close(raio.vermelho, oracle.raiox.vermelho as number);
    close(raio.preto, oracle.raiox.preto as number);
    close(raio.zero, oracle.raiox.zero as number);
    close(raio.d1, oracle.raiox.d1 as number);
    close(raio.d2, oracle.raiox.d2 as number);
    close(raio.d3, oracle.raiox.d3 as number);
    close(raio.c1, oracle.raiox.c1 as number);
    close(raio.c2, oracle.raiox.c2 as number);
    close(raio.c3, oracle.raiox.c3 as number);
    close(raio.par, oracle.raiox.par as number);
    close(raio.impar, oracle.raiox.impar as number);
  });

  it("gatilho D3 / RR", () => {
    const tags = hist.map(classificarNumero);
    assert.equal(verificarGatilho(tags, { gatilho: ["D3"], ausencia: false }), oracle.gatilho_d3);
    assert.equal(verificarGatilho(tags, { gatilho: ["R", "R"], ausencia: false }), oracle.gatilho_rr);
  });
});
