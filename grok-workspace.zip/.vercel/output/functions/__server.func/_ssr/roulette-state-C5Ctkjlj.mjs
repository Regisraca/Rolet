import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { n as TABLE_IDS } from "./tables-B8T2W11k.mjs";
import { i as object, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/roulette-state-C5Ctkjlj.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var InputSchema = object({ tableId: _enum(TABLE_IDS) });
var getRouletteState_createServerFn_handler = createServerRpc({
	id: "ca48d293587ef46f7dd4e127b388d189ed7c8ae1c737f14f9492b23f8bb5e65e",
	name: "getRouletteState",
	filename: "src/lib/roulette-state.ts"
}, (opts) => getRouletteState.__executeServer(opts));
var getRouletteState = createServerFn({ method: "GET" }).validator((data) => InputSchema.parse(data)).handler(getRouletteState_createServerFn_handler, async ({ data }) => {
	const { readTableState } = await import("./casinoscores.server-x4Gng8n4.mjs");
	return readTableState(data.tableId);
});
//#endregion
export { getRouletteState_createServerFn_handler };
