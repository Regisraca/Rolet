import { o as numberColor, r as computeWindowStats, t as WHEEL_ORDER } from "./roulette-DK-APDMj.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as useRoletaStore, n as cn, r as useLiveTable } from "./router-C1XRQaZK.mjs";
import { t as NumberOrb } from "./number-orb-CgSa4pVS.mjs";
import { t as WindowPills } from "./window-pills-CA79D6pe.mjs";
import { a as Cell, i as Bar, n as YAxis, o as ResponsiveContainer, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analysis-CH41Lvcc.js
var import_jsx_runtime = require_jsx_runtime();
var FILL = {
	green: "#1F8A5B",
	red: "#C4453C",
	black: "#1A2221"
};
function RouletteWheel({ lastNumber, targets = [], className }) {
	const size = 280;
	const cx = size / 2;
	const cy = size / 2;
	const outer = 132;
	const inner = 78;
	const count = WHEEL_ORDER.length;
	const targetSet = new Set(targets);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${size} ${size}`,
		className: cn("mx-auto size-full max-w-[280px]", className),
		role: "img",
		"aria-label": "Roda europeia",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx,
				cy,
				r: 138,
				fill: "#0e1413",
				stroke: "#2a3937",
				strokeWidth: "2"
			}),
			WHEEL_ORDER.map((number, index) => {
				const start = index / count * Math.PI * 2 - Math.PI / 2;
				const end = (index + 1) / count * Math.PI * 2 - Math.PI / 2;
				const large = 0;
				const x1 = cx + Math.cos(start) * outer;
				const y1 = cy + Math.sin(start) * outer;
				const x2 = cx + Math.cos(end) * outer;
				const y2 = cy + Math.sin(end) * outer;
				const ix1 = cx + Math.cos(end) * inner;
				const iy1 = cy + Math.sin(end) * inner;
				const ix2 = cx + Math.cos(start) * inner;
				const iy2 = cy + Math.sin(start) * inner;
				const mid = start + (end - start) / 2;
				const tx = cx + Math.cos(mid) * 105;
				const ty = cy + Math.sin(mid) * 105;
				const isLast = number === lastNumber;
				const isTarget = targetSet.has(number);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: `M ${x1} ${y1} A ${outer} ${outer} 0 ${large} 1 ${x2} ${y2} L ${ix1} ${iy1} A ${inner} ${inner} 0 ${large} 0 ${ix2} ${iy2} Z`,
					fill: FILL[numberColor(number)],
					stroke: isLast ? "#90D6CA" : isTarget ? "#F06C61" : "#111717",
					strokeWidth: isLast || isTarget ? 2.2 : .6
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: tx,
					y: ty,
					textAnchor: "middle",
					dominantBaseline: "middle",
					fill: "#F4F7F7",
					fontSize: isLast ? 9.5 : 8,
					fontWeight: isLast ? 700 : 500,
					fontFamily: "IBM Plex Sans, sans-serif",
					children: number
				})] }, number);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx,
				cy,
				r: 70,
				fill: "#161e1d",
				stroke: "#2a3937"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: cx,
				y: 132,
				textAnchor: "middle",
				fill: "#91A29F",
				fontSize: "9",
				letterSpacing: "1.6",
				fontFamily: "IBM Plex Sans, sans-serif",
				children: "ÚLTIMO"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: cx,
				y: 156,
				textAnchor: "middle",
				fill: "#F4F7F7",
				fontSize: "28",
				fontWeight: "600",
				fontFamily: "Syne, sans-serif",
				children: lastNumber ?? "—"
			})
		]
	});
}
function Meter({ label, value, total, tone }) {
	const pct = total === 0 ? 0 : Math.round(value / total * 100);
	const fill = {
		red: "bg-pocket-red",
		black: "bg-muted",
		green: "bg-pocket-green",
		teal: "bg-accent",
		blue: "bg-blue",
		coral: "bg-coral"
	}[tone];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1.5 flex items-baseline justify-between text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-medium tabular",
			children: [
				value,
				" · ",
				pct,
				"%"
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 overflow-hidden rounded-full bg-surface-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `h-full rounded-full ${fill}`,
			style: { width: `${pct}%` }
		})
	})] });
}
function AnalysisPage() {
	const { spins, currentSignal, analysisWindow } = useLiveTable();
	const setAnalysisWindow = useRoletaStore((state) => state.setAnalysisWindow);
	const stats = computeWindowStats(spins, analysisWindow);
	const last = spins[0]?.number;
	const chartData = stats.terminals.map((item) => ({
		name: `T${item.terminal}`,
		count: item.count
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] font-semibold tracking-[0.16em] text-subtle uppercase",
				children: "Distribuição"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-1 text-2xl font-semibold tracking-tight",
				children: "Análise"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WindowPills, {
				value: analysisWindow,
				onChange: (value) => setAnalysisWindow(value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RouletteWheel, {
					lastNumber: last,
					targets: currentSignal?.targets ?? []
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-xs text-subtle",
					children: "Contorno teal = último giro. Contorno coral = alvos do sinal ativo."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Cor e paridade"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Vermelho",
								value: stats.red,
								total: stats.total,
								tone: "red"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Preto",
								value: stats.black,
								total: stats.total,
								tone: "black"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Zero",
								value: stats.green,
								total: stats.total,
								tone: "green"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Par",
								value: stats.even,
								total: stats.total,
								tone: "teal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Ímpar",
								value: stats.odd,
								total: stats.total,
								tone: "blue"
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Dúzias e colunas"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Dúzia 1",
								value: stats.dozens[0],
								total: stats.total,
								tone: "teal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Dúzia 2",
								value: stats.dozens[1],
								total: stats.total,
								tone: "blue"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Dúzia 3",
								value: stats.dozens[2],
								total: stats.total,
								tone: "coral"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Coluna 1",
								value: stats.columns[0],
								total: stats.total,
								tone: "teal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Coluna 2",
								value: stats.columns[1],
								total: stats.total,
								tone: "blue"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
								label: "Coluna 3",
								value: stats.columns[2],
								total: stats.total,
								tone: "coral"
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Quentes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: stats.hot.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Sem amostra ainda."
						}) : stats.hot.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberOrb, {
								number: item.number,
								size: "sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[10px] text-subtle tabular",
								children: [item.count, "x"]
							})]
						}, item.number))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Frios"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: stats.cold.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Sem amostra ainda."
						}) : stats.cold.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberOrb, {
								number: item.number,
								size: "sm",
								dim: item.count === 0
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[10px] text-subtle tabular",
								children: [item.count, "x"]
							})]
						}, item.number))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Terminais"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-40",
					children: stats.total === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-10 text-center text-sm text-muted",
						children: "Aguardando giros para montar o gráfico."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: chartData,
							barCategoryGap: 8,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "name",
									tick: {
										fill: "#91A29F",
										fontSize: 11
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "count",
									radius: [
										6,
										6,
										0,
										0
									],
									children: chartData.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: "#90D6CA" }, entry.name))
								})
							]
						})
					})
				})]
			})
		]
	});
}
//#endregion
export { AnalysisPage as component };
