//#region node_modules/.nitro/vite/services/ssr/assets/tables-B8T2W11k.js
var TABLE_IDS = [
	"auto-roulette",
	"immersive-roulette",
	"mega-fire-blaze",
	"mega-roulette"
];
var TABLES = {
	"auto-roulette": {
		id: "auto-roulette",
		label: "Auto Roulette",
		shortLabel: "Auto",
		provider: "evolution",
		providerLabel: "Evolution",
		apiPath: "autoroulette",
		duration: 1,
		pageUrl: "https://www.casino.org/casinoscores/pt-br/auto-roulette/",
		description: "Roleta automática da Evolution. Giro rápido, histórico estável."
	},
	"immersive-roulette": {
		id: "immersive-roulette",
		label: "Immersive Roulette",
		shortLabel: "Immersive",
		provider: "evolution",
		providerLabel: "Evolution",
		apiPath: "immersiveroulette",
		duration: 1,
		pageUrl: "https://www.casino.org/casinoscores/pt-br/immersive-roulette/",
		description: "Mesa imersiva da Evolution, com dealer ao vivo."
	},
	"mega-fire-blaze": {
		id: "mega-fire-blaze",
		label: "Mega Fire Blaze",
		shortLabel: "Fire Blaze",
		provider: "playtech",
		providerLabel: "Playtech",
		apiPath: "megafireblazeroulette",
		duration: 30,
		pageUrl: "https://www.casino.org/casinoscores/pt-br/mega-fire-blaze-roulette/",
		description: "Playtech com números sortudos e Super Boost."
	},
	"mega-roulette": {
		id: "mega-roulette",
		label: "Mega Roulette",
		shortLabel: "Mega",
		provider: "pragmatic",
		providerLabel: "Pragmatic",
		apiPath: "megaroulette",
		duration: 1,
		pageUrl: "https://www.casino.org/casinoscores/pt-br/mega-roulette/",
		description: "Pragmatic Play com multiplicadores nos números sortudos."
	}
};
var TABLE_LIST = TABLE_IDS.map((id) => TABLES[id]);
function isTableId(value) {
	return TABLE_IDS.includes(value);
}
//#endregion
export { isTableId as i, TABLE_IDS as n, TABLE_LIST as r, TABLES as t };
