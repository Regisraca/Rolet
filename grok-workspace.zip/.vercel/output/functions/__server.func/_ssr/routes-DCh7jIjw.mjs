import "../_runtime.mjs";
import { a as isRed, i as formatRelativeTime } from "./roulette-DK-APDMj.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Slot } from "../_libs/@radix-ui/react-popper+[...].mjs";
import { a as Radio, i as RefreshCw, o as Info, u as CirclePause } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { i as useRoletaStore, n as cn, r as useLiveTable } from "./router-C1XRQaZK.mjs";
import { t as NumberOrb } from "./number-orb-CgSa4pVS.mjs";
import { t as WindowPills } from "./window-pills-CA79D6pe.mjs";
import { t as SignalCard } from "./signal-card-BgSSFZU8.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-[var(--radius-md)] text-sm font-medium transition-[opacity,transform,background-color,border-color] duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-45 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:opacity-92",
			accent: "bg-accent text-accent-fg hover:opacity-92",
			outline: "border border-border bg-transparent text-fg hover:bg-surface-2",
			ghost: "text-muted hover:bg-surface-2 hover:text-fg",
			coral: "bg-coral text-primary-fg hover:opacity-92"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Home() {
	const { spins, source, currentSignal, analysisWindow, isFetching, refresh } = useLiveTable();
	const setAnalysisWindow = useRoletaStore((state) => state.setAnalysisWindow);
	const lastSpin = spins[0];
	const recent = spins.slice(0, 10);
	const redCount = spins.slice(0, analysisWindow).filter((spin) => isRed(spin.number)).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			source.status === "error" || source.status === "unavailable" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3 rounded-[var(--radius-lg)] border border-danger/40 bg-danger/8 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "mt-0.5 size-4 text-danger" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-danger",
					children: "Fonte de resultados indisponível"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: source.message
				})] })]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WindowPills, {
				value: analysisWindow,
				onChange: (value) => setAnalysisWindow(value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[var(--radius-xl)] border border-border bg-surface p-5 shadow-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-semibold tracking-[0.16em] text-subtle uppercase",
							children: "Último resultado"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: lastSpin ? formatRelativeTime(lastSpin.createdAt) : "aguardando fonte"
						})] }), lastSpin?.multiplier ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-coral/15 px-2.5 py-1 text-[10px] font-semibold tracking-[0.12em] text-coral uppercase",
							children: ["x", lastSpin.multiplier]
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex items-center gap-4",
						children: [lastSpin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberOrb, {
							number: lastSpin.number,
							size: "xl"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-[88px] w-[88px] items-center justify-center rounded-[28px] bg-surface-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-7 text-muted" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl font-semibold tracking-tight",
									children: lastSpin ? `Número ${lastSpin.number}` : "Aguardando resultado"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: lastSpin ? lastSpin.number === 0 ? "Zero · verde" : `${isRed(lastSpin.number) ? "Vermelho" : "Preto"} · ${lastSpin.number % 2 === 0 ? "par" : "ímpar"}` : "O próximo giro autorizado aparece aqui."
								}),
								lastSpin?.luckyNumbers.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs text-subtle",
									children: ["Sortudos ", lastSpin.luckyNumbers.map((item) => item.number).join(" · ")]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs font-medium text-accent",
									children: source.status === "online" ? "Leitura atualizada" : source.message
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-wrap items-end justify-between gap-4 border-t border-border pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-semibold tracking-[0.12em] text-subtle uppercase",
								children: "Giros lidos"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-xl font-semibold tabular",
								children: spins.length
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[10px] font-semibold tracking-[0.12em] text-subtle uppercase",
								children: ["Vermelhos / ", analysisWindow]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-xl font-semibold tabular",
								children: redCount
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								onClick: () => void refresh(),
								disabled: isFetching,
								className: "ml-auto",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: isFetching ? "size-3.5 animate-spin" : "size-3.5" }), "Atualizar"]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold tracking-tight",
						children: "Sinal em foco"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/history",
						className: "text-sm text-accent hover:opacity-80",
						children: "Ver histórico"
					})]
				}), currentSignal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalCard, { signal: currentSignal }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-[92px] items-center gap-3 rounded-[var(--radius-xl)] border border-border bg-surface px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-11 items-center justify-center rounded-[14px] bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePause, { className: "size-5 text-muted" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold tracking-[0.08em] uppercase",
						children: "Sem sinal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Condições insuficientes. Aguardando nova sequência."
					})] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold tracking-tight",
						children: "Últimos giros"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/history",
						className: "text-sm text-accent hover:opacity-80",
						children: "Abrir lista"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-[var(--radius-xl)] border border-border bg-surface p-4",
					children: recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-6 text-center text-sm text-muted",
						children: "Os resultados aparecem assim que a mesa responder."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 overflow-x-auto pb-1",
						children: recent.map((spin) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-12 flex-col items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberOrb, { number: spin.number }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-subtle",
								children: formatRelativeTime(spin.createdAt)
							})]
						}, spin.id))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex gap-2 text-xs leading-5 text-subtle",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "mt-0.5 size-3.5 shrink-0 text-warn" }), "Análises estatísticas não garantem resultados. Use o app apenas para leitura de dados. Jogue com responsabilidade."]
			})
		]
	});
}
//#endregion
export { Home as component };
