import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as ChartColumn, f as Activity, l as Crosshair } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn } from "./router-C1XRQaZK.mjs";
import { t as NumberOrb } from "./number-orb-CgSa4pVS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/signal-card-BgSSFZU8.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-semibold tracking-[0.08em] uppercase", {
	variants: { tone: {
		muted: "bg-surface-2 text-muted",
		accent: "bg-accent/15 text-accent",
		coral: "bg-coral/15 text-coral",
		teal: "bg-teal/15 text-teal",
		blue: "bg-blue/15 text-blue",
		warn: "bg-warn/15 text-warn",
		danger: "bg-danger/15 text-danger"
	} },
	defaultVariants: { tone: "muted" }
});
function Badge({ className, tone, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ tone }), className),
		...props
	});
}
var toneMeta = {
	coral: {
		badge: "coral",
		icon: Crosshair
	},
	teal: {
		badge: "teal",
		icon: Activity
	},
	blue: {
		badge: "blue",
		icon: ChartColumn
	}
};
function SignalBadge({ signal, compact = false }) {
	const meta = toneMeta[signal.tone];
	const Icon = meta.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
		tone: meta.badge,
		className: compact ? "px-2 py-0.5" : void 0,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: compact ? "size-3" : "size-3.5",
			strokeWidth: 2
		}), signal.type]
	});
}
function TargetPills({ targets, limit = 7, highlight }) {
	const visible = targets.slice(0, limit);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap gap-1.5",
		children: [visible.map((target) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberOrb, {
			number: target,
			size: "sm",
			active: target === highlight
		}, target)), targets.length > limit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex h-8 min-w-8 items-center justify-center rounded-[10px] bg-surface-2 px-2 text-xs text-muted",
			children: ["+", targets.length - limit]
		}) : null]
	});
}
function SignalCard({ signal, compact = false }) {
	const resultTone = signal.result === "GREEN" ? "text-teal" : signal.result === "RED" ? "text-danger" : "text-warn";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("rounded-[var(--radius-xl)] border border-border bg-surface-2 p-4 shadow-panel", compact && "p-3.5"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalBadge, {
					signal,
					compact
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("text-[10px] font-semibold tracking-[0.12em] uppercase", resultTone),
					children: signal.result === "PENDING" ? "Sinal detectado" : signal.result
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display mt-3 text-lg font-semibold tracking-tight text-fg",
				children: signal.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: signal.trigger
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TargetPills, {
					targets: signal.targets,
					limit: compact ? 5 : 8,
					highlight: signal.resolvedNumber
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 grid grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[10px] font-semibold tracking-[0.12em] text-subtle uppercase",
						children: "Confiança"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 font-display text-lg font-semibold text-teal tabular",
						children: [signal.confidence, "%"]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[10px] font-semibold tracking-[0.12em] text-subtle uppercase",
						children: "Greens"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 font-display text-lg font-semibold tabular",
						children: [signal.greens, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm text-muted",
							children: [" / ", signal.greens + signal.reds]
						})]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[10px] font-semibold tracking-[0.12em] text-subtle uppercase",
						children: "Gale"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 font-display text-lg font-semibold tabular",
						children: ["G0–G", signal.maxGales]
					})] })
				]
			})
		]
	});
}
//#endregion
export { SignalCard as t };
