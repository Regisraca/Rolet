import { i as formatRelativeTime, o as numberColor } from "./roulette-DK-APDMj.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { s as Inbox } from "../_libs/lucide-react.mjs";
import { r as useLiveTable } from "./router-C1XRQaZK.mjs";
import { t as NumberOrb } from "./number-orb-CgSa4pVS.mjs";
import { t as SignalCard } from "./signal-card-BgSSFZU8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/history-DwtmFRSx.js
var import_jsx_runtime = require_jsx_runtime();
function HistoryPage() {
	const { spins, signals, source } = useLiveTable();
	const colorLabel = (number) => {
		const tone = numberColor(number);
		if (tone === "green") return "Verde";
		if (tone === "red") return "Vermelho";
		return "Preto";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] font-semibold tracking-[0.16em] text-subtle uppercase",
				children: "Dados da mesa"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-1 text-2xl font-semibold tracking-tight",
				children: "Histórico"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-3 gap-3 rounded-[var(--radius-xl)] border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] font-semibold tracking-[0.1em] text-subtle uppercase",
						children: "Capturado"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-2xl font-semibold tabular",
						children: spins.length
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] font-semibold tracking-[0.1em] text-subtle uppercase",
						children: "Sinais"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-2xl font-semibold text-teal tabular",
						children: signals.length
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] font-semibold tracking-[0.1em] text-subtle uppercase",
						children: "Status"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm font-medium",
						children: source.status === "online" ? "Online" : source.status === "connecting" ? "Conectando" : "Indisponível"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs leading-5 text-muted",
				children: [
					source.origin,
					" · ",
					source.message
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-semibold",
					children: "Sinais recentes"
				}), signals.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-[var(--radius-lg)] border border-border bg-surface px-4 py-5 text-sm text-muted",
					children: "Nenhum sinal gerado nesta sessão da mesa."
				}) : signals.map((signal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalCard, {
					signal,
					compact: true
				}, signal.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-semibold",
					children: "Giros recentes"
				}), spins.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-2 py-12 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "size-7 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: "Nenhum giro capturado"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-xs text-sm text-muted",
							children: "Os resultados aparecem aqui assim que a mesa for monitorada."
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border rounded-[var(--radius-xl)] border border-border bg-surface",
					children: spins.slice(0, 80).map((spin) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex min-h-[68px] items-center gap-3 px-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberOrb, { number: spin.number }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-medium",
									children: ["Resultado ", spin.number]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										formatRelativeTime(spin.createdAt),
										" · ",
										colorLabel(spin.number),
										spin.multiplier ? ` · x${spin.multiplier}` : ""
									]
								})]
							}),
							spin.totalWinners ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[11px] text-subtle tabular",
								children: [spin.totalWinners, " ganhadores"]
							}) : null
						]
					}, spin.id))
				})]
			})
		]
	});
}
//#endregion
export { HistoryPage as component };
