import { o as numberColor } from "./roulette-DK-APDMj.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as cn } from "./router-C1XRQaZK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/number-orb-CgSa4pVS.js
var import_jsx_runtime = require_jsx_runtime();
var toneClass = {
	green: "bg-pocket-green text-fg",
	red: "bg-pocket-red text-fg",
	black: "bg-pocket-black text-fg ring-1 ring-border-strong"
};
function NumberOrb({ number, size = "md", dim = false, active = false, className }) {
	const tone = numberColor(number);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center justify-center font-display font-semibold tabular leading-none", toneClass[tone], size === "sm" && "size-8 rounded-[10px] text-xs", size === "md" && "size-10 rounded-[12px] text-sm", size === "lg" && "size-14 rounded-[16px] text-xl", size === "xl" && "h-[88px] w-[88px] rounded-[28px] text-4xl tracking-tight", dim && "opacity-40", active && "ring-2 ring-accent", className),
		children: number
	});
}
//#endregion
export { NumberOrb as t };
