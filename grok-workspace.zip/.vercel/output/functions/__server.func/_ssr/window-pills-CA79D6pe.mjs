import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as cn } from "./router-C1XRQaZK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/window-pills-CA79D6pe.js
var import_jsx_runtime = require_jsx_runtime();
var WINDOWS = [
	20,
	50,
	100
];
function WindowPills({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-semibold tracking-[0.14em] text-subtle uppercase",
			children: "Janela de análise"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-1 rounded-[var(--radius-md)] bg-surface-2 p-1",
			children: WINDOWS.map((window) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(window),
				className: cn("min-h-9 min-w-11 rounded-[8px] px-2.5 text-xs font-semibold tabular transition-colors", value === window ? "bg-surface text-fg" : "text-muted hover:text-fg"),
				children: window
			}, window))
		})]
	});
}
//#endregion
export { WindowPills as t };
