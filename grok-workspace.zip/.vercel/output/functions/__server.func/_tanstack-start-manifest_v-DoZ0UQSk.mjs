//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DoZ0UQSk.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/analysis",
			"/history",
			"/settings"
		],
		preloads: [
			"/assets/index-DXbpqbxl.js",
			"/assets/utils-Be07lAIr.js",
			"/assets/crosshair-CFjJt2fY.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DXbpqbxl.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BKKLun2A.js",
			"/assets/signal-card-DYglhcxV.js",
			"/assets/number-orb-CjjEScIb.js",
			"/assets/window-pills-CrBb-opP.js"
		]
	},
	"/analysis": {
		filePath: "/workspace/src/routes/analysis.tsx",
		children: void 0,
		preloads: [
			"/assets/analysis-B4NNIMpB.js",
			"/assets/number-orb-CjjEScIb.js",
			"/assets/window-pills-CrBb-opP.js"
		]
	},
	"/history": {
		filePath: "/workspace/src/routes/history.tsx",
		children: void 0,
		preloads: [
			"/assets/history-BF3B_7t7.js",
			"/assets/signal-card-DYglhcxV.js",
			"/assets/number-orb-CjjEScIb.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-Cwi4FrDM.js"]
	}
} });
//#endregion
export { tsrStartManifest };
