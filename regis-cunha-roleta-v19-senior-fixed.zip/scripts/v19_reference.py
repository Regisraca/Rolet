#!/usr/bin/env python3
"""Pure-function extract of RÉGIS CUNHA ROLETA v19.0 — used as the parity oracle."""
from __future__ import annotations

import json
import math
import sys

APP_NOME = "RÉGIS CUNHA ROLETA"
APP_VERSAO = "v19.0"

VERMELHOS = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}

SETORES_FISICOS = {
    "P1": {0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27},
    "P2": {13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1},
    "P3": {20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26},
}

TERMINAIS_MAP = {
    "T0": ["0", "10", "20", "30"],
    "T1": ["1", "11", "21", "31"],
    "T2": ["2", "12", "22", "32"],
    "T3": ["3", "13", "23", "33"],
    "T4": ["4", "14", "24", "34"],
    "T5": ["5", "15", "25", "35"],
    "T6": ["6", "16", "26", "36"],
    "T7": ["7", "17", "27"],
    "T8": ["8", "18", "28"],
    "T9": ["9", "19", "29"],
}

NUMEROS_POR_TAG: dict[str, set[int]] = {}

RODA_EUROPEIA = [
    0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24,
    16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26,
]


def classificar_numero(num):
    tags = [str(num)]
    if num == 0:
        tags.extend(["T0", "P1"])
    else:
        if 1 <= num <= 12:
            tags.append("D1")
        elif 13 <= num <= 24:
            tags.append("D2")
        elif 25 <= num <= 36:
            tags.append("D3")
        if num % 3 == 1:
            tags.append("C1")
        elif num % 3 == 2:
            tags.append("C2")
        elif num % 3 == 0:
            tags.append("C3")
        tags.append("L" if 1 <= num <= 18 else "H")
        tags.append("P" if num % 2 == 0 else "O")
        tags.append("R" if num in VERMELHOS else "B")
        tags.append(f"T{num % 10}")

    for setor, numeros in SETORES_FISICOS.items():
        if num in numeros:
            tags.append(setor)
            break

    return tags


def expandir_alvos(alvos):
    expandidos = []
    for alvo in alvos:
        alvo = str(alvo)
        if alvo in SETORES_FISICOS:
            expandidos.extend(str(n) for n in sorted(SETORES_FISICOS[alvo]))
        elif alvo in TERMINAIS_MAP:
            expandidos.extend(TERMINAIS_MAP[alvo])
        else:
            expandidos.append(alvo)
    return list(dict.fromkeys(expandidos))


def vizinhos_roda(numero, raio=2):
    try:
        pos = RODA_EUROPEIA.index(int(numero))
    except ValueError:
        return [str(numero)]
    total = len(RODA_EUROPEIA)
    return [str(RODA_EUROPEIA[(pos + d) % total]) for d in range(-raio, raio + 1)]


def obter_vizinhos_cilindro(num, qtd):
    idx = RODA_EUROPEIA.index(num)
    tamanho = len(RODA_EUROPEIA)
    vizinhos = []
    for i in range(-qtd, qtd + 1):
        viz_idx = (idx + i) % tamanho
        vizinhos.append(RODA_EUROPEIA[viz_idx])
    return vizinhos


def numeros_cobertos(alvos_expandidos):
    if not NUMEROS_POR_TAG:
        for n in range(37):
            for tag in classificar_numero(n):
                NUMEROS_POR_TAG.setdefault(tag, set()).add(n)
    casas = set()
    for alvo in alvos_expandidos:
        casas.update(NUMEROS_POR_TAG.get(str(alvo), set()))
    return len(casas)


def limite_inferior_wilson(greens, total):
    if total <= 0:
        return 0.0
    z = 1.96
    p = greens / total
    denominador = 1 + (z ** 2) / total
    centro = p + (z ** 2) / (2 * total)
    margem = z * math.sqrt((p * (1 - p) + (z ** 2) / (4 * total)) / total)
    return max(0.0, (centro - margem) / denominador) * 100


def verificar_gatilho(historico_rodadas, est):
    alvo_gatilho = est["gatilho"]
    is_ausencia = est.get("ausencia", False)

    if not is_ausencia:
        if not historico_rodadas:
            return False
        if len(alvo_gatilho) == 1:
            elemento_esperado = alvo_gatilho[0]
            if elemento_esperado == "N":
                return True
            return elemento_esperado in historico_rodadas[-1]

        tam_gatilho = len(alvo_gatilho)
        if len(historico_rodadas) < tam_gatilho:
            return False
        sub_historico = historico_rodadas[-tam_gatilho:]
        for registro_rodada, elemento_esperado in zip(sub_historico, alvo_gatilho):
            if elemento_esperado == "N":
                continue
            if elemento_esperado not in registro_rodada:
                return False
        return True

    try:
        limite_ausencia = int(alvo_gatilho[1])
    except (ValueError, IndexError):
        limite_ausencia = 5

    tag_alvo = est["tag_ausencia"]
    contador = 0
    for rodada in reversed(historico_rodadas):
        if tag_alvo in rodada:
            break
        contador += 1
    return contador >= limite_ausencia


def gerar_catalogo_padroes(historico_nums):
    catalogo = []
    familias = [
        ("DÚZIA", ["D1", "D2", "D3"], {"D1": "1ª Dúzia", "D2": "2ª Dúzia", "D3": "3ª Dúzia"}),
        ("COLUNA", ["C1", "C2", "C3"], {"C1": "Coluna 1", "C2": "Coluna 2", "C3": "Coluna 3"}),
        ("COR", ["R", "B"], {"R": "Vermelho", "B": "Preto"}),
        ("PARIDADE", ["P", "O"], {"P": "Par", "O": "Ímpar"}),
        ("METADE", ["L", "H"], {"L": "Baixas 1-18", "H": "Altas 19-36"}),
        ("SETOR", ["P1", "P2", "P3"], {"P1": "Setor 1", "P2": "Setor 2", "P3": "Setor 3"}),
    ]

    for familia, tags, rotulos in familias:
        for tag in tags:
            complementares = [t for t in tags if t != tag]
            for repeticoes in (2, 3):
                gatilho = [tag] * repeticoes
                catalogo.append((
                    gatilho, complementares,
                    f"Quebra {repeticoes}x {rotulos[tag]} ➔ {'/'.join(rotulos[c] for c in complementares)}",
                    familia,
                ))
                catalogo.append((
                    gatilho, [tag],
                    f"Tendência {repeticoes}x {rotulos[tag]} ➔ {rotulos[tag]}",
                    familia,
                ))

    for d in range(10):
        tag = f"T{d}"
        vizinhos = [f"T{(d + 1) % 10}", f"T{(d - 1) % 10}"]
        catalogo.append(([tag], [tag], f"Puxada Terminal {d} ➔ T{d}", "TERMINAL"))
        catalogo.append(([tag], vizinhos, f"Terminal {d} ➔ vizinhos {vizinhos[0]}/{vizinhos[1]}", "TERMINAL"))
        catalogo.append(([tag, tag], [tag] + vizinhos, f"Terminal {d} 2x ➔ cluster T{d}", "TERMINAL"))

    amostra = historico_nums[-120:]
    contagem = {}
    for n in amostra:
        contagem[n] = contagem.get(n, 0) + 1
    quentes = [n for n, c in sorted(contagem.items(), key=lambda x: x[1], reverse=True)[:6] if c >= 2]

    for num in quentes:
        catalogo.append((
            [str(num)], [str(num)],
            f"Repetição do Pleno {num}", "PLENO",
        ))
        catalogo.append((
            [str(num)], vizinhos_roda(num, raio=2),
            f"Pleno {num} ➔ vizinhos físicos (5 fichas)", "PLENO",
        ))
        catalogo.append((
            [str(num)], [f"T{num % 10}"],
            f"Pleno {num} ➔ Terminal {num % 10}", "PLENO",
        ))

    return catalogo


def simular_padrao(historico_tags, gatilho_seq, alvos_expandidos, max_gales):
    greens = 0
    reds = 0
    max_drawdown = 0
    drawdown_atual = 0
    alvos = set(alvos_expandidos)

    tamanho = len(gatilho_seq)
    i = tamanho
    total = len(historico_tags)

    while i < total:
        sub_hist = historico_tags[i - tamanho:i]
        if all(g in sub_hist[idx] for idx, g in enumerate(gatilho_seq)):
            acertou = False
            gale_usado = 0
            for g in range(max_gales + 1):
                if i + g >= total:
                    break
                gale_usado = g
                if alvos.intersection(historico_tags[i + g]):
                    acertou = True
                    break

            if acertou:
                greens += 1
                drawdown_atual = 0
            else:
                reds += 1
                drawdown_atual += 1
                max_drawdown = max(max_drawdown, drawdown_atual)

            i += (gale_usado + 1)
        else:
            i += 1

    return greens, reds, max_drawdown


def minerar_padroes_ao_vivo(historico_nums, max_gales=2):
    if len(historico_nums) < 20:
        return []

    historico_tags = [classificar_numero(num) for num in historico_nums]
    candidatos = []

    for gatilho_seq, alvos_seq, nome_padrao, familia in gerar_catalogo_padroes(historico_nums):
        alvos_expandidos = expandir_alvos(alvos_seq)
        cobertura = len(alvos_expandidos)
        cobertos = numeros_cobertos(alvos_expandidos)
        if cobertos > 24:
            continue

        greens, reds, max_drawdown = simular_padrao(
            historico_tags, gatilho_seq, alvos_expandidos, max_gales
        )
        operacoes = greens + reds
        if operacoes < (4 if familia == "PLENO" else 6):
            continue

        assertividade = greens / operacoes * 100
        confianca = limite_inferior_wilson(greens, operacoes)
        aleatorio = (1 - ((37 - cobertos) / 37) ** (max_gales + 1)) * 100
        vantagem = assertividade - aleatorio
        vantagem_conf = confianca - aleatorio
        score = vantagem_conf - (max_drawdown * 4)
        if vantagem < 5 or vantagem_conf <= 0:
            continue

        candidatos.append({
            "nome": nome_padrao,
            "familia": familia,
            "gatilho": list(gatilho_seq),
            "alvos": list(alvos_seq),
            "alvos_expandidos": alvos_expandidos,
            "cobertura": cobertura,
            "numeros_cobertos": cobertos,
            "greens": greens,
            "reds": reds,
            "total_entradas": operacoes,
            "assertividade": assertividade,
            "confianca": confianca,
            "aleatorio": aleatorio,
            "vantagem": vantagem,
            "vantagem_conf": vantagem_conf,
            "max_drawdown": max_drawdown,
            "score": score,
            "max_gales": max_gales,
        })

    for meta_assertividade, meta_drawdown in ((85, 1), (85, 2), (78, 2), (70, 3)):
        selecionados = [
            c for c in candidatos
            if c["assertividade"] >= meta_assertividade and c["max_drawdown"] <= meta_drawdown
        ]
        if selecionados:
            selecionados.sort(key=lambda x: x["score"], reverse=True)
            return selecionados[:12]

    return []


def simular_estrategia(historico, gatilho_list, alvos_expandidos, max_gales):
    greens = 0
    reds = 0
    total_entradas = 0
    max_drawdown = 0
    drawdown_atual = 0

    historico_tags = [classificar_numero(num) for num in historico]
    tamanho_gatilho = len(gatilho_list)
    i = tamanho_gatilho

    while i < len(historico_tags):
        match = True
        if i >= tamanho_gatilho:
            sub_hist = historico_tags[i - tamanho_gatilho:i]
            for idx, g_item in enumerate(gatilho_list):
                if g_item not in sub_hist[idx]:
                    match = False
                    break
        else:
            match = False

        if match:
            total_entradas += 1
            acertou_no_ciclo = False
            gale_usado = 0

            for g in range(max_gales + 1):
                if i + g < len(historico_tags):
                    num_seguinte = str(historico[i + g])
                    tags_seguinte = historico_tags[i + g]
                    if num_seguinte in alvos_expandidos or any(alvo in tags_seguinte for alvo in alvos_expandidos):
                        acertou_no_ciclo = True
                        gale_usado = g
                        break
                gale_usado = g

            if acertou_no_ciclo:
                greens += 1
                drawdown_atual = 0
            else:
                reds += 1
                drawdown_atual += 1
                max_drawdown = max(max_drawdown, drawdown_atual)

            i += (gale_usado + 1)
        else:
            i += 1

    total_operacoes = greens + reds
    assertividade = (greens / total_operacoes * 100) if total_operacoes > 0 else 0.0
    return {
        "total_entradas": total_entradas,
        "greens": greens,
        "reds": reds,
        "assertividade": assertividade,
        "max_drawdown": max_drawdown,
        "gatilho": gatilho_list,
        "alvos": alvos_expandidos,
        "max_gales": max_gales,
    }


def analisar_sniper(historico_bruto, janela_amostra=60, atraso_min=30, qtd_vizinhos=5, momentum_min=3, min_meta=80.0, max_gales_sim=2):
    if len(historico_bruto) < janela_amostra:
        return None

    atrasos = {}
    for n in range(37):
        try:
            idx_reverso = historico_bruto[::-1].index(n)
            atrasos[n] = idx_reverso
        except ValueError:
            atrasos[n] = len(historico_bruto)

    janela_recente = historico_bruto[-janela_amostra:]
    alvos_encontrados = []

    for n, atraso in atrasos.items():
        if atraso >= atraso_min:
            vizinhos_zona = obter_vizinhos_cilindro(n, qtd_vizinhos)
            acertos_zona = sum(1 for x in janela_recente if x in vizinhos_zona)
            if acertos_zona >= momentum_min:
                alvos_encontrados.append((n, vizinhos_zona, atraso, acertos_zona))

    if not alvos_encontrados:
        return None

    alvos_encontrados.sort(key=lambda x: (x[3], x[2]), reverse=True)

    for alvo in alvos_encontrados:
        num_alvo = alvo[0]
        zona = alvo[1]
        atraso_alvo = alvo[2]
        greens_bt = 0
        reds_bt = 0
        i = 0
        while i < len(janela_recente) - max_gales_sim:
            acertou_no_ciclo = False
            g_usado = 0
            for g in range(max_gales_sim + 1):
                if i + g < len(janela_recente):
                    if str(janela_recente[i + g]) in map(str, zona):
                        acertou_no_ciclo = True
                        g_usado = g
                        break
                g_usado = g
            if acertou_no_ciclo:
                greens_bt += 1
            else:
                reds_bt += 1
            i += (g_usado + 1)

        total_bt = greens_bt + reds_bt
        pct_bt = (greens_bt / total_bt * 100) if total_bt > 0 else 0.0
        if pct_bt >= min_meta:
            return {
                "nome": f"Sniper (Alvo: {num_alvo})",
                "gatilho_str": f"MODO SNIPER [Alvo: {num_alvo} | Atr: {atraso_alvo}]",
                "alvos": [str(x) for x in zona],
                "alvo_central": num_alvo,
                "max_gales": max_gales_sim,
                "greens": greens_bt,
                "reds": reds_bt,
                "pct": pct_bt,
            }
    return None


def analisar_termo(historico_bruto, janela_amostra=60, min_hits=8, qtd_vizinhos=1, min_meta=80.0, max_gales_sim=2):
    if len(historico_bruto) < janela_amostra:
        return None

    janela_recente = historico_bruto[-janela_amostra:]
    cont_terms = {i: 0 for i in range(10)}
    for n in janela_recente:
        cont_terms[n % 10] += 1

    term_campeao = max(cont_terms.items(), key=lambda x: x[1])
    term_id = term_campeao[0]
    hits_term = term_campeao[1]
    if hits_term < min_hits:
        return None

    numeros_base = TERMINAIS_MAP[f"T{term_id}"]
    alvos_expandidos = set()
    for num_str in numeros_base:
        viz = obter_vizinhos_cilindro(int(num_str), qtd_vizinhos)
        for v in viz:
            alvos_expandidos.add(str(v))

    zona = list(alvos_expandidos)
    greens_bt = 0
    reds_bt = 0
    i = 0
    while i < len(janela_recente) - max_gales_sim:
        acertou_no_ciclo = False
        g_usado = 0
        for g in range(max_gales_sim + 1):
            if i + g < len(janela_recente):
                if str(janela_recente[i + g]) in zona:
                    acertou_no_ciclo = True
                    g_usado = g
                    break
            g_usado = g
        if acertou_no_ciclo:
            greens_bt += 1
        else:
            reds_bt += 1
        i += (g_usado + 1)

    total_bt = greens_bt + reds_bt
    pct_bt = (greens_bt / total_bt * 100) if total_bt > 0 else 0.0
    if pct_bt >= min_meta:
        return {
            "nome": f"Terminal Físico (T{term_id} + {qtd_vizinhos}V)",
            "gatilho_str": f"IA TERMO-FÍSICA [T{term_id} em Alta ({hits_term}x)]",
            "alvos": zona,
            "alvo_central": f"T{term_id}",
            "is_termo": True,
            "max_gales": max_gales_sim,
            "greens": greens_bt,
            "reds": reds_bt,
            "pct": pct_bt,
            "hits": hits_term,
        }
    return None


def raio_x(historico, janela=60):
    if not historico:
        return None
    ultimos = historico[-janela:]
    tot = len(ultimos)
    cont_nums = {n: ultimos.count(n) for n in set(ultimos)}
    top_nums = sorted(cont_nums.items(), key=lambda x: x[1], reverse=True)[:5]
    cont_terms = {i: 0 for i in range(10)}
    for n in ultimos:
        cont_terms[n % 10] += 1
    top_terms = sorted(cont_terms.items(), key=lambda x: x[1], reverse=True)[:3]

    def calc_pct(count):
        return (count / tot * 100) if tot > 0 else 0

    r = sum(1 for n in ultimos if n in VERMELHOS)
    b = sum(1 for n in ultimos if n not in VERMELHOS and n != 0)
    z = sum(1 for n in ultimos if n == 0)
    d1 = sum(1 for n in ultimos if 1 <= n <= 12)
    d2 = sum(1 for n in ultimos if 13 <= n <= 24)
    d3 = sum(1 for n in ultimos if 25 <= n <= 36)
    c1 = sum(1 for n in ultimos if n != 0 and n % 3 == 1)
    c2 = sum(1 for n in ultimos if n != 0 and n % 3 == 2)
    c3 = sum(1 for n in ultimos if n != 0 and n % 3 == 0)
    par = sum(1 for n in ultimos if n != 0 and n % 2 == 0)
    impar = sum(1 for n in ultimos if n != 0 and n % 2 != 0)
    return {
        "total": tot,
        "plenos": [{"n": n, "c": c} for n, c in top_nums],
        "terminais": [{"t": t, "c": c} for t, c in top_terms],
        "vermelho": calc_pct(r),
        "preto": calc_pct(b),
        "zero": calc_pct(z),
        "d1": calc_pct(d1),
        "d2": calc_pct(d2),
        "d3": calc_pct(d3),
        "c1": calc_pct(c1),
        "c2": calc_pct(c2),
        "c3": calc_pct(c3),
        "par": calc_pct(par),
        "impar": calc_pct(impar),
    }


def fixture_history(length=120):
    # Deterministic mixed sample with repeats, delays and terminal concentration.
    nums = []
    for i in range(length):
        if i % 11 == 0:
            nums.append(0)
        elif i % 7 == 0:
            nums.append(32)
        elif i % 5 == 0:
            nums.append(17)
        else:
            nums.append((i * 13 + 5) % 37)
    return nums


def dump_all():
    hist = fixture_history(120)
    mined = minerar_padroes_ao_vivo(hist)
    return {
        "app": APP_NOME,
        "versao": APP_VERSAO,
        "roda": RODA_EUROPEIA,
        "tags_0": classificar_numero(0),
        "tags_17": classificar_numero(17),
        "tags_32": classificar_numero(32),
        "expand_P1": expandir_alvos(["P1"]),
        "expand_T2": expandir_alvos(["T2"]),
        "expand_D2D3": expandir_alvos(["D2", "D3"]),
        "vizinhos_17": vizinhos_roda(17, 2),
        "vizinhos_cilindro_17_5": obter_vizinhos_cilindro(17, 5),
        "cobertos_T2": numeros_cobertos(expandir_alvos(["T2"])),
        "cobertos_D2D3": numeros_cobertos(expandir_alvos(["D2", "D3"])),
        "cobertos_P2P3": numeros_cobertos(expandir_alvos(["P2", "P3"])),
        "wilson_8_10": limite_inferior_wilson(8, 10),
        "wilson_3_3": limite_inferior_wilson(3, 3),
        "history": hist,
        "mine_count": len(mined),
        "mined": mined,
        "sniper": analisar_sniper(hist),
        "termo": analisar_termo(hist),
        "backtest_d3": simular_estrategia(hist, ["D3"], expandir_alvos(["T1", "T2", "T3"]), 2),
        "raiox": raio_x(hist, 60),
        "gatilho_d3": verificar_gatilho([classificar_numero(n) for n in hist], {"gatilho": ["D3"], "ausencia": False}),
        "gatilho_rr": verificar_gatilho(
            [classificar_numero(n) for n in hist],
            {"gatilho": ["R", "R"], "ausencia": False},
        ),
    }


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "dump"
    if cmd == "dump":
        print(json.dumps(dump_all(), ensure_ascii=False))
        return
    if cmd == "classify":
        n = int(sys.argv[2])
        print(json.dumps(classificar_numero(n)))
        return
    if cmd == "mine":
        hist = json.loads(sys.argv[2])
        print(json.dumps(minerar_padroes_ao_vivo(hist), ensure_ascii=False))
        return
    raise SystemExit(f"unknown command {cmd}")


if __name__ == "__main__":
    main()
