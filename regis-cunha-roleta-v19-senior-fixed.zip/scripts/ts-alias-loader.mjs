import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const SRC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "src");

function existingFile(filePath) {
  const candidates = [
    filePath,
    `${filePath}.ts`,
    `${filePath}.tsx`,
    path.join(filePath, "index.ts"),
    path.join(filePath, "index.tsx"),
  ];
  for (const candidate of candidates) {
    try {
      if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate;
    } catch {
      // ignore
    }
  }
  return null;
}

export async function resolve(specifier, context, nextResolve) {
  if (specifier.startsWith("@/")) {
    const mapped = existingFile(path.join(SRC, specifier.slice(2)));
    if (mapped) {
      return { url: pathToFileURL(mapped).href, shortCircuit: true };
    }
  }
  if (specifier.startsWith(".") && context.parentURL) {
    const parent = path.dirname(fileURLToPath(context.parentURL));
    const mapped = existingFile(path.resolve(parent, specifier));
    if (mapped) {
      return { url: pathToFileURL(mapped).href, shortCircuit: true };
    }
  }
  return nextResolve(specifier, context);
}
