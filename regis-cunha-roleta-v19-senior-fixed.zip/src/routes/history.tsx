import { createFileRoute } from "@tanstack/react-router";
import { Inbox } from "lucide-react";
import { NumberOrb } from "@/components/number-orb";
import { SignalCard } from "@/components/signal-card";
import { WindowPills } from "@/components/window-pills";
import { Panel } from "@/components/ui/panel";
import { useLiveTable } from "@/hooks/use-live-table";
import type { AnalysisWindow } from "@/lib/config/app";
import { colorLabel, formatRelativeTime } from "@/lib/analise/roulette";
import { useRoletaStore } from "@/lib/state/store";

export const Route = createFileRoute("/history")({ component: HistoryPage });

function HistoryPage() {
  const { spins, signals, source, analysisWindow, runtime } = useLiveTable();
  const setAnalysisWindow = useRoletaStore((state) => state.setAnalysisWindow);
  const sample = spins.slice(0, analysisWindow);

  return (
    <div className="flex flex-col gap-5">
      <div>
        <p className="text-micro text-subtle">Dados da mesa</p>
        <h1 className="font-display mt-1 text-2xl font-semibold tracking-tight">Histórico</h1>
      </div>

      <WindowPills value={analysisWindow} onChange={(value: AnalysisWindow) => setAnalysisWindow(value)} />

      <section className="grid grid-cols-3 gap-3 rounded-[var(--radius-xl)] border border-border bg-surface p-4">
        <div>
          <p className="text-micro text-subtle">Capturado</p>
          <p className="mt-1 font-display text-2xl font-semibold tabular">{spins.length}</p>
        </div>
        <div>
          <p className="text-micro text-subtle">Sinais</p>
          <p className="mt-1 font-display text-2xl font-semibold text-sage tabular">{signals.length}</p>
        </div>
        <div>
          <p className="text-micro text-subtle">Estado</p>
          <p className="mt-2 text-sm font-medium">{runtime.status}</p>
        </div>
      </section>

      <p className="text-xs leading-5 text-muted">
        {source.origin} · {source.message}
      </p>

      <Panel>
        <h2 className="font-display text-lg font-semibold">Faixa visual</h2>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {sample.length === 0 ? (
            <p className="text-sm text-muted">Conecte a mesa para ver os giros.</p>
          ) : (
            sample.slice(0, 80).map((spin, index) => {
              const prev = sample[index + 1];
              return (
                <NumberOrb
                  key={spin.id}
                  number={spin.number}
                  size="sm"
                  repeat={Boolean(prev && prev.number === spin.number)}
                />
              );
            })
          )}
        </div>
      </Panel>

      <section className="flex flex-col gap-3">
        <h2 className="font-display text-lg font-semibold">Sinais recentes</h2>
        {signals.length === 0 ? (
          <p className="rounded-[var(--radius-lg)] border border-border bg-surface px-4 py-5 text-sm text-muted">
            Nenhum sinal gerado nesta sessão da mesa.
          </p>
        ) : (
          signals.map((signal) => <SignalCard key={signal.id} signal={signal} compact />)
        )}
      </section>

      <section className="flex flex-col gap-2">
        <h2 className="font-display text-lg font-semibold">Giros recentes</h2>
        {spins.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-12 text-center">
            <Inbox className="size-7 text-muted" />
            <p className="font-medium">Nenhum giro capturado</p>
            <p className="max-w-xs text-sm text-muted">
              Os resultados aparecem aqui assim que a mesa for conectada e varrida.
            </p>
          </div>
        ) : (
          <ul className="divide-y divide-border rounded-[var(--radius-xl)] border border-border bg-surface">
            {spins.slice(0, 120).map((spin) => (
              <li key={spin.id} className="flex min-h-[68px] items-center gap-3 px-3">
                <NumberOrb number={spin.number} />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">Resultado {spin.number}</p>
                  <p className="text-xs text-muted">
                    {formatRelativeTime(spin.createdAt)} · {colorLabel(spin.number)} · {spin.parity} · D
                    {spin.dozen || "—"} · C{spin.column || "—"} · T{spin.terminal}
                    {spin.multiplier ? ` · x${spin.multiplier}` : ""}
                  </p>
                </div>
                {spin.totalWinners ? (
                  <span className="text-xs text-subtle tabular">{spin.totalWinners}</span>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
