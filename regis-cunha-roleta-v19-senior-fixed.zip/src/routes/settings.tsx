import { createFileRoute } from "@tanstack/react-router";
import { Crosshair, Shield } from "lucide-react";
import { FilterPanel } from "@/components/filter-panel";
import { Switch } from "@/components/ui/switch";
import { Panel } from "@/components/ui/panel";
import { useLiveTable } from "@/hooks/use-live-table";
import { APP_VERSION, DISCLAIMER } from "@/lib/config/app";
import { TABLES } from "@/lib/config/tables";
import { playwrightUnsupportedReason } from "@/lib/coleta/playwright";
import { connectorLabel } from "@/lib/analise/roulette";
import { useRoletaStore } from "@/lib/state/store";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const { source, tableId, runtime } = useLiveTable();
  const settings = useRoletaStore((state) => state.settings);
  const toggleSetting = useRoletaStore((state) => state.toggleSetting);
  const table = TABLES[tableId];
  const bancaInicial = useRoletaStore((state) => state.bancaInicial);
  const fichaBase = useRoletaStore((state) => state.fichaBase);
  const stopWin = useRoletaStore((state) => state.stopWin);
  const stopLoss = useRoletaStore((state) => state.stopLoss);
  const maxReds = useRoletaStore((state) => state.maxReds);
  const multsGales = useRoletaStore((state) => state.multsGales);
  const setMultsGales = useRoletaStore((state) => state.setMultsGales);
  const setBancaInicial = useRoletaStore((state) => state.setBancaInicial);
  const setFichaBase = useRoletaStore((state) => state.setFichaBase);
  const setStopWin = useRoletaStore((state) => state.setStopWin);
  const setStopLoss = useRoletaStore((state) => state.setStopLoss);
  const setMaxReds = useRoletaStore((state) => state.setMaxReds);

  return (
    <div className="flex flex-col gap-5">
      <div>
        <p className="text-micro text-subtle">Controle do monitor</p>
        <h1 className="font-display mt-1 text-2xl font-semibold tracking-tight">Ajustes</h1>
      </div>

      <section className="flex items-center gap-3 rounded-[var(--radius-xl)] bg-surface-2 p-4">
        <div className="flex size-12 items-center justify-center rounded-[16px] bg-ember text-primary-fg">
          <Crosshair className="size-5" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="font-display text-lg font-semibold">{table.label}</p>
          <p className="text-sm text-accent">{table.providerLabel} · {connectorLabel(runtime.status)}</p>
        </div>
      </section>

      <Panel className="px-4 py-0">
        <label className="flex min-h-[78px] items-center gap-3">
          <div className="min-w-0 flex-1 py-4">
            <p className="text-sm font-medium">Alertas sonoros</p>
            <p className="mt-1 text-xs text-muted">Toca um tom curto quando um sinal novo aparece.</p>
          </div>
          <Switch checked={settings.sound} onCheckedChange={() => toggleSetting("sound")} />
        </label>
      </Panel>

      <FilterPanel />

      <Panel>
        <h2 className="text-sm font-semibold">Gestão de banca virtual</h2>
        <p className="mt-1 text-xs text-muted">Somente simulação. O aplicativo não executa apostas.</p>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <NumberField label="Banca inicial" value={bancaInicial} onChange={setBancaInicial} min={0} step={1} />
          <NumberField label="Ficha base" value={fichaBase} onChange={setFichaBase} min={0.01} step={0.01} />
          <NumberField label="Stop win" value={stopWin} onChange={setStopWin} min={0} step={1} />
          <NumberField label="Stop loss" value={stopLoss} onChange={setStopLoss} min={0} step={1} />
          <NumberField label="Máx. reds" value={maxReds} onChange={setMaxReds} min={0} step={1} />
        </div>
        <div className="mt-4">
          <p className="text-xs text-muted">Multiplicadores dos gales</p>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {multsGales.map((value, index) => (
              <label key={index} className="flex flex-col gap-1 text-xs text-muted">
                G{index + 1}
                <input
                  value={value}
                  onChange={(event) => {
                    const next = [...multsGales];
                    next[index] = event.target.value;
                    setMultsGales(next);
                  }}
                  className="min-h-10 rounded-[var(--radius-md)] border border-border bg-surface-2 px-3 text-sm text-fg outline-none focus:border-accent"
                />
              </label>
            ))}
          </div>
        </div>
      </Panel>

      <Panel className="px-4 py-2">
        <Row label="Versão" value={APP_VERSION} />
        <Row label="Fonte de dados" value={source.origin} />
        <Row label="Mesa" value={source.table} />
        <Row label="Provedor" value={table.providerLabel} />
        <Row label="Estado" value={source.message} />
      </Panel>

      <Panel>
        <div className="flex items-start gap-3">
          <Shield className="mt-0.5 size-4 text-warn" />
          <div className="text-sm leading-6 text-muted">
            <p className="font-medium text-fg">Responsabilidade e coleta</p>
            <p className="mt-1">{table.description}</p>
            <p className="mt-2">{DISCLAIMER}</p>
            <p className="mt-2">{playwrightUnsupportedReason()}</p>
          </div>
        </div>
      </Panel>
    </div>
  );
}

function NumberField({ label, value, onChange, min, step }: { label: string; value: number; onChange: (value: number) => void; min: number; step: number }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-xs text-muted">{label}</span>
      <input
        type="number"
        inputMode="decimal"
        min={min}
        step={step}
        value={value}
        onChange={(event) => onChange(Math.max(min, Number(event.target.value) || min))}
        className="min-h-10 rounded-[var(--radius-md)] border border-border bg-surface-2 px-3 text-sm tabular outline-none focus:border-accent"
      />
    </label>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex min-h-12 items-center justify-between gap-4">
      <span className="text-sm text-muted">{label}</span>
      <span className="max-w-[60%] text-right text-sm font-medium">{value}</span>
    </div>
  );
}
