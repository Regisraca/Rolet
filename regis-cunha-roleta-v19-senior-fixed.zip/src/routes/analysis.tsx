import { createFileRoute } from "@tanstack/react-router";
import { RouletteWheel } from "@/components/roulette-wheel";
import { StatsCards } from "@/components/stats-cards";
import { WindowPills } from "@/components/window-pills";
import { Panel } from "@/components/ui/panel";
import { useLiveTable } from "@/hooks/use-live-table";
import type { AnalysisWindow } from "@/lib/config/app";
import { computeWindowStats } from "@/lib/analise/stats";
import { useRoletaStore } from "@/lib/state/store";

export const Route = createFileRoute("/analysis")({ component: AnalysisPage });

function AnalysisPage() {
  const { spins, currentSignal, analysisWindow } = useLiveTable();
  const setAnalysisWindow = useRoletaStore((state) => state.setAnalysisWindow);
  const stats = computeWindowStats(spins, analysisWindow);
  const last = spins[0]?.number;

  return (
    <div className="flex flex-col gap-5">
      <div>
        <p className="text-micro text-subtle">Distribuição</p>
        <h1 className="font-display mt-1 text-2xl font-semibold tracking-tight">Análise</h1>
      </div>

      <WindowPills value={analysisWindow} onChange={(value: AnalysisWindow) => setAnalysisWindow(value)} />

      <Panel>
        <RouletteWheel lastNumber={last} targets={currentSignal?.targets ?? []} />
        <p className="mt-3 text-center text-xs text-subtle">
          Contorno pedra = último giro. Contorno ember = alvos do sinal ativo.
        </p>
      </Panel>

      {stats.repeats.streak > 1 ? (
        <Panel>
          <p className="text-micro text-subtle">Repetição</p>
          <p className="mt-1 text-sm">
            {stats.repeats.number} saiu {stats.repeats.streak} vezes seguidas.
          </p>
        </Panel>
      ) : null}

      <div className="grid grid-cols-3 gap-2">
        <Panel className="p-3">
          <p className="text-micro text-subtle">Cor</p>
          <p className="mt-1 text-sm font-medium">
            {stats.streaks.color.label} · {stats.streaks.color.length}
          </p>
        </Panel>
        <Panel className="p-3">
          <p className="text-micro text-subtle">Paridade</p>
          <p className="mt-1 text-sm font-medium">
            {stats.streaks.parity.label} · {stats.streaks.parity.length}
          </p>
        </Panel>
        <Panel className="p-3">
          <p className="text-micro text-subtle">Dúzia</p>
          <p className="mt-1 text-sm font-medium">
            {stats.streaks.dozen.label} · {stats.streaks.dozen.length}
          </p>
        </Panel>
      </div>

      <StatsCards spins={spins} window={analysisWindow} />
    </div>
  );
}
