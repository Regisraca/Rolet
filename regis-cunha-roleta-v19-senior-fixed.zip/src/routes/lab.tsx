import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { WindowPills } from "@/components/window-pills";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/ui/panel";
import { useLiveTable } from "@/hooks/use-live-table";
import { minePatterns } from "@/lib/analise/quant";
import { runBacktest, type BacktestResult, type BacktestStrategy } from "@/lib/backtest/engine";
import { compareStrategies, sweepMinScore, type ComparisonRow } from "@/lib/backtest/comparison";
import type { AnalysisWindow } from "@/lib/config/app";
import { DISCLAIMER } from "@/lib/config/app";
import { useRoletaStore } from "@/lib/state/store";

export const Route = createFileRoute("/lab")({ component: LabPage });

const STRATEGIES: { id: BacktestStrategy; label: string }[] = [
  { id: "consenso", label: "Consenso" },
  { id: "sniper", label: "Sniper" },
  { id: "termo", label: "Termo" },
  { id: "quant", label: "Quant" },
  { id: "modelo", label: "Modelo" },
];

function formatPct(value: number | null) {
  if (value === null) return "—";
  return `${Math.round(value * 1000) / 10}%`;
}

function ResultGrid({ result }: { result: BacktestResult }) {
  const cells = [
    ["Sinais", String(result.signals)],
    ["Green", String(result.greens)],
    ["Red", String(result.reds)],
    ["Taxa", formatPct(result.hitRate)],
    ["G0", String(result.g0)],
    ["G1", String(result.g1)],
    ["G2", String(result.g2)],
    ["Seq. red", String(result.maxLosingStreak)],
    ["Drawdown", String(result.drawdown)],
    ["Unidades", String(result.units)],
    ["Baseline", formatPct(result.baseline)],
    ["Wilson", formatPct(result.wilson)],
    ["Edge", formatPct(result.edge)],
    ["Cobertura", String(result.avgCoverage)],
  ];
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      {cells.map(([label, value]) => (
        <div key={label} className="rounded-[var(--radius-md)] bg-surface-2 px-3 py-3">
          <p className="text-micro text-subtle">{label}</p>
          <p className="mt-1 font-display text-xl font-semibold tabular">{value}</p>
        </div>
      ))}
    </div>
  );
}

function ComparisonTable({ rows }: { rows: ComparisonRow[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead>
          <tr className="text-micro text-subtle">
            {["Estratégia", "Sinais", "Green", "Red", "G0", "G1", "G2", "Edge", "Drawdown"].map((header) => (
              <th key={header} className="px-2 py-2 font-medium">
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.label} className="border-t border-border">
              <td className="px-2 py-2 font-medium">{row.label}</td>
              <td className="px-2 py-2 tabular">{row.signals}</td>
              <td className="px-2 py-2 tabular">{row.greens}</td>
              <td className="px-2 py-2 tabular">{row.reds}</td>
              <td className="px-2 py-2 tabular">{row.g0}</td>
              <td className="px-2 py-2 tabular">{row.g1}</td>
              <td className="px-2 py-2 tabular">{row.g2}</td>
              <td className="px-2 py-2 tabular">{formatPct(row.edge)}</td>
              <td className="px-2 py-2 tabular">{row.drawdown}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function LabPage() {
  const { spins, analysisWindow, minScore, maxGales } = useLiveTable();
  const setAnalysisWindow = useRoletaStore((state) => state.setAnalysisWindow);
  const [strategy, setStrategy] = useState<BacktestStrategy>("consenso");
  const [result, setResult] = useState<BacktestResult | null>(null);
  const [comparison, setComparison] = useState<ComparisonRow[] | null>(null);
  const [sweep, setSweep] = useState<ComparisonRow[] | null>(null);
  const patterns = useMemo(() => minePatterns(spins, analysisWindow), [spins, analysisWindow]);
  const window = Math.min(analysisWindow, 100);
  const base = { spins, minScore, maxGales, window };

  return (
    <div className="flex flex-col gap-5">
      <div>
        <p className="text-micro text-subtle">Quant lab</p>
        <h1 className="font-display mt-1 text-2xl font-semibold tracking-tight">Backtest</h1>
      </div>

      <WindowPills value={analysisWindow} onChange={(value: AnalysisWindow) => setAnalysisWindow(value)} />

      <Panel>
        <h2 className="font-display text-lg font-semibold">Mineração de padrões</h2>
        <p className="mt-1 text-sm text-muted">{patterns.sample} giros na amostra atual.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <div>
            <p className="text-micro text-subtle">Pares seguintes</p>
            <ul className="mt-2 space-y-1 text-sm">
              {patterns.pairs.length === 0 ? (
                <li className="text-muted">Sem amostra suficiente.</li>
              ) : (
                patterns.pairs.slice(0, 5).map((pair) => (
                  <li key={`${pair.a}-${pair.b}`} className="flex justify-between tabular">
                    <span>
                      {pair.a} → {pair.b}
                    </span>
                    <span className="text-muted">{pair.count}</span>
                  </li>
                ))
              )}
            </ul>
          </div>
          <div>
            <p className="text-micro text-subtle">Terminais</p>
            <ul className="mt-2 space-y-1 text-sm">
              {patterns.terminalShare.slice(0, 5).map((item) => (
                <li key={item.terminal} className="flex justify-between tabular">
                  <span>T{item.terminal}</span>
                  <span className="text-muted">{Math.round(item.share * 100)}%</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <p className="mt-4 text-sm text-muted">
          Sequência de cor mais longa: {patterns.longestColorStreak.label} · {patterns.longestColorStreak.length}.
          Concentração de terminais (HHI): {patterns.concentration.toFixed(3)}.
        </p>
      </Panel>

      <Panel>
        <h2 className="font-display text-lg font-semibold">Backtest da estratégia</h2>
        <p className="mt-1 text-sm text-muted">
          Cada estratégia é testada com a própria lógica. Resultados ruins não são mascarados.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          {STRATEGIES.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setStrategy(item.id)}
              className={`min-h-10 rounded-[var(--radius-md)] px-3 text-sm font-medium ${
                strategy === item.id ? "bg-surface-2 text-fg" : "text-muted"
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button
            disabled={spins.length < 30}
            onClick={() => setResult(runBacktest({ ...base, strategy }))}
          >
            Executar backtest
          </Button>
          <Button
            variant="ghost"
            disabled={spins.length < 30}
            onClick={() => setComparison(compareStrategies(base))}
          >
            Comparar estratégias
          </Button>
          <Button
            variant="ghost"
            disabled={spins.length < 30}
            onClick={() => setSweep(sweepMinScore({ ...base, strategy }))}
          >
            Varrer score
          </Button>
        </div>
        {spins.length < 30 ? (
          <p className="mt-3 text-sm text-muted">Conecte a mesa para carregar histórico suficiente.</p>
        ) : null}
      </Panel>

      {result ? (
        <Panel>
          {result.insufficient ? (
            <p className="font-display text-xl font-semibold text-warn">DADOS INSUFICIENTES</p>
          ) : (
            <p className="font-display text-xl font-semibold">Resultado hipotético</p>
          )}
          <p className="mt-2 text-sm text-muted">{result.note}</p>
          <div className="mt-4">
            <ResultGrid result={result} />
          </div>
        </Panel>
      ) : null}

      {comparison ? (
        <Panel>
          <h2 className="font-display text-lg font-semibold">Comparação</h2>
          <p className="mt-1 text-sm text-muted">
            Mesma amostra, mesmas regras de G0/G1/G2. Edge é taxa menos a baseline da cobertura.
          </p>
          <div className="mt-4">
            <ComparisonTable rows={comparison} />
          </div>
        </Panel>
      ) : null}

      {sweep ? (
        <Panel>
          <h2 className="font-display text-lg font-semibold">Varredura de score</h2>
          <p className="mt-1 text-sm text-muted">
            Compara o limiar 10 / 15 / 20 / 25 na estratégia selecionada. Não é aprendizado de máquina.
          </p>
          <div className="mt-4">
            <ComparisonTable rows={sweep} />
          </div>
        </Panel>
      ) : null}

      <p className="text-xs leading-5 text-subtle">{DISCLAIMER}</p>
    </div>
  );
}
