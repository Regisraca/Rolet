import { Pause, Play, PlugZap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLiveTable, useTableControls } from "@/hooks/use-live-table";

export function TableControls() {
  const { runtime } = useLiveTable();
  const { connect, connecting, startScan, stopScan, stopping } = useTableControls();
  const disconnected = runtime.status === "disconnected" || runtime.status === "error";
  const capturing = runtime.status === "capturing";
  const canStop = capturing || runtime.status === "connected";

  return (
    <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
      <Button
        variant="outline"
        onClick={connect}
        disabled={connecting || capturing}
        className="min-h-12"
      >
        <PlugZap className="size-4" />
        {connecting ? "Conectando" : "Conectar mesa"}
      </Button>
      <Button
        variant="sage"
        onClick={startScan}
        disabled={connecting || capturing}
        className="min-h-12"
      >
        <Play className="size-4" />
        {capturing ? "Capturando" : disconnected ? "Conectar e varrer" : "Iniciar varredura"}
      </Button>
      <Button
        variant="ember"
        onClick={stopScan}
        disabled={!canStop || stopping}
        className="min-h-12"
      >
        <Pause className="size-4" />
        Parar
      </Button>
    </div>
  );
}
