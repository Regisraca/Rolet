import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-micro font-semibold",
  {
    variants: {
      tone: {
        muted: "bg-surface-2 text-muted",
        accent: "bg-accent/15 text-accent",
        ember: "bg-ember/15 text-ember",
        sage: "bg-sage/15 text-sage",
        blue: "bg-blue/15 text-blue",
        warn: "bg-warn/15 text-warn",
        danger: "bg-danger/15 text-danger",
        stone: "bg-accent/15 text-accent",
      },
    },
    defaultVariants: { tone: "muted" },
  },
);

export function Badge({
  className,
  tone,
  ...props
}: React.ComponentProps<"span"> & VariantProps<typeof badgeVariants>) {
  return <span className={cn(badgeVariants({ tone }), className)} {...props} />;
}
