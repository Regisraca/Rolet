import { NumberOrb } from "@/components/number-orb";
import { formatRelativeTime, type Spin } from "@/lib/analise/roulette";

export function HistoryStrip({ spins, limit = 18 }: { spins: Spin[]; limit?: number }) {
  const recent = spins.slice(0, limit);
  if (recent.length === 0) {
    return (
      <p className="py-6 text-center text-sm text-muted">
        Os resultados aparecem depois que a mesa for conectada.
      </p>
    );
  }
  return (
    <div className="flex gap-2 overflow-x-auto pb-1">
      {recent.map((spin, index) => {
        const prev = recent[index + 1];
        const repeat = Boolean(prev && prev.number === spin.number);
        return (
          <div key={spin.id} className="flex min-w-12 flex-col items-center gap-1.5">
            <NumberOrb number={spin.number} repeat={repeat} />
            <span className="text-micro tracking-normal text-subtle">{formatRelativeTime(spin.createdAt)}</span>
          </div>
        );
      })}
    </div>
  );
}
