import type { EngineSnapshot } from "@/lib/types/strategy";
import { cn } from "@/lib/utils";

const ORDER = ["SNIPER", "TERMO", "QUANT", "MODELO"] as const;

function statusTone(status: string) {
  if (status === "PRONTO") return "text-sage";
  if (status === "CANDIDATO") return "text-warn";
  if (status === "DADOS_INSUFICIENTES") return "text-danger";
  return "text-muted";
}

function statusLabel(status: string) {
  if (status === "PRONTO") return "Pronto";
  if (status === "CANDIDATO") return "Candidato";
  if (status === "DADOS_INSUFICIENTES") return "Sem dados";
  return "Observando";
}

export function StrategyBoard({ snapshot }: { snapshot: EngineSnapshot }) {
  const byId = new Map(snapshot.strategies.map((item) => [item.strategy, item]));
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      {ORDER.map((id) => {
        const item = byId.get(id);
        return (
          <div key={id} className="rounded-[var(--radius-lg)] border border-border bg-surface px-3 py-3">
            <p className="text-micro text-subtle">{id}</p>
            <p className="mt-1 font-display text-xl font-semibold tabular">{item ? item.score.toFixed(1) : "—"}</p>
            <p className={cn("mt-1 text-xs", statusTone(item?.status ?? "OBSERVANDO"))}>
              {statusLabel(item?.status ?? "OBSERVANDO")}
            </p>
          </div>
        );
      })}
    </div>
  );
}
