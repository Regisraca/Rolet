import { ANALYSIS_WINDOWS, type AnalysisWindow } from "@/lib/config/app";
import { cn } from "@/lib/utils";

export function WindowPills({
  value,
  onChange,
}: {
  value: AnalysisWindow;
  onChange: (value: AnalysisWindow) => void;
}) {
  return (
    <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
      <p className="text-micro text-subtle">Janela de análise</p>
      <div className="flex gap-1 overflow-x-auto rounded-[var(--radius-md)] bg-surface-2 p-1">
        {ANALYSIS_WINDOWS.map((window) => (
          <button
            key={window}
            type="button"
            onClick={() => onChange(window)}
            className={cn(
              "min-h-9 min-w-11 rounded-[8px] px-2.5 text-xs font-semibold tabular transition-colors",
              value === window ? "bg-surface text-fg" : "text-muted hover:text-fg",
            )}
          >
            {window}
          </button>
        ))}
      </div>
    </div>
  );
}
