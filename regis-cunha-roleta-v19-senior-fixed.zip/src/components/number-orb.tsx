import { cn } from "@/lib/utils";
import { numberColor, type PocketColor } from "@/lib/analise/roulette";

const toneClass: Record<PocketColor, string> = {
  green: "bg-pocket-green text-fg",
  red: "bg-pocket-red text-fg",
  black: "bg-pocket-black text-fg ring-1 ring-border-strong",
};

export function NumberOrb({
  number,
  size = "md",
  dim = false,
  active = false,
  repeat = false,
  className,
}: {
  number: number;
  size?: "sm" | "md" | "lg" | "xl";
  dim?: boolean;
  active?: boolean;
  repeat?: boolean;
  className?: string;
}) {
  const tone = numberColor(number);
  return (
    <span
      className={cn(
        "relative inline-flex items-center justify-center font-display font-semibold tabular leading-none",
        toneClass[tone],
        size === "sm" && "size-8 rounded-[10px] text-xs",
        size === "md" && "size-10 rounded-[12px] text-sm",
        size === "lg" && "size-14 rounded-[16px] text-xl",
        size === "xl" && "h-20 w-20 rounded-[24px] text-4xl tracking-tight",
        dim && "opacity-40",
        active && "ring-2 ring-accent",
        className,
      )}
    >
      {number}
      {repeat ? <span className="absolute -top-1 -right-1 size-2 rounded-full bg-warn" /> : null}
    </span>
  );
}
