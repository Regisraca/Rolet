import { TABLE_LIST, type TableId } from "@/lib/config/tables";
import { cn } from "@/lib/utils";

export function TableSwitcher({
  value,
  onChange,
}: {
  value: TableId;
  onChange: (id: TableId) => void;
}) {
  return (
    <div
      className="flex gap-1 overflow-x-auto rounded-[var(--radius-lg)] bg-surface-2 p-1"
      role="tablist"
      aria-label="Mesas"
    >
      {TABLE_LIST.map((table) => {
        const active = table.id === value;
        return (
          <button
            key={table.id}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(table.id)}
            className={cn(
              "min-h-11 min-w-20 shrink-0 rounded-[var(--radius-md)] px-3 text-left transition-colors",
              active ? "bg-surface text-fg" : "text-muted hover:text-fg",
            )}
          >
            <span className="block text-xs font-semibold tracking-tight">{table.shortLabel}</span>
            <span className="block text-micro tracking-wider text-subtle">{table.providerLabel}</span>
          </button>
        );
      })}
    </div>
  );
}
