import { captureLabel, connectorLabel, formatRelativeTime } from "@/lib/analise/roulette";
import { useLiveTable } from "@/hooks/use-live-table";
import { cn } from "@/lib/utils";

function Dot({ on, warn }: { on: boolean; warn?: boolean }) {
  return (
    <span
      className={cn(
        "size-2 rounded-full",
        warn ? "bg-warn" : on ? "bg-sage" : "bg-danger",
      )}
    />
  );
}

export function StatusStrip() {
  const { runtime, source, spins } = useLiveTable();
  const last = spins[0];
  const connectionOn = runtime.status === "connected" || runtime.status === "capturing" || runtime.status === "paused";
  const capturing = runtime.status === "capturing";
  const connecting = runtime.status === "connecting";

  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      <div className="rounded-[var(--radius-lg)] border border-border bg-surface px-3 py-3">
        <p className="text-micro text-subtle">Conexão</p>
        <p className="mt-2 flex items-center gap-2 text-sm font-medium">
          <Dot on={connectionOn} warn={connecting} />
          {connectorLabel(runtime.status).toUpperCase()}
        </p>
      </div>
      <div className="rounded-[var(--radius-lg)] border border-border bg-surface px-3 py-3">
        <p className="text-micro text-subtle">Coleta</p>
        <p className="mt-2 flex items-center gap-2 text-sm font-medium">
          <Dot on={capturing} warn={runtime.status === "paused"} />
          {captureLabel(runtime.status).toUpperCase()}
        </p>
      </div>
      <div className="rounded-[var(--radius-lg)] border border-border bg-surface px-3 py-3">
        <p className="text-micro text-subtle">Último resultado</p>
        <p className="mt-1 font-display text-2xl font-semibold tabular">{last ? last.number : "—"}</p>
      </div>
      <div className="rounded-[var(--radius-lg)] border border-border bg-surface px-3 py-3">
        <p className="text-micro text-subtle">Mesa</p>
        <p className="mt-2 truncate text-sm font-medium">
          {source.provider} · {source.table}
        </p>
        <p className="mt-1 truncate text-xs text-subtle">
          {last ? formatRelativeTime(last.createdAt) : source.message}
        </p>
      </div>
    </div>
  );
}
