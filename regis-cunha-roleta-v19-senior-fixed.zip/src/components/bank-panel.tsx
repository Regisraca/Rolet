import { Panel } from "@/components/ui/panel";
import type { BancaState } from "@/lib/v19/live";

function money(value: number) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function BankPanel({ banca, maxReds = 2 }: { banca: BancaState; maxReds?: number }) {
  const atual = banca.bancaInicial + banca.lucroVirtual;
  const total = banca.greens + banca.reds;
  const taxa = total > 0 ? (banca.greens / total) * 100 : 0;
  const stopped = maxReds > 0 && banca.redsConsecutivos >= maxReds;

  return (
    <Panel>
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-micro text-subtle">Gestão de banca</p>
          <h2 className="font-display mt-1 text-lg font-semibold">Banca virtual</h2>
        </div>
        <span className={atual >= banca.bancaInicial ? "text-sage" : "text-danger"}>
          {money(atual)}
        </span>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Metric label="Inicial" value={money(banca.bancaInicial)} />
        <Metric label="P&L" value={money(banca.lucroVirtual)} />
        <Metric label="Assertividade" value={`${taxa.toFixed(1)}%`} />
        <Metric label="G / R" value={`${banca.greens} / ${banca.reds}`} />
      </div>
      <div className="mt-3 flex items-center justify-between rounded-[var(--radius-md)] bg-surface-2 px-3 py-2 text-xs">
        <span className="text-muted">Sequência de reds: {banca.redsConsecutivos}</span>
        <span className={stopped ? "text-danger" : "text-muted"}>
          {stopped ? "Limite de reds atingido" : "Monitoramento ativo"}
        </span>
      </div>
      {banca.entradas.length > 0 ? (
        <div className="mt-4">
          <p className="text-micro text-subtle">Últimas entradas liquidadas</p>
          <div className="mt-2 space-y-2">
            {banca.entradas.slice(0, 4).map((entry, index) => (
              <div key={`${entry.hora}-${entry.numero}-${index}`} className="flex items-center justify-between gap-3 text-xs">
                <span className="text-muted">{entry.estrategia} · {entry.numero} · {entry.gale ? `G${entry.gale}` : "DIRETA"}</span>
                <span className={entry.resultado === "GREEN" ? "text-sage" : "text-danger"}>
                  {entry.resultado === "GREEN" ? "+" : ""}{money(entry.valor)}
                </span>
              </div>
            ))}
          </div>
        </div>
      ) : null}
    </Panel>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[var(--radius-md)] bg-surface-2 px-3 py-2">
      <p className="text-micro text-subtle">{label}</p>
      <p className="mt-1 text-sm font-semibold tabular">{value}</p>
    </div>
  );
}
