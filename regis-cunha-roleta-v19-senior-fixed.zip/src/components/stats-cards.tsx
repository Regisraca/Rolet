import { NumberOrb } from "@/components/number-orb";
import { Panel } from "@/components/ui/panel";
import { computeWindowStats, pct } from "@/lib/analise/stats";
import type { Spin } from "@/lib/analise/roulette";
import { Bar, BarChart, Cell, ResponsiveContainer, XAxis, YAxis } from "recharts";

function Meter({
  label,
  value,
  total,
  tone,
}: {
  label: string;
  value: number;
  total: number;
  tone: "red" | "black" | "green" | "sage" | "blue" | "ember";
}) {
  const percent = pct(value, total);
  const fill = {
    red: "bg-pocket-red",
    black: "bg-muted",
    green: "bg-pocket-green",
    sage: "bg-sage",
    blue: "bg-blue",
    ember: "bg-ember",
  }[tone];
  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between text-xs">
        <span className="text-muted">{label}</span>
        <span className="font-medium tabular">
          {value} · {percent}%
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-surface-2">
        <div className={`h-full rounded-full ${fill}`} style={{ width: `${percent}%` }} />
      </div>
    </div>
  );
}

export function StatsCards({ spins, window }: { spins: Spin[]; window: number }) {
  const stats = computeWindowStats(spins, window);
  const chartData = stats.terminals.map((item) => ({
    name: `T${item.terminal}`,
    count: item.count,
  }));

  return (
    <div className="flex flex-col gap-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <Panel>
          <h2 className="text-sm font-semibold">Cor, paridade e faixa</h2>
          <div className="mt-4 flex flex-col gap-3">
            <Meter label="Vermelho" value={stats.red} total={stats.total} tone="red" />
            <Meter label="Preto" value={stats.black} total={stats.total} tone="black" />
            <Meter label="Zero" value={stats.green} total={stats.total} tone="green" />
            <Meter label="Par" value={stats.even} total={stats.total} tone="sage" />
            <Meter label="Ímpar" value={stats.odd} total={stats.total} tone="blue" />
            <Meter label="1–18" value={stats.low} total={stats.total} tone="sage" />
            <Meter label="19–36" value={stats.high} total={stats.total} tone="ember" />
          </div>
        </Panel>
        <Panel>
          <h2 className="text-sm font-semibold">Dúzias e colunas</h2>
          <div className="mt-4 flex flex-col gap-3">
            <Meter label="Dúzia 1" value={stats.dozens[0]} total={stats.total} tone="sage" />
            <Meter label="Dúzia 2" value={stats.dozens[1]} total={stats.total} tone="blue" />
            <Meter label="Dúzia 3" value={stats.dozens[2]} total={stats.total} tone="ember" />
            <Meter label="Coluna 1" value={stats.columns[0]} total={stats.total} tone="sage" />
            <Meter label="Coluna 2" value={stats.columns[1]} total={stats.total} tone="blue" />
            <Meter label="Coluna 3" value={stats.columns[2]} total={stats.total} tone="ember" />
          </div>
        </Panel>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <Panel>
          <h2 className="text-sm font-semibold">Frequência</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {stats.hot.length === 0 ? (
              <p className="text-sm text-muted">Sem amostra.</p>
            ) : (
              stats.hot.map((item) => (
                <div key={item.number} className="flex flex-col items-center gap-1">
                  <NumberOrb number={item.number} size="sm" />
                  <span className="text-micro tracking-normal text-subtle tabular">{item.count}x</span>
                </div>
              ))
            )}
          </div>
        </Panel>
        <Panel>
          <h2 className="text-sm font-semibold">Atraso</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {stats.delayed.length === 0 ? (
              <p className="text-sm text-muted">Sem amostra.</p>
            ) : (
              stats.delayed.map((item) => (
                <div key={item.number} className="flex flex-col items-center gap-1">
                  <NumberOrb number={item.number} size="sm" dim={item.count === 0} />
                  <span className="text-micro tracking-normal text-subtle tabular">{item.lastSeen}</span>
                </div>
              ))
            )}
          </div>
        </Panel>
        <Panel>
          <h2 className="text-sm font-semibold">Frios</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {stats.cold.length === 0 ? (
              <p className="text-sm text-muted">Sem amostra.</p>
            ) : (
              stats.cold.map((item) => (
                <div key={item.number} className="flex flex-col items-center gap-1">
                  <NumberOrb number={item.number} size="sm" dim={item.count === 0} />
                  <span className="text-micro tracking-normal text-subtle tabular">{item.count}x</span>
                </div>
              ))
            )}
          </div>
        </Panel>
      </div>

      <Panel>
        <h2 className="text-sm font-semibold">Terminais 0–9</h2>
        <div className="mt-3 h-40">
          {stats.total === 0 ? (
            <p className="py-10 text-center text-sm text-muted">Aguardando giros para montar o gráfico.</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} barCategoryGap={8}>
                <XAxis dataKey="name" tick={{ fill: "#9b9890", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {chartData.map((entry) => (
                    <Cell key={entry.name} fill="#c5c1b7" />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </Panel>
    </div>
  );
}
