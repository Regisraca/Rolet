import { Switch } from "@/components/ui/switch";
import { Panel } from "@/components/ui/panel";
import { COOLDOWN_PRESETS, CONSENSUS_PRESETS, MIN_SCORE_PRESETS } from "@/lib/config/strategies";
import type { StrategyWeights } from "@/lib/config/strategies";
import { FILTER_CATALOG, type FilterId } from "@/lib/sinais/filters";
import { useRoletaStore } from "@/lib/state/store";

function ChipRow<T extends number>({
  label,
  hint,
  values,
  value,
  onChange,
  format,
}: {
  label: string;
  hint?: string;
  values: readonly T[];
  value: T | number;
  onChange: (value: T) => void;
  format?: (value: T) => string;
}) {
  return (
    <div className="mt-4">
      <p className="text-micro text-subtle">{label}</p>
      {hint ? <p className="mt-1 text-xs text-muted">{hint}</p> : null}
      <div className="mt-2 flex flex-wrap gap-2">
        {values.map((item) => (
          <button
            key={String(item)}
            type="button"
            onClick={() => onChange(item)}
            className={`min-h-10 min-w-11 rounded-[var(--radius-sm)] px-2 text-sm font-semibold tabular ${
              value === item ? "bg-surface-2 text-fg" : "text-muted"
            }`}
          >
            {format ? format(item) : item}
          </button>
        ))}
      </div>
    </div>
  );
}

const WEIGHT_STEPS = [0.5, 1, 1.5] as const;
const WEIGHT_KEYS: { id: keyof StrategyWeights; label: string }[] = [
  { id: "sniper", label: "SNIPER" },
  { id: "termo", label: "TERMO" },
  { id: "quant", label: "QUANT" },
  { id: "model", label: "MODELO" },
];

export function FilterPanel() {
  const filters = useRoletaStore((state) => state.filters);
  const toggleFilter = useRoletaStore((state) => state.toggleFilter);
  const minScore = useRoletaStore((state) => state.minScore);
  const setMinScore = useRoletaStore((state) => state.setMinScore);
  const maxGales = useRoletaStore((state) => state.maxGales);
  const setMaxGales = useRoletaStore((state) => state.setMaxGales);
  const cooldownSpins = useRoletaStore((state) => state.cooldownSpins);
  const setCooldownSpins = useRoletaStore((state) => state.setCooldownSpins);
  const minConsensus = useRoletaStore((state) => state.minConsensus);
  const setMinConsensus = useRoletaStore((state) => state.setMinConsensus);
  const confirmationSpins = useRoletaStore((state) => state.confirmationSpins);
  const setConfirmationSpins = useRoletaStore((state) => state.setConfirmationSpins);
  const weights = useRoletaStore((state) => state.weights);
  const setWeight = useRoletaStore((state) => state.setWeight);

  return (
    <div className="flex flex-col gap-4">
      <Panel>
        <h2 className="text-sm font-semibold">Motor de estratégias</h2>
        <p className="mt-1 text-xs text-muted">
          O sinal só nasce quando score, consenso e cooldown passam no filtro de qualidade. Isso não é probabilidade.
        </p>
        <ChipRow
          label="Score mínimo"
          values={MIN_SCORE_PRESETS}
          value={minScore}
          onChange={setMinScore}
        />
        <ChipRow
          label="Gales máximos"
          values={[0, 1, 2, 3, 4, 5, 6] as const}
          value={maxGales}
          onChange={setMaxGales}
          format={(item) => `G${item}`}
        />
        <ChipRow
          label="Consenso mínimo"
          hint="Quantas estratégias precisam apontar o mesmo número."
          values={CONSENSUS_PRESETS}
          value={minConsensus}
          onChange={setMinConsensus}
          format={(item) => `${item}/3`}
        />
        <ChipRow
          label="Confirmação"
          hint="Giros consecutivos com o mesmo padrão antes de abrir o sinal."
          values={[1, 2] as const}
          value={confirmationSpins}
          onChange={setConfirmationSpins}
          format={(item) => (item === 1 ? "Imediato" : "2 giros")}
        />
        <ChipRow
          label="Cooldown"
          hint="Giros de espera depois de GREEN ou RED."
          values={COOLDOWN_PRESETS}
          value={cooldownSpins}
          onChange={setCooldownSpins}
        />
        <div className="mt-4">
          <p className="text-micro text-subtle">Pesos</p>
          <div className="mt-2 flex flex-col gap-3">
            {WEIGHT_KEYS.map((item) => (
              <div key={item.id} className="flex items-center justify-between gap-3">
                <span className="text-sm">{item.label}</span>
                <div className="flex gap-1">
                  {WEIGHT_STEPS.map((step) => (
                    <button
                      key={step}
                      type="button"
                      onClick={() => setWeight(item.id, step)}
                      className={`min-h-10 min-w-11 rounded-[var(--radius-sm)] px-2 text-sm font-semibold tabular ${
                        weights[item.id] === step ? "bg-surface-2 text-fg" : "text-muted"
                      }`}
                    >
                      {step}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </Panel>
      <Panel className="px-0 py-0">
        {FILTER_CATALOG.map((filter, index) => (
          <label
            key={filter.id}
            className={`flex min-h-[72px] items-center gap-3 px-4 ${
              index < FILTER_CATALOG.length - 1 ? "border-b border-border" : ""
            }`}
          >
            <div className="min-w-0 flex-1 py-3">
              <p className="text-sm font-medium">{filter.name}</p>
              <p className="mt-1 text-xs text-muted">{filter.description}</p>
            </div>
            <Switch
              checked={filters[filter.id as FilterId].enabled}
              onCheckedChange={() => toggleFilter(filter.id)}
            />
          </label>
        ))}
      </Panel>
      <p className="px-1 text-xs leading-5 text-subtle">
        Filtros continuam como leitura de mesa. Eles não somam para fabricar um sinal — cada estratégia tem lógica própria.
      </p>
    </div>
  );
}
