import { WHEEL_ORDER, numberColor } from "@/lib/analise/roulette";
import { cn } from "@/lib/utils";

const FILL: Record<string, string> = {
  green: "#1F8A5B",
  red: "#C4453C",
  black: "#161618",
};

export function RouletteWheel({
  lastNumber,
  targets = [],
  className,
}: {
  lastNumber?: number;
  targets?: number[];
  className?: string;
}) {
  const size = 320;
  const cx = size / 2;
  const cy = size / 2;
  const outer = 148;
  const inner = 86;
  const count = WHEEL_ORDER.length;
  const targetSet = new Set(targets);

  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      className={cn("mx-auto size-full max-w-80", className)}
      role="img"
      aria-label="Roda europeia"
    >
      <circle cx={cx} cy={cy} r={outer + 10} fill="#0c0c0d" stroke="#3d3b37" strokeWidth="2" />
      <circle cx={cx} cy={cy} r={outer + 4} fill="none" stroke="#c5c1b7" strokeWidth="1.2" />
      {WHEEL_ORDER.map((number, index) => {
        const start = (index / count) * Math.PI * 2 - Math.PI / 2;
        const end = ((index + 1) / count) * Math.PI * 2 - Math.PI / 2;
        const x1 = cx + Math.cos(start) * outer;
        const y1 = cy + Math.sin(start) * outer;
        const x2 = cx + Math.cos(end) * outer;
        const y2 = cy + Math.sin(end) * outer;
        const ix1 = cx + Math.cos(end) * inner;
        const iy1 = cy + Math.sin(end) * inner;
        const ix2 = cx + Math.cos(start) * inner;
        const iy2 = cy + Math.sin(start) * inner;
        const mid = start + (end - start) / 2;
        const tx = cx + Math.cos(mid) * ((outer + inner) / 2);
        const ty = cy + Math.sin(mid) * ((outer + inner) / 2);
        const isLast = number === lastNumber;
        const isTarget = targetSet.has(number);
        return (
          <g key={number}>
            <path
              d={`M ${x1} ${y1} A ${outer} ${outer} 0 0 1 ${x2} ${y2} L ${ix1} ${iy1} A ${inner} ${inner} 0 0 0 ${ix2} ${iy2} Z`}
              fill={FILL[numberColor(number)]}
              stroke={isLast ? "#c5c1b7" : isTarget ? "#d15a4a" : "#0c0c0d"}
              strokeWidth={isLast ? 3 : isTarget ? 2 : 0.55}
            />
            <text
              x={tx}
              y={ty}
              textAnchor="middle"
              dominantBaseline="middle"
              fill="#F3F1EC"
              fontSize={isLast ? 11 : 8.5}
              fontWeight={isLast ? 700 : 500}
              fontFamily="Figtree, sans-serif"
            >
              {number}
            </text>
          </g>
        );
      })}
      <circle cx={cx} cy={cy} r={inner - 10} fill="#131314" stroke="#2a2926" />
      <text
        x={cx}
        y={cy - 14}
        textAnchor="middle"
        fill="#6e6c66"
        fontSize="9"
        letterSpacing="2"
        fontFamily="Figtree, sans-serif"
      >
        ÚLTIMO
      </text>
      <text
        x={cx}
        y={cy + 16}
        textAnchor="middle"
        fill="#F3F1EC"
        fontSize="36"
        fontWeight="500"
        fontFamily="Fraunces, serif"
      >
        {lastNumber ?? "—"}
      </text>
    </svg>
  );
}
