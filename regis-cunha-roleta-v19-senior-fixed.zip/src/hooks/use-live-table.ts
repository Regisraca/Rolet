import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useRef } from "react";
import { connectTable, emptyState, pauseTable, scanTable } from "@/lib/coleta/api";
import { playSignalTone } from "@/lib/sound";
import { runtimeFromStore, useRoletaStore } from "@/lib/state/store";
import type { ConnectorStatus, RouletteState } from "@/lib/analise/roulette";
import { SCAN_INTERVAL_MS } from "@/lib/config/app";
import { evaluateEngine } from "@/lib/engine/signal-engine";
import { chronologicalFromSpins } from "@/lib/v19/live";
import { minerarPadroesAoVivo } from "@/lib/v19/quant";
import { raioXDaMesa } from "@/lib/v19/raiox";

const IDLE_RUNTIME = {
  status: "disconnected" as const,
  sessionId: null,
  error: null,
};

export function useRouletteQuery() {
  const tableId = useRoletaStore((state) => state.tableId);
  const runtime = useRoletaStore((state) => state.runtime[state.tableId] ?? IDLE_RUNTIME);
  const capturing = runtime.status === "capturing";

  return useQuery({
    queryKey: ["roulette-state", tableId, runtime.sessionId],
    queryFn: () =>
      scanTable({
        data: { tableId, sessionId: runtime.sessionId, deep: false },
      }),
    enabled: capturing && Boolean(runtime.sessionId),
    refetchInterval: capturing ? SCAN_INTERVAL_MS : false,
    staleTime: 800,
  });
}

export function LiveIngest() {
  const tableId = useRoletaStore((state) => state.tableId);
  const sound = useRoletaStore((state) => state.settings.sound);
  const ingestSpins = useRoletaStore((state) => state.ingestSpins);
  const query = useRouletteQuery();
  const lastSignalId = useRef<string | null>(null);
  const spins = query.data?.spins ?? [];

  useEffect(() => {
    lastSignalId.current = null;
  }, [tableId]);

  useEffect(() => {
    if (!spins.length) return;
    const created = ingestSpins(tableId, spins);
    if (created && created.id !== lastSignalId.current) {
      lastSignalId.current = created.id;
      if (sound) void playSignalTone();
    }
  }, [ingestSpins, sound, spins, tableId]);

  return null;
}

export function useTableControls() {
  const tableId = useRoletaStore((state) => state.tableId);
  const runtime = useRoletaStore((state) => state.runtime[tableId] ?? IDLE_RUNTIME);
  const setRuntime = useRoletaStore((state) => state.setRuntime);
  const queryClient = useQueryClient();

  const connect = useMutation({
    mutationFn: async (next: Extract<ConnectorStatus, "connected" | "capturing">) => {
      setRuntime(tableId, { status: "connecting", error: null });
      const state = await connectTable({ data: { tableId, deep: true } });
      return { state, next };
    },
    onSuccess: ({ state, next }) => {
      queryClient.setQueryData(["roulette-state", tableId, state.sessionId], state);
      const online = state.source.status === "online";
      setRuntime(tableId, {
        status: online ? next : "error",
        sessionId: state.sessionId,
        error: online ? null : state.source.message,
      });
    },
    onError: (error) => {
      setRuntime(tableId, {
        status: "error",
        error: error instanceof Error ? error.message : "Falha ao conectar a mesa.",
      });
    },
  });

  const startScan = () => {
    if (runtime.status === "disconnected" || runtime.status === "error") {
      connect.mutate("capturing");
      return;
    }
    setRuntime(tableId, { status: "capturing", error: null });
  };

  const stopScan = useMutation({
    mutationFn: async () => {
      if (runtime.sessionId) {
        await pauseTable({ data: { tableId, sessionId: runtime.sessionId } });
      }
    },
    onSettled: () => {
      setRuntime(tableId, { status: runtime.sessionId ? "paused" : "disconnected" });
    },
  });

  return {
    connect: () => connect.mutate("connected"),
    connecting: connect.isPending || runtime.status === "connecting",
    startScan,
    stopScan: () => stopScan.mutate(),
    stopping: stopScan.isPending,
  };
}

export function useLiveTable() {
  const tableId = useRoletaStore((state) => state.tableId);
  const analysisWindow = useRoletaStore((state) => state.analysisWindow);
  const signals = useRoletaStore((state) => state.signals);
  const runtime = useRoletaStore((state) => state.runtime[tableId] ?? IDLE_RUNTIME);
  const minScore = useRoletaStore((state) => state.minScore);
  const maxGales = useRoletaStore((state) => state.maxGales);
  const storedSnapshot = useRoletaStore((state) => state.snapshot);
  const estrategias = useRoletaStore((state) => state.estrategias);
  const banca = useRoletaStore((state) => state.banca);
  const query = useRouletteQuery();
  const snapshot = query.data;
  const connected =
    runtime.status === "connected" || runtime.status === "capturing" || runtime.status === "paused";
  const state: RouletteState = connected && snapshot ? snapshot : emptyState(tableId);
  const spins = connected ? state.spins : [];
  const storeSlice = useRoletaStore.getState();

  const engineSnapshot = useMemo(() => {
    if (!spins.length) return storedSnapshot;
    return evaluateEngine(spins, runtimeFromStore(storeSlice), estrategias);
  }, [spins, storedSnapshot, estrategias, analysisWindow, minScore, maxGales, storeSlice.sniperEnabled, storeSlice.termoEnabled, storeSlice.atrasoMin, storeSlice.vizinhosSniper, storeSlice.momentumMin, storeSlice.termHits, storeSlice.termViz]);

  const historico = useMemo(() => chronologicalFromSpins(spins), [spins]);
  const raiox = useMemo(() => raioXDaMesa(historico, analysisWindow), [historico, analysisWindow]);
  const mined = useMemo(() => minerarPadroesAoVivo(historico, maxGales), [historico, maxGales]);

  return {
    tableId,
    analysisWindow,
    minScore,
    maxGales,
    runtime,
    spins,
    historico,
    raiox,
    mined,
    banca,
    estrategias,
    source: connected
      ? state.source
      : runtime.status === "error"
        ? {
            ...emptyState(tableId).source,
            status: "error" as const,
            message: runtime.error ?? "Falha na conexão.",
          }
        : emptyState(tableId).source,
    signals,
    currentSignal: signals.find((signal) => signal.result === "PENDING") ?? null,
    engineSnapshot,
    isFetching: query.isFetching,
    isError: runtime.status === "error" || state.source.status === "error",
    refresh: query.refetch,
    inserted: snapshot?.inserted ?? 0,
  };
}
