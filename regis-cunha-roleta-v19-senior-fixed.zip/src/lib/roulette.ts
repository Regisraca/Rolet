export * from "@/lib/analise/roulette";
export * from "@/lib/analise/stats";
export * from "@/lib/sinais/engine";
