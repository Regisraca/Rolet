import { enrichSpin, getWheelNeighbors, type Spin } from "@/lib/analise/roulette";

export function spinsFrom(numbers: number[], start = Date.parse("2026-01-01T00:00:00Z")): Spin[] {
  return numbers.map((number, index) =>
    enrichSpin({
      id: `spin-${numbers.length - index}`,
      sourceEventId: `evt-${numbers.length - index}`,
      number,
      createdAt: new Date(start + (numbers.length - index) * 1000).toISOString(),
      luckyNumbers: [],
      multiplier: null,
      totalWinners: null,
      tableId: "auto-roulette",
      provider: "Evolution",
      sessionId: "test-session",
    }),
  );
}

export function prependSpin(history: Spin[], number: number): Spin[] {
  const newest = history[0];
  const nextIndex = history.length + 1;
  const createdAt = newest ? new Date(Date.parse(newest.createdAt) + 1000).toISOString() : new Date().toISOString();
  return [
    enrichSpin({
      id: `spin-${nextIndex}-${number}`,
      sourceEventId: `evt-${nextIndex}-${number}`,
      number,
      createdAt,
      luckyNumbers: [],
      multiplier: null,
      totalWinners: null,
      tableId: "auto-roulette",
      provider: "Evolution",
      sessionId: "test-session",
    }),
    ...history,
  ];
}

/** Newest-first history concentrated on the physical zone of 17, with extra T2 hits. */
export function clusteredNumbers(length = 80): number[] {
  const zone = getWheelNeighbors(17, 2);
  const terminals = [2, 12, 22, 32];
  const chronological: number[] = [];
  for (let i = 0; i < length; i += 1) {
    const slot = i % 8;
    if (slot < 4) chronological.push(zone[i % zone.length]);
    else if (slot < 7) chronological.push(terminals[i % terminals.length]);
    else chronological.push(2);
  }
  return [...chronological].reverse();
}

export function clusteredSpins(length = 80) {
  return spinsFrom(clusteredNumbers(length));
}

export function uniformSpins(length = 80) {
  const chronological = Array.from({ length }, (_, index) => (index * 11 + 7) % 37);
  return spinsFrom([...chronological].reverse());
}

export function shortSpins(length = 8) {
  return spinsFrom(Array.from({ length }, (_, index) => (index * 7) % 37));
}
