import type { Spin } from "@/lib/analise/roulette";
import { buildEngineConfig, type StrategyEngineConfig } from "@/lib/config/strategies";
import { analisarNumerosPlenosSniper } from "@/lib/v19/sniper";
import { analisarTerminaisDinamicos } from "@/lib/v19/termo";
import { minerarPadroesAoVivo } from "@/lib/v19/quant";
import type { StrategyContext, StrategyOutput } from "@/lib/types/strategy";

export function makeContext(spins: Spin[], window: number, timestamp?: string): StrategyContext {
  return {
    spins,
    history: spins.map((spin) => spin.number),
    window,
    timestamp: timestamp ?? spins[0]?.createdAt ?? new Date().toISOString(),
  };
}

/**
 * Canonical live strategy adapter.
 *
 * The actual V19 algorithms live under src/lib/v19 and mirror the original
 * Python reference. This module only adapts their results to the generic
 * engine contract used by the UI/consensus layer.
 */
export function runIndependentStrategies(
  spins: Spin[],
  config: StrategyEngineConfig = buildEngineConfig(),
): StrategyOutput[] {
  // The collector/UI exposes newest-first spins. V19 Python logic operates on
  // chronological history, so reverse once at this boundary and nowhere else.
  const chronological = [...spins].reverse();
  const timestamp = spins[0]?.createdAt ?? new Date().toISOString();
  const history = chronological.map((spin) => spin.number);
  const window = Math.max(config.sniper.window, config.quant.window, config.termo.longWindow);

  const sniperRaw = analisarNumerosPlenosSniper(history, {
    janelaAmostra: config.sniper.window,
    atrasoMin: config.sniper.atrasoMin,
    qtdVizinhos: config.sniper.zoneRadius,
    momentumMin: config.sniper.momentumMin,
    minMeta: config.minScore,
    maxGales: config.maxGales,
  });
  const termoRaw = analisarTerminaisDinamicos(history, {
    janelaAmostra: Math.min(config.termo.longWindow, config.termo.mediumWindow),
    minHits: config.termo.minHits,
    qtdVizinhos: config.termo.zoneNeighbors,
    minMeta: config.minScore,
    maxGales: config.maxGales,
  });
  const mined = minerarPadroesAoVivo(history, config.maxGales);

  const sniper: StrategyOutput = sniperRaw
    ? {
        strategy: "SNIPER",
        candidates: sniperRaw.alvos.map((raw) => ({ number: Number(raw), score: sniperRaw.pct, votes: ["SNIPER"] })),
        score: sniperRaw.pct,
        reasons: [{ code: "v19-sniper", text: sniperRaw.gatilho_str }],
        window: Math.min(config.sniper.window, history.length),
        timestamp,
        status: sniperRaw.pct >= config.minScore ? "PRONTO" : "CANDIDATO",
        requiredSpins: config.sniper.window,
        availableSpins: history.length,
      }
    : insufficientOrWatching("SNIPER", history.length, config.sniper.window, timestamp, "Nenhuma zona física passou os filtros V19.");

  const termo: StrategyOutput = termoRaw
    ? {
        strategy: "TERMO",
        candidates: termoRaw.alvos.map((raw) => ({ number: Number(raw), score: termoRaw.pct, votes: ["TERMO"] })),
        score: termoRaw.pct,
        reasons: [{ code: "v19-termo", text: termoRaw.gatilho_str }],
        window: Math.min(config.termo.longWindow, history.length),
        timestamp,
        status: termoRaw.pct >= config.minScore ? "PRONTO" : "CANDIDATO",
        requiredSpins: config.termo.mediumWindow,
        availableSpins: history.length,
      }
    : insufficientOrWatching("TERMO", history.length, config.termo.mediumWindow, timestamp, "Nenhum terminal passou os filtros V19.");

  const top = mined[0];
  const quant: StrategyOutput = top
    ? {
        strategy: "QUANT",
        candidates: top.alvos_expandidos
          .map(Number)
          .filter((number) => Number.isInteger(number) && number >= 0 && number <= 36)
          .map((number) => ({ number, score: top.assertividade, votes: ["QUANT"] })),
        score: top.assertividade,
        reasons: [{ code: "v19-quant", text: `${top.nome} · edge +${top.vantagem.toFixed(1)}% · Wilson ${top.confianca.toFixed(1)}%` }],
        window: Math.min(config.quant.window, history.length),
        timestamp,
        status: top.assertividade >= config.minScore ? "PRONTO" : "CANDIDATO",
        requiredSpins: 20,
        availableSpins: history.length,
      }
    : insufficientOrWatching("QUANT", history.length, 20, timestamp, "Nenhum padrão Quant passou Wilson/edge/cobertura.");

  // MODELO is deliberately metadata derived from the primary strategies. It
  // is not counted as an independent vote by combineConsensus.
  const modelo: StrategyOutput = {
    strategy: "MODELO",
    candidates: [],
    score: 0,
    reasons: [{ code: "meta", text: "MODELO é a camada de leitura do consenso; não adiciona um voto independente." }],
    window,
    timestamp,
    status: "OBSERVANDO",
    requiredSpins: config.minHistory,
    availableSpins: history.length,
  };

  const outputs = [
    config.focus === "TERMO" || config.focus === "QUANT" || config.focus === "MODELO" ? sniperDisabled(sniper) : sniper,
    config.focus === "SNIPER" || config.focus === "QUANT" || config.focus === "MODELO" ? termoDisabled(termo) : termo,
    config.focus === "SNIPER" || config.focus === "TERMO" || config.focus === "MODELO" ? quantDisabled(quant) : quant,
    modelo,
  ];

  if (config.focus === "SNIPER") return [sniper, termoDisabled(termo), quantDisabled(quant), modelo];
  if (config.focus === "TERMO") return [sniperDisabled(sniper), termo, quantDisabled(quant), modelo];
  if (config.focus === "QUANT") return [sniperDisabled(sniper), termoDisabled(termo), quant, modelo];
  if (config.focus === "MODELO") return [sniper, termo, quant, modelo];
  return outputs;
}


function insufficientOrWatching(
  strategy: "SNIPER" | "TERMO" | "QUANT",
  available: number,
  required: number,
  timestamp: string,
  reason: string,
): StrategyOutput {
  return {
    strategy,
    candidates: [],
    score: 0,
    reasons: [{ code: available < required ? "history" : "watch", text: reason }],
    window: required,
    timestamp,
    status: available < required ? "DADOS_INSUFICIENTES" : "OBSERVANDO",
    requiredSpins: required,
    availableSpins: available,
  };
}

function sniperDisabled(output: StrategyOutput): StrategyOutput {
  return { ...output, candidates: [], score: 0, status: "OBSERVANDO", reasons: [{ code: "focus", text: "SNIPER fora do foco atual." }] };
}
function termoDisabled(output: StrategyOutput): StrategyOutput {
  return { ...output, candidates: [], score: 0, status: "OBSERVANDO", reasons: [{ code: "focus", text: "TERMO fora do foco atual." }] };
}
function quantDisabled(output: StrategyOutput): StrategyOutput {
  return { ...output, candidates: [], score: 0, status: "OBSERVANDO", reasons: [{ code: "focus", text: "QUANT fora do foco atual." }] };
}
