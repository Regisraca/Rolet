import type { StrategyEngineConfig } from "@/lib/config/strategies";

import { round1 } from "@/lib/strategies/helpers";
import type { ConsensusOutput, RankedCandidate, StrategyContribution, StrategyOutput, StrategyStatus } from "@/lib/types/strategy";


export function rankByAgreement(
  outputs: StrategyOutput[],
  weights: StrategyEngineConfig["weights"],
  limit: number,
): RankedCandidate[] {
  const scores = Array.from({ length: 37 }, () => 0);
  const votes: Array<StrategyOutput["strategy"][]> = Array.from({ length: 37 }, () => []);

  for (const output of outputs) {
    if (output.strategy === "MODELO" || output.status === "DADOS_INSUFICIENTES") continue;
    const weight = output.strategy === "SNIPER" ? weights.sniper : output.strategy === "TERMO" ? weights.termo : weights.quant;
    const peak = output.candidates[0]?.score || 1;
    for (const candidate of output.candidates) {
      const share = peak > 0 ? candidate.score / peak : 0;
      scores[candidate.number] += share * output.score * weight;
      if (!votes[candidate.number].includes(output.strategy)) votes[candidate.number].push(output.strategy);
    }
  }

  return scores
    .map((score, number) => ({ number, score: round1(score + Math.max(0, votes[number].length - 1) * 2.4), votes: votes[number] }))
    .filter((item) => item.votes.length > 0)
    .sort((a, b) => b.votes.length - a.votes.length || b.score - a.score || a.number - b.number)
    .slice(0, limit);
}

function summaryOf(output: StrategyOutput) {
  return output.reasons[0]?.text ?? (output.status === "DADOS_INSUFICIENTES" ? "Dados insuficientes" : "Sem evidência");
}

function contrib(output: StrategyOutput | undefined, weight: number): StrategyContribution | null {
  if (!output) return null;
  return {
    strategy: output.strategy,
    score: output.score,
    weight,
    weighted: round1(output.score * weight),
    summary: summaryOf(output),
    candidates: output.candidates.map((item) => item.number),
  };
}

function fromFocus(output: StrategyOutput, config: StrategyEngineConfig): ConsensusOutput {
  const ranking: RankedCandidate[] = output.candidates.map((item) => ({
    ...item,
    votes: item.votes.length ? item.votes : [output.strategy],
  }));
  const score = round1(output.score);
  let status: StrategyStatus = output.status;
  if (output.status === "PRONTO" && score < config.minScore) status = "CANDIDATO";
  return {
    ranking,
    score,
    consensus: ranking[0]?.votes.length ?? (output.status === "PRONTO" ? 1 : 0),
    consensusTotal: output.strategy === "MODELO" ? 3 : 1,
    reasons: output.reasons,
    contributions: [contrib(output, 1)].filter((item): item is StrategyContribution => Boolean(item)),
    status,
    requiredSpins: output.requiredSpins,
    availableSpins: output.availableSpins,
  };
}

export function combineConsensus(outputs: StrategyOutput[], config: StrategyEngineConfig): ConsensusOutput {
  const sniper = outputs.find((item) => item.strategy === "SNIPER");
  const termo = outputs.find((item) => item.strategy === "TERMO");
  const quant = outputs.find((item) => item.strategy === "QUANT");
  const modelo = outputs.find((item) => item.strategy === "MODELO");
  const available = Math.max(...outputs.map((item) => item.availableSpins), 0);
  const required = config.minHistory;

  if (available < required) {
    return {
      ranking: [],
      score: 0,
      consensus: 0,
      consensusTotal: 3,
      reasons: [{ code: "history", text: `DADOS INSUFICIENTES — faltam ${required - available} giros (mínimo ${required}).` }],
      contributions: [],
      status: "DADOS_INSUFICIENTES",
      requiredSpins: required,
      availableSpins: available,
    };
  }

  if (config.focus === "SNIPER" && sniper) return fromFocus(sniper, config);
  if (config.focus === "TERMO" && termo) return fromFocus(termo, config);
  if (config.focus === "QUANT" && quant) return fromFocus(quant, config);
  if (config.focus === "MODELO" && modelo) return fromFocus(modelo, config);

  const ready = [sniper, termo, quant].filter((item): item is StrategyOutput =>  item !== undefined && item.status !== "DADOS_INSUFICIENTES");
  const primed = ready.filter((item) => item.status === "PRONTO");
  const ranking = rankByAgreement(ready, config.weights, config.maxCandidates);
  const agreed = ranking.filter((item) => item.votes.length >= config.minConsensus);
  const maxVotes = ranking[0]?.votes.length ?? 0;

  const contributions = [
    contrib(sniper, config.weights.sniper),
    contrib(termo, config.weights.termo),
    contrib(quant, config.weights.quant),
    contrib(modelo, config.weights.model),
  ].filter((item): item is StrategyContribution => Boolean(item));

  const activeWeighted =
    (sniper ? config.weights.sniper : 0) +
    (termo ? config.weights.termo : 0) +
    (quant ? config.weights.quant : 0);
  const raw =
    (sniper ? sniper.score * config.weights.sniper : 0) +
    (termo ? termo.score * config.weights.termo : 0) +
    (quant ? quant.score * config.weights.quant : 0);
  const score = round1(activeWeighted > 0 ? raw / activeWeighted : 0);
  const reasons = [
    ...(modelo?.reasons ?? []),
    ...(agreed[0]
      ? [
          {
            code: "rank",
            text: `Topo do ranking: ${agreed
              .slice(0, 4)
              .map((item) => item.number)
              .join(" · ")}`,
          },
        ]
      : [{ code: "none", text: "Sem convergência mínima entre as estratégias." }]),
  ];

  let status: StrategyStatus = "OBSERVANDO";
  if (ready.length === 0) status = "DADOS_INSUFICIENTES";
  else if (
    agreed.length > 0 &&
    score >= config.minScore &&
    maxVotes >= config.minConsensus &&
    primed.length >= 1
  ) {
    status = "PRONTO";
  } else if (ranking.length > 0 && (score >= config.minScore * 0.5 || maxVotes >= 2)) {
    status = "CANDIDATO";
  }

  return {
    ranking: agreed.length > 0 ? agreed : ranking.slice(0, config.maxCandidates),
    score,
    consensus: maxVotes,
    consensusTotal: 3,
    reasons,
    contributions,
    status,
    requiredSpins: required,
    availableSpins: available,
  };
}
