import type { Signal, SignalPhase, Spin } from "@/lib/analise/roulette";
import { MAX_SIGNALS } from "@/lib/config/app";
import { classificarNumero, expandirAlvos } from "@/lib/v19/classify";
import type { EstrategiaV19 } from "@/lib/v19/classify";
import {
  candidateToSignal,
  chronologicalFromSpins,
  emptyBanca,
  phaseFromGale,
  resolverSinalAtivo,
  type BancaState,
  type CandidateSignal,
  type MesaInfo,
  type V19RuntimeConfig,
  defaultRuntime,
} from "@/lib/v19/live";
import type { EngineSnapshot, SignalEngineState, StrategyOutput } from "@/lib/types/strategy";
import { buildEngineConfig, type StrategyEngineConfig } from "@/lib/config/strategies";
import { runIndependentStrategies } from "@/lib/engine/strategy-engine";
import { combineConsensus } from "@/lib/engine/consensus-engine";

export type V19EngineState = SignalEngineState & {
  candidate: CandidateSignal | null;
  mesa: MesaInfo;
  banca: BancaState;
};

export function emptyMesa(): MesaInfo {
  return {
    historico: [],
    cooldownSniper: 0,
    ultimoAlvoSniper: null,
    cooldownTerm: 0,
    ultimoAlvoTerm: null,
  };
}

export function emptyEngineState(signals: Signal[] = []): V19EngineState {
  return {
    signals,
    confirmation: null,
    lastProcessedSpinId: null,
    lastResolvedSpinId: null,
    candidate: null,
    mesa: emptyMesa(),
    banca: emptyBanca(),
  };
}

export function phaseOfPending(spinsSince: number, galeAtual: number): SignalPhase {
  if (spinsSince <= 0) return "SINAL_ATIVO";
  return phaseFromGale(galeAtual, true);
}

export function advanceSignal(signal: Signal, spins: Spin[]): Signal {
  const triggerIndex = spins.findIndex((spin) => spin.id === signal.triggerSpinId);
  const spinsSince = triggerIndex < 0 ? signal.spinsSince : triggerIndex;
  if (signal.result !== "PENDING") {
    return { ...signal, spinsSince, phase: signal.result, active: false };
  }
  if (triggerIndex < 0) return { ...signal, spinsSince };
  const after = spins.slice(0, triggerIndex);
  if (after.length === 0) {
    return { ...signal, spinsSince: 0, phase: "SINAL_ATIVO", galeAtual: 0, galeStep: 0, active: true };
  }
  const chronological = [...after].reverse().slice(0, (signal.maxGales ?? 2) + 1);
  const tokens = (signal.apostaStr ?? signal.targets.join(" ")).replace(/,/g, " ").split(/\s+/).filter(Boolean);
  const expanded = expandirAlvos(tokens);
  const hitIndex = chronological.findIndex((spin) => {
    const tags = classificarNumero(spin.number);
    return expanded.includes(String(spin.number)) || tokens.some((token) => tags.includes(token));
  });
  if (hitIndex >= 0) {
    const hit = chronological[hitIndex];
    return {
      ...signal,
      result: "GREEN",
      active: false,
      phase: "GREEN",
      resolvedAt: hit.createdAt,
      resolvedNumber: hit.number,
      resolvedSpinId: hit.id,
      galeHit: hitIndex,
      galeStep: hitIndex,
      galeAtual: hitIndex,
      spinsSince,
    };
  }
  if (chronological.length >= (signal.maxGales ?? 2) + 1) {
    const last = chronological[chronological.length - 1];
    return {
      ...signal,
      result: "RED",
      active: false,
      phase: "RED",
      resolvedAt: last?.createdAt,
      resolvedNumber: last?.number,
      resolvedSpinId: last?.id,
      galeStep: Math.max(0, chronological.length - 1),
      galeAtual: Math.max(0, chronological.length - 1),
      spinsSince,
    };
  }
  const galeAtual = Math.max(0, chronological.length - 1);
  return {
    ...signal,
    spinsSince,
    phase: phaseFromGale(galeAtual, true),
    galeStep: galeAtual,
    galeAtual,
    active: true,
  };
}

export function resolveSignals(signals: Signal[], spins: Spin[]): Signal[] {
  return signals.map((signal) => advanceSignal(signal, spins));
}

function runtimeConfigFromAny(config: V19RuntimeConfig | StrategyEngineConfig): V19RuntimeConfig {
  if ("sniperEnabled" in config) return config;
  const base = defaultRuntime();
  return {
    ...base,
    amostra: Math.max(20, config.sniper.window),
    minAssertividade: config.minScore,
    maxGales: Math.max(0, Math.min(6, config.maxGales)),
    cooldown: config.cooldownSpins,
    minConsensus: config.minConsensus,
    confirmationSpins: config.confirmationSpins,
    fichaBase: base.fichaBase,
    multsGales: [...base.multsGales],
    weights: config.weights,
    focus: config.focus,
    atrasoMin: config.sniper.atrasoMin,
    vizinhosSniper: config.sniper.zoneRadius,
    momentumMin: config.sniper.momentumMin,
    termHits: config.termo.minHits,
    termViz: config.termo.zoneNeighbors,
  };
}

function strategyConfigFromRuntime(config: V19RuntimeConfig | StrategyEngineConfig): StrategyEngineConfig {
  if (!("sniperEnabled" in config)) return config;
  const built = buildEngineConfig({
    analysisWindow: config.amostra,
    minScore: config.minAssertividade,
    maxGales: Math.max(0, Math.min(6, config.maxGales)),
    cooldownSpins: config.cooldown,
    minConsensus: config.minConsensus,
    confirmationSpins: config.confirmationSpins,
    focus: config.focus,
    stopWin: config.stopWin,
    stopLoss: config.stopLoss,
    maxReds: config.maxReds,
    weights: config.weights,
  });
  return {
    ...built,
    sniper: {
      ...built.sniper,
      atrasoMin: config.atrasoMin,
      momentumMin: config.momentumMin,
      zoneRadius: config.vizinhosSniper,
    },
    termo: {
      ...built.termo,
      minHits: config.termHits,
      zoneNeighbors: config.termViz,
    },
  };
}

function customQuantOutput(
  historico: number[],
  estrategias: EstrategiaV19[],
  base: StrategyOutput,
  config: V19RuntimeConfig,
): StrategyOutput {
  if (!estrategias.length) return base;
  const tags = historico.map(classificarNumero);
  const matches = estrategias.filter((est) => verificarEstrategia(tags, est));
  if (!matches.length) return base;

  const customCandidates = matches.flatMap((est) => {
    const pct = est.pct ?? 0;
    const alvos = est.alvos?.length ? est.alvos : expandirAlvos(est.aposta_str.replace(/,/g, " ").split(/\s+/).filter(Boolean));
    return alvos
      .map(Number)
      .filter((number) => Number.isInteger(number) && number >= 0 && number <= 36)
      .map((number) => ({ number, score: pct, votes: ["QUANT" as const] }));
  });
  const candidates = [...base.candidates, ...customCandidates]
    .reduce((acc, item) => {
      const prev = acc.get(item.number);
      if (!prev || item.score > prev.score) acc.set(item.number, item);
      return acc;
    }, new Map<number, StrategyOutput["candidates"][number]>());
  const list = [...candidates.values()].sort((a, b) => b.score - a.score).slice(0, config.amostra > 0 ? 24 : 24);
  const score = Math.max(base.score, ...matches.map((est) => est.pct ?? 0), 0);
  return {
    ...base,
    candidates: list,
    score,
    status: score >= config.minAssertividade ? "PRONTO" : list.length ? "CANDIDATO" : base.status,
    reasons: [
      { code: "custom-quant", text: `${matches.length} padrão(ões) Quant aplicado(s) e confirmado(s) pelo gatilho.` },
      ...base.reasons,
    ].slice(0, 4),
  };
}

function verificarEstrategia(tags: string[][], est: EstrategiaV19): boolean {
  const gatilho = est.gatilho ?? [];
  if (!gatilho.length) return false;
  if (est.ausencia) {
    const alvo = est.tag_ausencia ?? "";
    let limite = Number.parseInt(String(gatilho[1] ?? 5), 10);
    if (!Number.isFinite(limite)) limite = 5;
    let count = 0;
    for (let i = tags.length - 1; i >= 0; i -= 1) {
      if (tags[i].includes(alvo)) break;
      count += 1;
    }
    return count >= limite;
  }
  if (tags.length < gatilho.length) return false;
  const recent = tags.slice(-gatilho.length);
  return gatilho.every((expected, index) => expected === "N" || recent[index].includes(expected));
}


function disabledStrategy(output: StrategyOutput, reason: string): StrategyOutput {
  return { ...output, candidates: [], score: 0, status: "OBSERVANDO", reasons: [{ code: "disabled", text: reason }] };
}

export function evaluateEngine(
  spins: Spin[],
  config: V19RuntimeConfig | StrategyEngineConfig = defaultRuntime(),
  estrategias: EstrategiaV19[] = [],
): EngineSnapshot {
  const historico = chronologicalFromSpins(spins);
  const strategyConfig = strategyConfigFromRuntime(config);
  let strategies = runIndependentStrategies(spins, strategyConfig);

  const quant = strategies.find((item) => item.strategy === "QUANT");
  if (quant && ("sniperEnabled" in config) && config.amostra) {
    strategies = strategies.map((item) =>
      item.strategy === "QUANT" ? customQuantOutput(historico, estrategias, item, config) : item,
    );
  }

  if (!("weights" in config)) {
    strategies = strategies.map((item) => {
      if (item.strategy === "SNIPER" && !config.sniperEnabled) return disabledStrategy(item, "SNIPER desativado nos ajustes.");
      if (item.strategy === "TERMO" && !config.termoEnabled) return disabledStrategy(item, "TERMO desativado nos ajustes.");
      return item;
    });
  }
  const consensus = combineConsensus(strategies, strategyConfig);
  const available = historico.length;
  const required = strategyConfig.minHistory;
  const at = spins[0]?.createdAt ?? new Date().toISOString();
  const phase: SignalPhase =
    consensus.status === "DADOS_INSUFICIENTES"
      ? "OBSERVANDO"
      : consensus.status === "PRONTO"
        ? "CANDIDATO"
        : consensus.status === "CANDIDATO"
          ? "CANDIDATO"
          : "OBSERVANDO";

  return {
    at,
    triggerSpinId: spins[0]?.id ?? null,
    availableSpins: available,
    requiredSpins: required,
    insufficient: consensus.status === "DADOS_INSUFICIENTES",
    phase,
    strategies,
    consensus,
  };
}

function candidateFromSnapshot(snapshot: EngineSnapshot, config: V19RuntimeConfig): CandidateSignal | null {
  const engineConfig = strategyConfigFromRuntime(config);
  const minimumVotes = engineConfig.minConsensus;
  const top = snapshot.consensus.ranking.find((item) => item.votes.length >= minimumVotes) ?? snapshot.consensus.ranking[0];
  if (!top || snapshot.consensus.status !== "PRONTO") return null;
  if (top.votes.length < minimumVotes) return null;
  const primary = top.votes[0];
  const source = snapshot.strategies.find((item) => item.strategy === primary);
  if (!source) return null;
  const targets = snapshot.consensus.ranking
    .filter((item) => item.votes.length >= minimumVotes)
    .map((item) => String(item.number))
    .slice(0, 24);
  if (!targets.length) return null;
  return {
    nome: `CONSENSO V19 • ${primary}`,
    gatilho_str: `CONSENSO ${top.votes.length}/${snapshot.consensus.consensusTotal} • ${top.votes.join(" + ")} • alvo ${top.number}`,
    aposta_str: targets.join(" "),
    alvos: targets,
    max_gales: Math.max(0, Math.min(6, config.maxGales)),
    mults_gales: config.multsGales,
    gale_atual: 0,
    pct: snapshot.consensus.score,
    tipo: "MODELO",
    est_obj: null,
    alvo_central: top.number,
  };
}

export function runSignalCycle(args: {
  spins: Spin[];
  state: SignalEngineState | V19EngineState;
  config?: V19RuntimeConfig;
  estrategias?: EstrategiaV19[];
}): { state: V19EngineState; created: Signal | null; snapshot: EngineSnapshot } {
  const config = runtimeConfigFromAny(args.config ?? defaultRuntime());
  const estrategias = args.estrategias ?? [];
  const spins = args.spins;
  const prev = args.state as V19EngineState;
  const snapshot = evaluateEngine(spins, config, estrategias);
  const newestId = spins[0]?.id ?? null;
  let signals = resolveSignals(prev.signals ?? [], spins).slice(0, MAX_SIGNALS);
  let banca = prev.banca ?? emptyBanca();
  let mesa: MesaInfo = prev.mesa ?? emptyMesa();
  let candidate = prev.candidate ?? null;
  const historico = chronologicalFromSpins(spins);
  mesa = { ...mesa, historico };

  if (!newestId) {
    return { state: { ...emptyEngineState(signals), banca, mesa, candidate }, created: null, snapshot };
  }

  if (newestId === prev.lastProcessedSpinId) {
    const active = signals.find((signal) => signal.result === "PENDING");
    return {
      state: { signals, confirmation: null, lastProcessedSpinId: newestId, lastResolvedSpinId: prev.lastResolvedSpinId ?? null, candidate, mesa, banca },
      created: null,
      snapshot: { ...snapshot, phase: active?.phase ?? snapshot.phase },
    };
  }

  if (mesa.cooldownSniper > 0) mesa = { ...mesa, cooldownSniper: mesa.cooldownSniper - 1 };
  if (mesa.cooldownTerm > 0) mesa = { ...mesa, cooldownTerm: mesa.cooldownTerm - 1 };

  const pendingUi = signals.find((signal) => signal.result === "PENDING");
  if (candidate && spins[0]) {
    const tags = classificarNumero(spins[0].number);
    const hora = new Date(spins[0].createdAt).toISOString().slice(11, 19);
    const resolved = resolverSinalAtivo({
      sinal: candidate,
      numero: spins[0].number,
      tags,
      banca,
      config,
      hora,
    });
    banca = resolved.banca;
    if (resolved.resolved) {
      if (candidate.is_termo) {
        mesa = { ...mesa, ultimoAlvoTerm: String(candidate.alvo_central ?? ""), cooldownTerm: config.cooldown };
      } else if (candidate.alvo_central !== undefined && typeof candidate.alvo_central === "number") {
        mesa = { ...mesa, ultimoAlvoSniper: candidate.alvo_central, cooldownSniper: config.cooldown };
      }
      candidate = null;
    } else {
      candidate = resolved.sinal;
    }
  }

  const stillPending = signals.some((signal) => signal.result === "PENDING");
  let created: Signal | null = null;
  const stopped = banca.lucroVirtual >= config.stopWin || banca.lucroVirtual <= -Math.abs(config.stopLoss) || banca.redsConsecutivos >= config.maxReds;
  const inCooldown = mesa.cooldownSniper > 0 || mesa.cooldownTerm > 0;
  if (!stillPending && !candidate && !stopped && !inCooldown) {
    const detected = candidateFromSnapshot(snapshot, config);
    const requiredConfirmations = Math.max(1, strategyConfigFromRuntime(config).confirmationSpins);
    if (detected) {
      const fingerprint = `${detected.nome}|${detected.alvo_central ?? detected.alvos[0] ?? ""}|${detected.gatilho_str.split("•")[0]}`;
      const previousConfirmation = prev.confirmation;
      if (requiredConfirmations > 1 && (!previousConfirmation || previousConfirmation.fingerprint !== fingerprint)) {
        return {
          state: {
            signals,
            confirmation: { count: 1, fingerprint, spinId: newestId },
            lastProcessedSpinId: newestId,
            lastResolvedSpinId: prev.lastResolvedSpinId ?? null,
            candidate: null,
            mesa,
            banca,
          },
          created: null,
          snapshot: { ...snapshot, phase: "CONFIRMACAO" },
        };
      }
      if (requiredConfirmations > 1 && previousConfirmation && previousConfirmation.fingerprint === fingerprint && previousConfirmation.count + 1 < requiredConfirmations) {
        return {
          state: {
            signals,
            confirmation: { count: previousConfirmation.count + 1, fingerprint, spinId: newestId },
            lastProcessedSpinId: newestId,
            lastResolvedSpinId: prev.lastResolvedSpinId ?? null,
            candidate: null,
            mesa,
            banca,
          },
          created: null,
          snapshot: { ...snapshot, phase: "CONFIRMACAO" },
        };
      }
      created = candidateToSignal(detected, spins[0]);
      created = {
        ...created,
        apostaStr: detected.aposta_str,
        galeAtual: 0,
        isTermo: false,
        alvoCentral: detected.alvo_central,
        consensus: snapshot.consensus.consensus,
        consensusTotal: snapshot.consensus.consensusTotal,
        explanation: snapshot.consensus.contributions,
      };
      candidate = detected;
      signals = [created, ...signals].slice(0, MAX_SIGNALS);
    }
  }

  const justResolved = signals.find(
    (signal) =>
      (signal.result === "GREEN" || signal.result === "RED") &&
      signal.resolvedSpinId &&
      !(prev.signals ?? []).find((item) => item.id === signal.id && item.result !== "PENDING"),
  );

  return {
    state: {
      signals,
      confirmation: created ? null : prev.confirmation,
      lastProcessedSpinId: newestId,
      lastResolvedSpinId: justResolved?.resolvedSpinId ?? prev.lastResolvedSpinId ?? null,
      candidate,
      mesa,
      banca,
    },
    created,
    snapshot: {
      ...snapshot,
      phase: created ? "SINAL_ATIVO" : pendingUi?.phase ?? (candidate ? "G0" : snapshot.phase),
    },
  };
}

export function passesQuality(
  snapshot: EngineSnapshot,
  config: V19RuntimeConfig | StrategyEngineConfig = defaultRuntime(),
): boolean {
  const engineConfig = strategyConfigFromRuntime(config);
  const consensus = snapshot.consensus;
  const top = consensus.ranking[0];
  if (snapshot.insufficient || consensus.status !== "PRONTO") return false;
  if (consensus.score < engineConfig.minScore) return false;
  if (consensus.consensus < engineConfig.minConsensus) return false;
  if (!top || top.votes.length < engineConfig.minConsensus) return false;
  if (!snapshot.strategies.some((item) => item.status === "PRONTO" && item.candidates.length > 0)) return false;
  return true;
}
