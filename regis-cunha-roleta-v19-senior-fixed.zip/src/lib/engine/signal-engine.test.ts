import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { buildEngineConfig } from "../config/strategies.ts";
import { clusteredSpins, prependSpin, shortSpins, uniformSpins } from "./fixtures.ts";
import { emptyEngineState, evaluateEngine, passesQuality, resolveSignals, runSignalCycle } from "./signal-engine.ts";

function liveConfig(overrides: Parameters<typeof buildEngineConfig>[0] = {}) {
  return buildEngineConfig({
    minScore: 8,
    minConsensus: 1,
    cooldownSpins: 0,
    confirmationSpins: 1,
    maxGales: 2,
    analysisWindow: 80,
    ...overrides,
  });
}

describe("ciclo do sinal", () => {
  it("não cria sinal com dados insuficientes", () => {
    const config = liveConfig();
    const cycle = runSignalCycle({ spins: shortSpins(10), state: emptyEngineState(), config });
    assert.equal(cycle.created, null);
    assert.equal(cycle.snapshot.insufficient, true);
    assert.match(cycle.snapshot.consensus.reasons[0]?.text ?? "", /DADOS INSUFICIENTES/);
  });

  it("não cria sinal em distribuição uniforme", () => {
    const config = liveConfig({ minScore: 16, minConsensus: 2 });
    const cycle = runSignalCycle({ spins: uniformSpins(80), state: emptyEngineState(), config });
    assert.equal(cycle.created, null);
    assert.notEqual(cycle.snapshot.phase, "SINAL_ATIVO");
  });

  it("não cria sinal quando o score mínimo não é atingido", () => {
    const config = liveConfig({ minScore: 99, minConsensus: 1 });
    const snapshot = evaluateEngine(clusteredSpins(80), config);
    assert.equal(passesQuality(snapshot, config), false);
    const cycle = runSignalCycle({ spins: clusteredSpins(80), state: emptyEngineState(), config });
    assert.equal(cycle.created, null);
  });

  it("cria sinal quando a condição mínima é atingida", () => {
    const config = liveConfig({ minScore: 6, minConsensus: 1, focus: "SNIPER" });
    const cycle = runSignalCycle({ spins: clusteredSpins(80), state: emptyEngineState(), config });
    assert.ok(cycle.created, "esperava um sinal SNIPER");
    assert.equal(cycle.created.result, "PENDING");
    assert.equal(cycle.created.phase, "SINAL_ATIVO");
    assert.ok(cycle.created.targets.length > 0);
    assert.ok(cycle.created.explanation.length > 0);
    assert.ok(cycle.created.score >= 0);
  });

  it("respeita confirmação em dois giros", () => {
    const config = liveConfig({ minScore: 6, minConsensus: 1, focus: "SNIPER", confirmationSpins: 2, cooldownSpins: 0 });
    let spins = clusteredSpins(80);
    let cycle = runSignalCycle({ spins, state: emptyEngineState(), config });
    assert.equal(cycle.created, null);
    assert.equal(cycle.snapshot.phase, "CONFIRMACAO");
    spins = prependSpin(spins, 17);
    cycle = runSignalCycle({ spins, state: cycle.state, config });
    assert.ok(cycle.created, "segundo giro alinhado deve promover a sinal ativo");
    assert.equal(cycle.created.phase, "SINAL_ATIVO");
  });

  it("não cria outro sinal enquanto um está ativo", () => {
    const config = liveConfig({ minScore: 6, minConsensus: 1, focus: "SNIPER", cooldownSpins: 0 });
    let spins = clusteredSpins(80);
    let cycle = runSignalCycle({ spins, state: emptyEngineState(), config });
    assert.ok(cycle.created);
    spins = prependSpin(spins, 0);
    cycle = runSignalCycle({ spins, state: cycle.state, config });
    assert.equal(cycle.created, null);
    assert.equal(cycle.state.signals.filter((item) => item.result === "PENDING").length, 1);
  });

  it("acompanha G0 / G1 / G2 e fecha GREEN", () => {
    const config = liveConfig({ minScore: 6, minConsensus: 1, focus: "SNIPER", cooldownSpins: 0, maxGales: 2 });
    let spins = clusteredSpins(80);
    let cycle = runSignalCycle({ spins, state: emptyEngineState(), config });
    const signal = cycle.created;
    assert.ok(signal);
    const miss = [0, 1, 3, 8, 11, 13, 14, 15, 16, 19].find((number) => !signal.targets.includes(number)) ?? 0;
    spins = prependSpin(spins, miss);
    cycle = runSignalCycle({ spins, state: cycle.state, config });
    const g0 = cycle.state.signals[0];
    assert.equal(g0.result, "PENDING");
    assert.equal(g0.phase, "G0");

    spins = prependSpin(spins, miss);
    cycle = runSignalCycle({ spins, state: cycle.state, config });
    assert.equal(cycle.state.signals[0].phase, "G1");

    const hit = signal.targets[0];
    spins = prependSpin(spins, hit);
    cycle = runSignalCycle({ spins, state: cycle.state, config });
    const closed = cycle.state.signals.find((item) => item.id === signal.id);
    assert.ok(closed);
    assert.equal(closed.result, "GREEN");
    assert.equal(closed.phase, "GREEN");
    assert.equal(closed.galeHit, 2);
  });

  it("fecha RED depois de G2 sem acerto", () => {
    const config = liveConfig({ minScore: 6, minConsensus: 1, focus: "SNIPER", cooldownSpins: 0, maxGales: 2 });
    let spins = clusteredSpins(80);
    let cycle = runSignalCycle({ spins, state: emptyEngineState(), config });
    const signal = cycle.created;
    assert.ok(signal);
    const miss = [0, 1, 3, 8, 11, 13, 14, 15, 16, 19].find((number) => !signal.targets.includes(number)) ?? 0;
    spins = prependSpin(spins, miss);
    cycle = runSignalCycle({ spins, state: cycle.state, config });
    assert.equal(cycle.state.signals[0].phase, "G0");
    spins = prependSpin(spins, miss);
    cycle = runSignalCycle({ spins, state: cycle.state, config });
    assert.equal(cycle.state.signals[0].phase, "G1");
    spins = prependSpin(spins, miss);
    cycle = runSignalCycle({ spins, state: cycle.state, config });
    const closed = cycle.state.signals.find((item) => item.id === signal.id);
    assert.ok(closed);
    assert.equal(closed.result, "RED");
    assert.equal(closed.phase, "RED");
  });

  it("GREEN em G0 quando o primeiro giro acerta o alvo", () => {
    const config = liveConfig({ minScore: 6, minConsensus: 1, focus: "SNIPER", cooldownSpins: 0 });
    let spins = clusteredSpins(80);
    let cycle = runSignalCycle({ spins, state: emptyEngineState(), config });
    const signal = cycle.created;
    assert.ok(signal);
    spins = prependSpin(spins, signal.targets[0]);
    const resolved = resolveSignals(cycle.state.signals, spins)[0];
    assert.equal(resolved.result, "GREEN");
    assert.equal(resolved.galeHit, 0);
  });

  it("cooldown impede novo sinal logo após o RED", () => {
    const config = liveConfig({ minScore: 6, minConsensus: 1, focus: "SNIPER", cooldownSpins: 3, maxGales: 0 });
    let spins = clusteredSpins(80);
    let cycle = runSignalCycle({ spins, state: emptyEngineState(), config });
    assert.ok(cycle.created);
    const miss = [0, 1, 3, 8, 11].find((number) => !cycle.created!.targets.includes(number)) ?? 0;
    spins = prependSpin(spins, miss);
    cycle = runSignalCycle({ spins, state: cycle.state, config });
    assert.equal(cycle.state.signals[0].result, "RED");
    spins = prependSpin(spins, 17);
    cycle = runSignalCycle({ spins, state: cycle.state, config });
    assert.equal(cycle.created, null, "ainda em cooldown");
  });
});

it("suporta configuração de até 6 gales sem truncar o estado", () => {
  const config = liveConfig({ minScore: 6, minConsensus: 1, focus: "SNIPER", cooldownSpins: 0, maxGales: 6 });
  let spins = clusteredSpins(80);
  let cycle = runSignalCycle({ spins, state: emptyEngineState(), config });
  assert.ok(cycle.created);
  const miss = [0, 1, 3, 8, 11, 13, 14, 15, 16, 19].find((number) => !cycle.created!.targets.includes(number)) ?? 0;
  for (let expectedGale = 1; expectedGale <= 6; expectedGale += 1) {
    spins = prependSpin(spins, miss);
    cycle = runSignalCycle({ spins, state: cycle.state, config });
    assert.equal(cycle.state.candidate?.gale_atual, expectedGale);
    assert.equal(cycle.state.signals[0]?.maxGales, 6);
  }
  spins = prependSpin(spins, miss);
  cycle = runSignalCycle({ spins, state: cycle.state, config });
  assert.equal(cycle.state.signals[0]?.result, "RED");
  assert.equal(cycle.state.signals[0]?.galeAtual, 6);
});
