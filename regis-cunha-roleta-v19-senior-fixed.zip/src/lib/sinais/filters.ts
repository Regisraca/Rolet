import { getWheelNeighbors, tagForNumber, WHEEL_SECTORS, type Spin } from "@/lib/analise/roulette";

export const FILTER_IDS = [
  "frequencia",
  "atrasos",
  "quentes",
  "frios",
  "repeticoes",
  "vizinhos",
  "terminais",
  "setores",
  "cor",
  "paridade",
  "altoBaixo",
  "duzias",
  "colunas",
] as const;

export type FilterId = (typeof FILTER_IDS)[number];

export type FilterConfig = Record<FilterId, { enabled: boolean; weight: number }>;

export type FilterContribution = {
  id: FilterId;
  name: string;
  points: number;
  numbers: number[];
  reason: string;
};

export type AnalysisContext = {
  history: number[];
  spins: Spin[];
  window: number;
};

export type RouletteFilter = {
  id: FilterId;
  name: string;
  description: string;
  evaluate: (ctx: AnalysisContext, weight: number) => Omit<FilterContribution, "id" | "name"> | null;
};

export const DEFAULT_FILTERS: FilterConfig = {
  frequencia: { enabled: true, weight: 1 },
  atrasos: { enabled: true, weight: 1 },
  quentes: { enabled: true, weight: 1 },
  frios: { enabled: true, weight: 1 },
  repeticoes: { enabled: true, weight: 1 },
  vizinhos: { enabled: true, weight: 1 },
  terminais: { enabled: true, weight: 1 },
  setores: { enabled: true, weight: 1 },
  cor: { enabled: false, weight: 1 },
  paridade: { enabled: false, weight: 1 },
  altoBaixo: { enabled: false, weight: 1 },
  duzias: { enabled: true, weight: 1 },
  colunas: { enabled: true, weight: 1 },
};

function countsOf(history: number[]) {
  const counts = Array.from({ length: 37 }, () => 0);
  for (const number of history) counts[number] += 1;
  return counts;
}

function lastSeenOf(history: number[], number: number) {
  const index = history.indexOf(number);
  return index < 0 ? history.length : index;
}

function topFamily(history: number[], tags: string[]) {
  return tags
    .map((tag) => ({
      tag,
      hits: history.filter((number) => tagForNumber(number, tag)).length,
    }))
    .sort((a, b) => b.hits - a.hits)[0];
}

function numbersForTag(tag: string) {
  return Array.from({ length: 37 }, (_, number) => number).filter((number) => tagForNumber(number, tag));
}

export const FILTER_CATALOG: RouletteFilter[] = [
  {
    id: "frequencia",
    name: "Frequência",
    description: "Números acima da frequência esperada na janela.",
    evaluate(ctx, weight) {
      if (ctx.history.length < 12) return null;
      const expected = ctx.history.length / 37;
      const counts = countsOf(ctx.history);
      const numbers = counts
        .map((count, number) => ({ number, count }))
        .filter((item) => item.count >= expected * 1.6)
        .sort((a, b) => b.count - a.count)
        .slice(0, 6)
        .map((item) => item.number);
      if (numbers.length === 0) return null;
      return {
        points: Math.round(5 * weight),
        numbers,
        reason: `${numbers.length} números acima da frequência esperada`,
      };
    },
  },
  {
    id: "atrasos",
    name: "Atrasos",
    description: "Números com atraso elevado em relação à volta da roda.",
    evaluate(ctx, weight) {
      const delayed = Array.from({ length: 37 }, (_, number) => ({
        number,
        lastSeen: lastSeenOf(ctx.history, number),
      }))
        .filter((item) => item.lastSeen >= 24)
        .sort((a, b) => b.lastSeen - a.lastSeen)
        .slice(0, 5);
      if (delayed.length === 0) return null;
      return {
        points: Math.round(6 * weight),
        numbers: delayed.map((item) => item.number),
        reason: `Maior atraso ${delayed[0].lastSeen} giros (${delayed[0].number})`,
      };
    },
  },
  {
    id: "quentes",
    name: "Números quentes",
    description: "Mais frequentes da janela recente.",
    evaluate(ctx, weight) {
      const counts = countsOf(ctx.history);
      const hot = counts
        .map((count, number) => ({ number, count }))
        .filter((item) => item.count > 0)
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);
      if (!hot[0] || hot[0].count < 2) return null;
      return {
        points: Math.round(4 * weight),
        numbers: hot.map((item) => item.number),
        reason: `${hot[0].number} saiu ${hot[0].count}x na janela`,
      };
    },
  },
  {
    id: "frios",
    name: "Números frios",
    description: "Baixa frequência combinada com atraso.",
    evaluate(ctx, weight) {
      const counts = countsOf(ctx.history);
      const cold = counts
        .map((count, number) => ({ number, count, lastSeen: lastSeenOf(ctx.history, number) }))
        .filter((item) => item.count <= 1 && item.lastSeen >= 18)
        .sort((a, b) => b.lastSeen - a.lastSeen)
        .slice(0, 5);
      if (cold.length === 0) return null;
      return {
        points: Math.round(3 * weight),
        numbers: cold.map((item) => item.number),
        reason: `${cold.length} números frios com atraso alto`,
      };
    },
  },
  {
    id: "repeticoes",
    name: "Repetições",
    description: "Último número e recência de repetição.",
    evaluate(ctx, weight) {
      const last = ctx.history[0];
      if (last === undefined) return null;
      const recent = ctx.history.slice(0, 12).filter((number) => number === last).length;
      if (recent < 2) return null;
      return {
        points: Math.round((3 + recent) * weight),
        numbers: [last, ...getWheelNeighbors(last, 1).filter((number) => number !== last)].slice(0, 5),
        reason: `${last} repetiu ${recent}x nos últimos 12`,
      };
    },
  },
  {
    id: "vizinhos",
    name: "Vizinhos",
    description: "Zona física da roda ao redor dos últimos resultados.",
    evaluate(ctx, weight) {
      const last = ctx.history[0];
      if (last === undefined) return null;
      const zone = getWheelNeighbors(last, 2);
      const momentum = ctx.history.slice(0, 20).filter((number) => zone.includes(number)).length;
      if (momentum < 3) return null;
      return {
        points: Math.round((4 + Math.min(6, momentum)) * weight),
        numbers: zone,
        reason: `Zona de ${last} com ${momentum} hits em 20`,
      };
    },
  },
  {
    id: "terminais",
    name: "Terminais",
    description: "Finais 0–9 com concentração acima do acaso.",
    evaluate(ctx, weight) {
      const window = ctx.history.slice(0, Math.max(20, ctx.window));
      const counts = Array.from({ length: 10 }, (_, terminal) => ({
        terminal,
        hits: window.filter((number) => number % 10 === terminal).length,
      })).sort((a, b) => b.hits - a.hits);
      const top = counts[0];
      if (!top || top.hits < 3) return null;
      const numbers = Array.from({ length: 37 }, (_, number) => number).filter(
        (number) => number % 10 === top.terminal,
      );
      return {
        points: Math.round((5 + top.hits) * weight),
        numbers,
        reason: `T${top.terminal} com ${top.hits} ocorrências`,
      };
    },
  },
  {
    id: "setores",
    name: "Setores da roda",
    description: "Terços físicos P1 / P2 / P3.",
    evaluate(ctx, weight) {
      const window = ctx.history.slice(0, 24);
      const ranked = (["P1", "P2", "P3"] as const)
        .map((tag) => ({ tag, hits: window.filter((number) => tagForNumber(number, tag)).length }))
        .sort((a, b) => b.hits - a.hits);
      const top = ranked[0];
      if (!top || top.hits < 8) return null;
      return {
        points: Math.round(5 * weight),
        numbers: [...WHEEL_SECTORS[top.tag]],
        reason: `${top.tag} concentrou ${top.hits}/24`,
      };
    },
  },
  {
    id: "cor",
    name: "Vermelho / preto",
    description: "Momentum de cor na janela curta.",
    evaluate(ctx, weight) {
      const window = ctx.history.slice(0, 16).filter((number) => number > 0);
      const family = topFamily(window, ["R", "B"]);
      if (!family || family.hits < 10) return null;
      return {
        points: Math.round(3 * weight),
        numbers: numbersForTag(family.tag),
        reason: `${family.tag === "R" ? "Vermelho" : "Preto"} com ${family.hits}/16`,
      };
    },
  },
  {
    id: "paridade",
    name: "Par / ímpar",
    description: "Momentum de paridade na janela curta.",
    evaluate(ctx, weight) {
      const window = ctx.history.slice(0, 16).filter((number) => number > 0);
      const family = topFamily(window, ["P", "O"]);
      if (!family || family.hits < 10) return null;
      return {
        points: Math.round(3 * weight),
        numbers: numbersForTag(family.tag),
        reason: `${family.tag === "P" ? "Par" : "Ímpar"} com ${family.hits}/16`,
      };
    },
  },
  {
    id: "altoBaixo",
    name: "Baixo / alto",
    description: "Faixas 1–18 e 19–36.",
    evaluate(ctx, weight) {
      const window = ctx.history.slice(0, 16).filter((number) => number > 0);
      const family = topFamily(window, ["L", "H"]);
      if (!family || family.hits < 10) return null;
      return {
        points: Math.round(3 * weight),
        numbers: numbersForTag(family.tag),
        reason: `${family.tag === "L" ? "1–18" : "19–36"} com ${family.hits}/16`,
      };
    },
  },
  {
    id: "duzias",
    name: "Dúzias",
    description: "Dúzia com maior concentração recente.",
    evaluate(ctx, weight) {
      const window = ctx.history.slice(0, 18);
      const family = topFamily(window, ["D1", "D2", "D3"]);
      if (!family || family.hits < 8) return null;
      return {
        points: Math.round(4 * weight),
        numbers: numbersForTag(family.tag),
        reason: `${family.tag} com ${family.hits}/18`,
      };
    },
  },
  {
    id: "colunas",
    name: "Colunas",
    description: "Coluna com maior concentração recente.",
    evaluate(ctx, weight) {
      const window = ctx.history.slice(0, 18);
      const family = topFamily(window, ["C1", "C2", "C3"]);
      if (!family || family.hits < 8) return null;
      return {
        points: Math.round(4 * weight),
        numbers: numbersForTag(family.tag),
        reason: `${family.tag} com ${family.hits}/18`,
      };
    },
  },
];

export function evaluateFilters(ctx: AnalysisContext, config: FilterConfig) {
  const hits: FilterContribution[] = [];
  for (const filter of FILTER_CATALOG) {
    const setting = config[filter.id];
    if (!setting?.enabled) continue;
    const result = filter.evaluate(ctx, setting.weight);
    if (result && result.numbers.length > 0) {
      hits.push({ id: filter.id, name: filter.name, ...result });
    }
  }
  return hits;
}
