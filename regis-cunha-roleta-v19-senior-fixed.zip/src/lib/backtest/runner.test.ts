import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { clusteredSpins, shortSpins } from "../engine/fixtures.ts";
import { compareStrategies, sweepMinScore } from "./comparison.ts";
import { runBacktest } from "./runner.ts";

describe("backtest e comparação", () => {
  it("roda cada estratégia de forma independente", () => {
    const spins = clusteredSpins(160);
    const sniper = runBacktest({ spins, minScore: 6, maxGales: 2, window: 50, strategy: "sniper", cooldownSpins: 2 });
    const termo = runBacktest({ spins, minScore: 6, maxGales: 2, window: 50, strategy: "termo", cooldownSpins: 2 });
    assert.equal(sniper.strategy, "sniper");
    assert.equal(termo.strategy, "termo");
    assert.ok(sniper.signals >= 0);
    assert.equal(sniper.g0 + sniper.g1 + sniper.g2, sniper.greens);
  });

  it("marca DADOS INSUFICIENTES quando a amostra é curta", () => {
    const result = runBacktest({
      spins: shortSpins(20),
      minScore: 6,
      maxGales: 2,
      window: 50,
      strategy: "consenso",
    });
    assert.equal(result.insufficient, true);
    assert.equal(result.note, "DADOS INSUFICIENTES");
  });

  it("compara as cinco linhas do laboratório", () => {
    const rows = compareStrategies({
      spins: clusteredSpins(140),
      minScore: 6,
      maxGales: 2,
      window: 50,
      cooldownSpins: 2,
    });
    assert.equal(rows.length, 5);
    assert.deepEqual(
      rows.map((row) => row.label),
      ["SNIPER", "TERMO", "QUANT", "MODELO", "CONSENSO"],
    );
    for (const row of rows) {
      assert.equal(row.g0 + row.g1 + row.g2, row.greens);
    }
  });

  it("varre limiares de score sem inventar máquina de aprendizado", () => {
    const rows = sweepMinScore({
      spins: clusteredSpins(140),
      maxGales: 2,
      window: 50,
      strategy: "sniper",
      cooldownSpins: 2,
    });
    assert.equal(rows.length, 4);
    assert.ok(rows.every((row) => row.label.startsWith("Score ")));
  });
});
