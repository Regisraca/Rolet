import type { Signal, Spin } from "@/lib/analise/roulette";
import { buildEngineConfig, type StrategyEngineConfig } from "@/lib/config/strategies";
import { emptyEngineState, runSignalCycle } from "@/lib/engine/signal-engine";
import { summarizeSignals, type BacktestMetrics } from "@/lib/backtest/metrics";

export type BacktestStrategy = "sniper" | "termo" | "quant" | "modelo" | "consenso";

export type BacktestInput = {
  spins: Spin[];
  minScore: number;
  maxGales: number;
  window: number;
  strategy: BacktestStrategy;
  cooldownSpins?: number;
  minConsensus?: number;
  confirmationSpins?: number;
};

export type BacktestResult = BacktestMetrics & {
  strategy: BacktestStrategy;
};

export function configForBacktest(input: BacktestInput): StrategyEngineConfig {
  const focus =
    input.strategy === "sniper"
      ? "SNIPER"
      : input.strategy === "termo"
        ? "TERMO"
        : input.strategy === "quant"
          ? "QUANT"
          : input.strategy === "modelo"
            ? "MODELO"
            : null;

  return buildEngineConfig({
    minScore: input.minScore,
    maxGales: input.maxGales,
    analysisWindow: input.window,
    cooldownSpins: input.cooldownSpins,
    confirmationSpins: input.confirmationSpins ?? 1,
    minConsensus: input.minConsensus ?? (focus && focus !== "MODELO" ? 1 : 2),
    focus,
  });
}

export function runBacktest(input: BacktestInput): BacktestResult {
  const chronological = [...input.spins].slice().reverse();
  const config = configForBacktest(input);
  const start = Math.max(config.minHistory, input.window > 0 ? Math.min(input.window, config.minHistory) : config.minHistory);
  let state = emptyEngineState();
  const coverages: number[] = [];
  const closed: Signal[] = [];

  for (let i = start; i < chronological.length; i += 1) {
    const historyNewestFirst = chronological.slice(0, i + 1).slice().reverse();
    const cycle = runSignalCycle({ spins: historyNewestFirst, state, config });
    state = cycle.state;
    if (cycle.created) coverages.push(cycle.created.targets.length);
    const stillOpen = [];
    for (const signal of state.signals) {
      if (signal.result === "PENDING") stillOpen.push(signal);
      else if (!closed.some((item) => item.id === signal.id)) closed.push(signal);
    }
    state = { ...state, signals: stillOpen };
  }

  const remaining = state.signals;
  const all = [...closed, ...remaining];
  const metrics = summarizeSignals(input.spins.length, all, input.maxGales, coverages);
  return { ...metrics, strategy: input.strategy };
}
