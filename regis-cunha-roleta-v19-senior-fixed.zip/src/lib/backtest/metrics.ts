import { expectedHitRate, missCost, netIfHit, wilsonLowerBound } from "@/lib/analise/quant";
import type { Signal } from "@/lib/analise/roulette";
import { MIN_BACKTEST_SIGNALS } from "@/lib/config/app";

export type BacktestMetrics = {
  sample: number;
  signals: number;
  greens: number;
  reds: number;
  pending: number;
  hitRate: number | null;
  g0: number;
  g1: number;
  g2: number;
  maxLosingStreak: number;
  drawdown: number;
  units: number;
  avgCoverage: number;
  baseline: number;
  wilson: number | null;
  edge: number | null;
  insufficient: boolean;
  note: string;
};

export function summarizeSignals(sample: number, signals: Signal[], maxGales: number, coverages: number[]): BacktestMetrics {
  const decided = signals.filter((signal) => signal.result !== "PENDING");
  const greens = decided.filter((signal) => signal.result === "GREEN");
  const reds = decided.filter((signal) => signal.result === "RED");

  let bank = 0;
  let peak = 0;
  let drawdown = 0;
  let losing = 0;
  let maxLosing = 0;
  let g0 = 0;
  let g1 = 0;
  let g2 = 0;

  for (const signal of decided) {
    const coverage = Math.max(1, signal.targets.length);
    if (signal.result === "GREEN") {
      const gale = signal.galeHit ?? 0;
      if (gale === 0) g0 += 1;
      else if (gale === 1) g1 += 1;
      else g2 += 1;
      bank += netIfHit(coverage, gale);
      losing = 0;
    } else {
      bank -= missCost(coverage, signal.maxGales);
      losing += 1;
      maxLosing = Math.max(maxLosing, losing);
    }
    peak = Math.max(peak, bank);
    drawdown = Math.min(drawdown, bank - peak);
  }

  const avgCoverage =
    coverages.length > 0 ? coverages.reduce((sum, value) => sum + value, 0) / coverages.length : 0;
  const baseline = expectedHitRate(avgCoverage || 5, maxGales + 1);
  const hitRate = decided.length > 0 ? greens.length / decided.length : null;
  const wilson = decided.length > 0 ? wilsonLowerBound(greens.length, decided.length) : null;
  const insufficient = decided.length < MIN_BACKTEST_SIGNALS;

  return {
    sample,
    signals: signals.length,
    greens: greens.length,
    reds: reds.length,
    pending: signals.length - decided.length,
    hitRate,
    g0,
    g1,
    g2,
    maxLosingStreak: maxLosing,
    drawdown: Math.round(drawdown * 10) / 10,
    units: Math.round(bank * 10) / 10,
    avgCoverage: Math.round(avgCoverage * 10) / 10,
    baseline,
    wilson,
    edge: hitRate === null ? null : hitRate - baseline,
    insufficient,
    note: insufficient
      ? "DADOS INSUFICIENTES"
      : "Resultado hipotético em unidades, 1 ficha por número-alvo, gale clássico. Evidência histórica, não garantia futura.",
  };
}
