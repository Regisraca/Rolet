import type { FilterConfig } from "@/lib/sinais/filters";
import { runBacktest as runStrategyBacktest, type BacktestInput, type BacktestResult, type BacktestStrategy } from "@/lib/backtest/runner";

export type { BacktestResult, BacktestStrategy } from "@/lib/backtest/runner";
export { compareStrategies, sweepMinScore } from "@/lib/backtest/comparison";

export type LegacyBacktestInput = BacktestInput & {
  filters?: FilterConfig;
};

export function runBacktest(input: LegacyBacktestInput): BacktestResult {
  return runStrategyBacktest(input);
}
