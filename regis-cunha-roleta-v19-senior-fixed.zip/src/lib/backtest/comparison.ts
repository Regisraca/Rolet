import { SCORE_SWEEP_VALUES } from "@/lib/config/strategies";
import { runBacktest, type BacktestInput, type BacktestResult, type BacktestStrategy } from "@/lib/backtest/runner";

export const COMPARISON_STRATEGIES: { id: BacktestStrategy; label: string }[] = [
  { id: "sniper", label: "SNIPER" },
  { id: "termo", label: "TERMO" },
  { id: "quant", label: "QUANT" },
  { id: "modelo", label: "MODELO" },
  { id: "consenso", label: "CONSENSO" },
];

export type ComparisonRow = BacktestResult & { label: string };

export function compareStrategies(base: Omit<BacktestInput, "strategy">): ComparisonRow[] {
  return COMPARISON_STRATEGIES.map((item) => ({
    label: item.label,
    ...runBacktest({ ...base, strategy: item.id }),
  }));
}

export function sweepMinScore(
  base: Omit<BacktestInput, "minScore">,
  values: readonly number[] = SCORE_SWEEP_VALUES,
): ComparisonRow[] {
  return values.map((minScore) => ({
    label: `Score ${minScore}`,
    ...runBacktest({ ...base, minScore }),
  }));
}
