export * from "@/lib/config/tables";
