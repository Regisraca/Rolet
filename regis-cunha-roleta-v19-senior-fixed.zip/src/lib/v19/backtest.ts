import { classificarNumero, expandirAlvos } from "@/lib/v19/classify";
import type { EstrategiaV19 } from "@/lib/v19/classify";

export type BacktestResultado = {
  total_entradas: number;
  greens: number;
  reds: number;
  assertividade: number;
  max_drawdown: number;
  gatilho: string[];
  alvos: string[];
  max_gales: number;
};

export function simularEstrategia(
  historico: number[],
  gatilhoList: string[],
  alvosExpandidos: string[],
  maxGales: number,
): BacktestResultado {
  let greens = 0;
  let reds = 0;
  let totalEntradas = 0;
  let maxDrawdown = 0;
  let drawdownAtual = 0;
  const historicoTags = historico.map(classificarNumero);
  const tamanhoGatilho = gatilhoList.length;
  let i = tamanhoGatilho;

  while (i < historicoTags.length) {
    let match = true;
    if (i >= tamanhoGatilho) {
      const subHist = historicoTags.slice(i - tamanhoGatilho, i);
      for (let idx = 0; idx < gatilhoList.length; idx += 1) {
        if (!subHist[idx].includes(gatilhoList[idx])) {
          match = false;
          break;
        }
      }
    } else {
      match = false;
    }

    if (match) {
      totalEntradas += 1;
      let acertou = false;
      let galeUsado = 0;
      for (let g = 0; g <= maxGales; g += 1) {
        if (i + g < historicoTags.length) {
          const numSeguinte = String(historico[i + g]);
          const tagsSeguinte = historicoTags[i + g];
          if (alvosExpandidos.includes(numSeguinte) || alvosExpandidos.some((alvo) => tagsSeguinte.includes(alvo))) {
            acertou = true;
            galeUsado = g;
            break;
          }
        }
        galeUsado = g;
      }
      if (acertou) {
        greens += 1;
        drawdownAtual = 0;
      } else {
        reds += 1;
        drawdownAtual += 1;
        maxDrawdown = Math.max(maxDrawdown, drawdownAtual);
      }
      i += galeUsado + 1;
    } else {
      i += 1;
    }
  }

  const totalOperacoes = greens + reds;
  return {
    total_entradas: totalEntradas,
    greens,
    reds,
    assertividade: totalOperacoes > 0 ? (greens / totalOperacoes) * 100 : 0,
    max_drawdown: maxDrawdown,
    gatilho: gatilhoList,
    alvos: alvosExpandidos,
    max_gales: maxGales,
  };
}

export function backtestEstrategias(historico: number[], estrategias: EstrategiaV19[], profundidade = 250) {
  const nums = historico.length > profundidade ? historico.slice(-profundidade) : historico;
  if (nums.length < 10) return estrategias.map((est) => ({ ...est }));
  return estrategias.map((est) => {
    const alvos = expandirAlvos(est.aposta_str.replace(/,/g, " ").split(/\s+/).filter(Boolean));
    const result = simularEstrategia(nums, est.gatilho, alvos.length ? alvos : est.alvos, est.max_gales ?? 2);
    const total = result.greens + result.reds;
    return {
      ...est,
      greens: result.greens,
      reds: result.reds,
      pct: total > 0 ? (result.greens / total) * 100 : 0,
    };
  });
}
