import { VERMELHOS } from "@/lib/v19/constants";

export type RaioXMesa = {
  total: number;
  plenos: { n: number; c: number }[];
  terminais: { t: number; c: number }[];
  vermelho: number;
  preto: number;
  zero: number;
  d1: number;
  d2: number;
  d3: number;
  c1: number;
  c2: number;
  c3: number;
  par: number;
  impar: number;
};

export function calcPct(count: number, tot: number): number {
  return tot > 0 ? (count / tot) * 100 : 0;
}

export function raioXDaMesa(historico: number[], janela = 60): RaioXMesa | null {
  if (!historico.length) return null;
  const ultimos = historico.slice(-janela);
  const tot = ultimos.length;
  const contNums = new Map<number, number>();
  for (const n of ultimos) contNums.set(n, (contNums.get(n) ?? 0) + 1);
  const topNums = [...contNums.entries()]
    .sort((a, b) => b[1] - a[1] || ultimos.indexOf(a[0]) - ultimos.indexOf(b[0]))
    .slice(0, 5);
  const contTerms = Array.from({ length: 10 }, () => 0);
  for (const n of ultimos) contTerms[n % 10] += 1;
  const topTerms = contTerms
    .map((c, t) => ({ t, c }))
    .sort((a, b) => b.c - a.c)
    .slice(0, 3);

  const r = ultimos.filter((n) => VERMELHOS.has(n)).length;
  const z = ultimos.filter((n) => n === 0).length;
  const b = ultimos.filter((n) => n !== 0 && !VERMELHOS.has(n)).length;
  const d1 = ultimos.filter((n) => n >= 1 && n <= 12).length;
  const d2 = ultimos.filter((n) => n >= 13 && n <= 24).length;
  const d3 = ultimos.filter((n) => n >= 25 && n <= 36).length;
  const c1 = ultimos.filter((n) => n !== 0 && n % 3 === 1).length;
  const c2 = ultimos.filter((n) => n !== 0 && n % 3 === 2).length;
  const c3 = ultimos.filter((n) => n !== 0 && n % 3 === 0).length;
  const par = ultimos.filter((n) => n !== 0 && n % 2 === 0).length;
  const impar = ultimos.filter((n) => n !== 0 && n % 2 !== 0).length;

  return {
    total: tot,
    plenos: topNums.map(([n, c]) => ({ n, c })),
    terminais: topTerms,
    vermelho: calcPct(r, tot),
    preto: calcPct(b, tot),
    zero: calcPct(z, tot),
    d1: calcPct(d1, tot),
    d2: calcPct(d2, tot),
    d3: calcPct(d3, tot),
    c1: calcPct(c1, tot),
    c2: calcPct(c2, tot),
    c3: calcPct(c3, tot),
    par: calcPct(par, tot),
    impar: calcPct(impar, tot),
  };
}
