import { classificarNumero, expandirAlvos, limiteInferiorWilson, numerosCobertos, vizinhosRoda } from "@/lib/v19/classify";
import type { PadraoFamilia } from "@/lib/v19/constants";

export type CatalogoItem = {
  gatilho: string[];
  alvos: string[];
  nome: string;
  familia: PadraoFamilia;
};

export type PadraoMinerado = {
  nome: string;
  familia: PadraoFamilia;
  gatilho: string[];
  alvos: string[];
  alvos_expandidos: string[];
  cobertura: number;
  numeros_cobertos: number;
  greens: number;
  reds: number;
  total_entradas: number;
  assertividade: number;
  confianca: number;
  aleatorio: number;
  vantagem: number;
  vantagem_conf: number;
  max_drawdown: number;
  score: number;
  max_gales: number;
};

export function gerarCatalogoPadroes(historicoNums: number[]): CatalogoItem[] {
  const catalogo: CatalogoItem[] = [];
  const familias: Array<[PadraoFamilia, string[], Record<string, string>]> = [
    ["DÚZIA", ["D1", "D2", "D3"], { D1: "1ª Dúzia", D2: "2ª Dúzia", D3: "3ª Dúzia" }],
    ["COLUNA", ["C1", "C2", "C3"], { C1: "Coluna 1", C2: "Coluna 2", C3: "Coluna 3" }],
    ["COR", ["R", "B"], { R: "Vermelho", B: "Preto" }],
    ["PARIDADE", ["P", "O"], { P: "Par", O: "Ímpar" }],
    ["METADE", ["L", "H"], { L: "Baixas 1-18", H: "Altas 19-36" }],
    ["SETOR", ["P1", "P2", "P3"], { P1: "Setor 1", P2: "Setor 2", P3: "Setor 3" }],
  ];

  for (const [familia, tags, rotulos] of familias) {
    for (const tag of tags) {
      const complementares = tags.filter((t) => t !== tag);
      for (const repeticoes of [2, 3] as const) {
        const gatilho = Array.from({ length: repeticoes }, () => tag);
        catalogo.push({
          gatilho,
          alvos: complementares,
          nome: `Quebra ${repeticoes}x ${rotulos[tag]} ➔ ${complementares.map((c) => rotulos[c]).join("/")}`,
          familia,
        });
        catalogo.push({
          gatilho,
          alvos: [tag],
          nome: `Tendência ${repeticoes}x ${rotulos[tag]} ➔ ${rotulos[tag]}`,
          familia,
        });
      }
    }
  }

  for (let d = 0; d < 10; d += 1) {
    const tag = `T${d}`;
    const vizinhos = [`T${(d + 1) % 10}`, `T${(d - 1 + 10) % 10}`];
    catalogo.push({ gatilho: [tag], alvos: [tag], nome: `Puxada Terminal ${d} ➔ T${d}`, familia: "TERMINAL" });
    catalogo.push({
      gatilho: [tag],
      alvos: vizinhos,
      nome: `Terminal ${d} ➔ vizinhos ${vizinhos[0]}/${vizinhos[1]}`,
      familia: "TERMINAL",
    });
    catalogo.push({
      gatilho: [tag, tag],
      alvos: [tag, ...vizinhos],
      nome: `Terminal ${d} 2x ➔ cluster T${d}`,
      familia: "TERMINAL",
    });
  }

  const amostra = historicoNums.slice(-120);
  const contagem = new Map<number, number>();
  for (const n of amostra) contagem.set(n, (contagem.get(n) ?? 0) + 1);
  const quentes = [...contagem.entries()]
    .sort((a, b) => b[1] - a[1])
    .filter(([, c]) => c >= 2)
    .slice(0, 6)
    .map(([n]) => n);

  for (const num of quentes) {
    catalogo.push({
      gatilho: [String(num)],
      alvos: [String(num)],
      nome: `Repetição do Pleno ${num}`,
      familia: "PLENO",
    });
    catalogo.push({
      gatilho: [String(num)],
      alvos: vizinhosRoda(num, 2),
      nome: `Pleno ${num} ➔ vizinhos físicos (5 fichas)`,
      familia: "PLENO",
    });
    catalogo.push({
      gatilho: [String(num)],
      alvos: [`T${num % 10}`],
      nome: `Pleno ${num} ➔ Terminal ${num % 10}`,
      familia: "PLENO",
    });
  }

  return catalogo;
}

export function simularPadrao(
  historicoTags: string[][],
  gatilhoSeq: string[],
  alvosExpandidos: string[],
  maxGales: number,
): { greens: number; reds: number; maxDrawdown: number } {
  let greens = 0;
  let reds = 0;
  let maxDrawdown = 0;
  let drawdownAtual = 0;
  const alvos = new Set(alvosExpandidos);
  const tamanho = gatilhoSeq.length;
  let i = tamanho;
  const total = historicoTags.length;

  while (i < total) {
    const subHist = historicoTags.slice(i - tamanho, i);
    const match = gatilhoSeq.every((g, idx) => subHist[idx].includes(g));
    if (match) {
      let acertou = false;
      let galeUsado = 0;
      for (let g = 0; g <= maxGales; g += 1) {
        if (i + g >= total) break;
        galeUsado = g;
        if (historicoTags[i + g].some((tag) => alvos.has(tag))) {
          acertou = true;
          break;
        }
      }
      if (acertou) {
        greens += 1;
        drawdownAtual = 0;
      } else {
        reds += 1;
        drawdownAtual += 1;
        maxDrawdown = Math.max(maxDrawdown, drawdownAtual);
      }
      i += galeUsado + 1;
    } else {
      i += 1;
    }
  }

  return { greens, reds, maxDrawdown };
}

export function minerarPadroesAoVivo(historicoNums: number[], maxGales = 2): PadraoMinerado[] {
  if (historicoNums.length < 20) return [];

  const historicoTags = historicoNums.map(classificarNumero);
  const candidatos: PadraoMinerado[] = [];

  for (const item of gerarCatalogoPadroes(historicoNums)) {
    const alvosExpandidos = expandirAlvos(item.alvos);
    const cobertura = alvosExpandidos.length;
    const cobertos = numerosCobertos(alvosExpandidos);
    if (cobertos > 24) continue;

    const { greens, reds, maxDrawdown } = simularPadrao(historicoTags, item.gatilho, alvosExpandidos, maxGales);
    const operacoes = greens + reds;
    if (operacoes < (item.familia === "PLENO" ? 4 : 6)) continue;

    const assertividade = (greens / operacoes) * 100;
    const confianca = limiteInferiorWilson(greens, operacoes);
    const aleatorio = (1 - ((37 - cobertos) / 37) ** (maxGales + 1)) * 100;
    const vantagem = assertividade - aleatorio;
    const vantagemConf = confianca - aleatorio;
    const score = vantagemConf - maxDrawdown * 4;
    if (vantagem < 5 || vantagemConf <= 0) continue;

    candidatos.push({
      nome: item.nome,
      familia: item.familia,
      gatilho: [...item.gatilho],
      alvos: [...item.alvos],
      alvos_expandidos: alvosExpandidos,
      cobertura,
      numeros_cobertos: cobertos,
      greens,
      reds,
      total_entradas: operacoes,
      assertividade,
      confianca,
      aleatorio,
      vantagem,
      vantagem_conf: vantagemConf,
      max_drawdown: maxDrawdown,
      score,
      max_gales: maxGales,
    });
  }

  for (const [metaAssertividade, metaDrawdown] of [
    [85, 1],
    [85, 2],
    [78, 2],
    [70, 3],
  ] as const) {
    const selecionados = candidatos.filter(
      (c) => c.assertividade >= metaAssertividade && c.max_drawdown <= metaDrawdown,
    );
    if (selecionados.length) {
      selecionados.sort((a, b) => b.score - a.score);
      return selecionados.slice(0, 12);
    }
  }

  return [];
}

export function padraoParaEstrategia(padrao: PadraoMinerado) {
  const maxGales = padrao.max_gales ?? 2;
  return {
    nome: `QUANT • ${padrao.nome}`,
    gatilho_str: padrao.gatilho.join(" "),
    gatilho: [...padrao.gatilho],
    ausencia: false,
    aposta_str: padrao.alvos_expandidos.join(" "),
    alvos: [...padrao.alvos_expandidos],
    max_gales: maxGales,
    mults_gales: (["2x", "4x"] as string[]).slice(0, maxGales).length ? (["2x", "4x"] as string[]).slice(0, maxGales) : ["2x"],
    greens: 0,
    reds: 0,
    origem_quant: true,
    pct: padrao.assertividade,
  };
}
