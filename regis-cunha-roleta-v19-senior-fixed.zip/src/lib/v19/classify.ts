import { RODA_EUROPEIA, SETORES_FISICOS, TERMINAIS_MAP, VERMELHOS } from "@/lib/v19/constants";

export function classificarNumero(num: number): string[] {
  const tags = [String(num)];
  if (num === 0) {
    tags.push("T0", "P1");
  } else {
    if (num >= 1 && num <= 12) tags.push("D1");
    else if (num >= 13 && num <= 24) tags.push("D2");
    else if (num >= 25 && num <= 36) tags.push("D3");
    if (num % 3 === 1) tags.push("C1");
    else if (num % 3 === 2) tags.push("C2");
    else if (num % 3 === 0) tags.push("C3");
    tags.push(num >= 1 && num <= 18 ? "L" : "H");
    tags.push(num % 2 === 0 ? "P" : "O");
    tags.push(VERMELHOS.has(num) ? "R" : "B");
    tags.push(`T${num % 10}`);
  }

  for (const [setor, numeros] of Object.entries(SETORES_FISICOS)) {
    if (numeros.includes(num)) {
      tags.push(setor);
      break;
    }
  }
  return tags;
}

export function expandirAlvos(alvos: string[]): string[] {
  const expandidos: string[] = [];
  const seen = new Set<string>();
  for (const raw of alvos) {
    const alvo = String(raw);
    let extra: string[];
    if (alvo in SETORES_FISICOS) {
      extra = [...SETORES_FISICOS[alvo as keyof typeof SETORES_FISICOS]].sort((a, b) => a - b).map(String);
    } else if (alvo in TERMINAIS_MAP) {
      extra = TERMINAIS_MAP[alvo];
    } else {
      extra = [alvo];
    }
    for (const item of extra) {
      if (seen.has(item)) continue;
      seen.add(item);
      expandidos.push(item);
    }
  }
  return expandidos;
}

export function vizinhosRoda(numero: number, raio = 2): string[] {
  const pos = RODA_EUROPEIA.indexOf(numero as (typeof RODA_EUROPEIA)[number]);
  if (pos < 0) return [String(numero)];
  const total = RODA_EUROPEIA.length;
  const out: string[] = [];
  for (let d = -raio; d <= raio; d += 1) {
    out.push(String(RODA_EUROPEIA[(pos + d + total) % total]));
  }
  return out;
}

export function obterVizinhosCilindro(num: number, qtd: number): number[] {
  const idx = RODA_EUROPEIA.indexOf(num as (typeof RODA_EUROPEIA)[number]);
  if (idx < 0) return [num];
  const tamanho = RODA_EUROPEIA.length;
  const vizinhos: number[] = [];
  for (let i = -qtd; i <= qtd; i += 1) {
    vizinhos.push(RODA_EUROPEIA[(idx + i + tamanho) % tamanho]);
  }
  return vizinhos;
}

const NUMEROS_POR_TAG: Record<string, Set<number>> = {};

export function buildNumerosPorTag(): Record<string, Set<number>> {
  if (Object.keys(NUMEROS_POR_TAG).length > 0) return NUMEROS_POR_TAG;
  for (let n = 0; n <= 36; n += 1) {
    for (const tag of classificarNumero(n)) {
      if (!NUMEROS_POR_TAG[tag]) NUMEROS_POR_TAG[tag] = new Set();
      NUMEROS_POR_TAG[tag].add(n);
    }
  }
  return NUMEROS_POR_TAG;
}

export function numerosCobertos(alvosExpandidos: string[]): number {
  const table = buildNumerosPorTag();
  const casas = new Set<number>();
  for (const alvo of alvosExpandidos) {
    const set = table[String(alvo)];
    if (set) for (const n of set) casas.add(n);
  }
  return casas.size;
}

export function casasCobertas(alvosExpandidos: string[]): number[] {
  const table = buildNumerosPorTag();
  const casas = new Set<number>();
  for (const alvo of alvosExpandidos) {
    const set = table[String(alvo)];
    if (set) for (const n of set) casas.add(n);
  }
  return [...casas].sort((a, b) => a - b);
}

export function limiteInferiorWilson(greens: number, total: number): number {
  if (total <= 0) return 0;
  const z = 1.96;
  const p = greens / total;
  const denominador = 1 + z ** 2 / total;
  const centro = p + z ** 2 / (2 * total);
  const margem = z * Math.sqrt((p * (1 - p) + z ** 2 / (4 * total)) / total);
  return Math.max(0, (centro - margem) / denominador) * 100;
}

export type EstrategiaV19 = {
  nome?: string;
  gatilho_str: string;
  gatilho: string[];
  ausencia?: boolean;
  tag_ausencia?: string;
  aposta_str: string;
  alvos: string[];
  max_gales: number;
  mults_gales?: string[];
  greens?: number;
  reds?: number;
  origem_quant?: boolean;
  pct?: number;
};

export function verificarGatilho(historicoRodadas: string[][], est: Pick<EstrategiaV19, "gatilho" | "ausencia" | "tag_ausencia">): boolean {
  const alvoGatilho = est.gatilho;
  const isAusencia = Boolean(est.ausencia);

  if (!isAusencia) {
    if (!historicoRodadas.length) return false;
    if (alvoGatilho.length === 1) {
      const elemento = alvoGatilho[0];
      if (elemento === "N") return true;
      return historicoRodadas[historicoRodadas.length - 1].includes(elemento);
    }
    const tam = alvoGatilho.length;
    if (historicoRodadas.length < tam) return false;
    const sub = historicoRodadas.slice(-tam);
    for (let idx = 0; idx < tam; idx += 1) {
      const esperado = alvoGatilho[idx];
      if (esperado === "N") continue;
      if (!sub[idx].includes(esperado)) return false;
    }
    return true;
  }

  let limite = 5;
  try {
    limite = Number.parseInt(String(alvoGatilho[1]), 10);
    if (Number.isNaN(limite)) limite = 5;
  } catch {
    limite = 5;
  }
  const tagAlvo = est.tag_ausencia ?? "";
  let contador = 0;
  for (let i = historicoRodadas.length - 1; i >= 0; i -= 1) {
    if (historicoRodadas[i].includes(tagAlvo)) break;
    contador += 1;
  }
  return contador >= limite;
}

export function toChronological(numbersNewestFirst: number[]): number[] {
  return [...numbersNewestFirst].reverse();
}
