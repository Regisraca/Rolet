import { obterVizinhosCilindro } from "@/lib/v19/classify";
import { DEFAULT_V19, TERMINAIS_MAP } from "@/lib/v19/constants";

export type TermoSinal = {
  nome: string;
  gatilho_str: string;
  alvos: string[];
  alvo_central: string;
  is_termo: true;
  max_gales: number;
  greens: number;
  reds: number;
  pct: number;
  hits: number;
};

export type TermoParams = {
  janelaAmostra?: number;
  minHits?: number;
  qtdVizinhos?: number;
  minMeta?: number;
  maxGales?: number;
  cooldown?: number;
  ultimoAlvo?: string | null;
};

export function analisarTerminaisDinamicos(historicoBruto: number[], params: TermoParams = {}): TermoSinal | null {
  const janelaAmostra = params.janelaAmostra ?? DEFAULT_V19.amostra;
  const minHits = params.minHits ?? DEFAULT_V19.termHits;
  const qtdVizinhos = params.qtdVizinhos ?? DEFAULT_V19.termViz;
  const minMeta = params.minMeta ?? DEFAULT_V19.minAssertividade;
  const maxGalesSim = params.maxGales ?? DEFAULT_V19.maxGales;

  if (historicoBruto.length < janelaAmostra) return null;

  const janelaRecente = historicoBruto.slice(-janelaAmostra);
  const contTerms = Array.from({ length: 10 }, () => 0);
  for (const n of janelaRecente) contTerms[n % 10] += 1;

  let termId = 0;
  let hitsTerm = -1;
  for (let t = 0; t < 10; t += 1) {
    if (contTerms[t] > hitsTerm) {
      hitsTerm = contTerms[t];
      termId = t;
    }
  }
  if (hitsTerm < minHits) return null;
  if (params.cooldown && params.cooldown > 0 && params.ultimoAlvo === `T${termId}`) return null;

  const numerosBase = TERMINAIS_MAP[`T${termId}`];
  const alvos = new Set<string>();
  const zona: string[] = [];
  for (const numStr of numerosBase) {
    const viz = obterVizinhosCilindro(Number(numStr), qtdVizinhos);
    for (const v of viz) {
      const key = String(v);
      if (!alvos.has(key)) {
        alvos.add(key);
        zona.push(key);
      }
    }
  }

  let greensBt = 0;
  let redsBt = 0;
  let i = 0;
  while (i < janelaRecente.length - maxGalesSim) {
    let acertou = false;
    let gUsado = 0;
    for (let g = 0; g <= maxGalesSim; g += 1) {
      if (i + g < janelaRecente.length) {
        if (alvos.has(String(janelaRecente[i + g]))) {
          acertou = true;
          gUsado = g;
          break;
        }
      }
      gUsado = g;
    }
    if (acertou) greensBt += 1;
    else redsBt += 1;
    i += gUsado + 1;
  }

  const totalBt = greensBt + redsBt;
  const pctBt = totalBt > 0 ? (greensBt / totalBt) * 100 : 0;
  if (pctBt >= minMeta) {
    return {
      nome: `Terminal Físico (T${termId} + ${qtdVizinhos}V)`,
      gatilho_str: `IA TERMO-FÍSICA [T${termId} em Alta (${hitsTerm}x)]`,
      alvos: zona,
      alvo_central: `T${termId}`,
      is_termo: true,
      max_gales: maxGalesSim,
      greens: greensBt,
      reds: redsBt,
      pct: pctBt,
      hits: hitsTerm,
    };
  }
  return null;
}
