import { obterVizinhosCilindro } from "@/lib/v19/classify";
import { DEFAULT_V19 } from "@/lib/v19/constants";

export type SniperSinal = {
  nome: string;
  gatilho_str: string;
  alvos: string[];
  alvo_central: number;
  max_gales: number;
  greens: number;
  reds: number;
  pct: number;
};

export type SniperParams = {
  janelaAmostra?: number;
  atrasoMin?: number;
  qtdVizinhos?: number;
  momentumMin?: number;
  minMeta?: number;
  maxGales?: number;
  cooldown?: number;
  ultimoAlvo?: number | null;
};

export function analisarNumerosPlenosSniper(historicoBruto: number[], params: SniperParams = {}): SniperSinal | null {
  const janelaAmostra = params.janelaAmostra ?? DEFAULT_V19.amostra;
  const atrasoMin = params.atrasoMin ?? DEFAULT_V19.atrasoMin;
  const qtdVizinhos = params.qtdVizinhos ?? DEFAULT_V19.vizinhosSniper;
  const momentumMin = params.momentumMin ?? DEFAULT_V19.momentumMin;
  const minMeta = params.minMeta ?? DEFAULT_V19.minAssertividade;
  const maxGalesSim = params.maxGales ?? DEFAULT_V19.maxGales;

  if (historicoBruto.length < janelaAmostra) return null;

  const atrasos: Record<number, number> = {};
  const reversed = [...historicoBruto].reverse();
  for (let n = 0; n <= 36; n += 1) {
    const idx = reversed.indexOf(n);
    atrasos[n] = idx < 0 ? historicoBruto.length : idx;
  }

  const janelaRecente = historicoBruto.slice(-janelaAmostra);
  const alvosEncontrados: Array<[number, number[], number, number]> = [];

  for (let n = 0; n <= 36; n += 1) {
    const atraso = atrasos[n];
    if (atraso < atrasoMin) continue;
    const vizinhosZona = obterVizinhosCilindro(n, qtdVizinhos);
    const acertosZona = janelaRecente.filter((x) => vizinhosZona.includes(x)).length;
    if (acertosZona >= momentumMin) {
      alvosEncontrados.push([n, vizinhosZona, atraso, acertosZona]);
    }
  }

  if (!alvosEncontrados.length) return null;
  alvosEncontrados.sort((a, b) => b[3] - a[3] || b[2] - a[2]);

  for (const alvo of alvosEncontrados) {
    const numAlvo = alvo[0];
    if (params.cooldown && params.cooldown > 0 && params.ultimoAlvo === numAlvo) continue;

    const zona = alvo[1];
    const atrasoAlvo = alvo[2];
    let greensBt = 0;
    let redsBt = 0;
    let i = 0;
    const zonaStr = zona.map(String);
    while (i < janelaRecente.length - maxGalesSim) {
      let acertou = false;
      let gUsado = 0;
      for (let g = 0; g <= maxGalesSim; g += 1) {
        if (i + g < janelaRecente.length) {
          if (zonaStr.includes(String(janelaRecente[i + g]))) {
            acertou = true;
            gUsado = g;
            break;
          }
        }
        gUsado = g;
      }
      if (acertou) greensBt += 1;
      else redsBt += 1;
      i += gUsado + 1;
    }

    const totalBt = greensBt + redsBt;
    const pctBt = totalBt > 0 ? (greensBt / totalBt) * 100 : 0;
    if (pctBt >= minMeta) {
      return {
        nome: `Sniper (Alvo: ${numAlvo})`,
        gatilho_str: `MODO SNIPER [Alvo: ${numAlvo} | Atr: ${atrasoAlvo}]`,
        alvos: zona.map(String),
        alvo_central: numAlvo,
        max_gales: maxGalesSim,
        greens: greensBt,
        reds: redsBt,
        pct: pctBt,
      };
    }
  }
  return null;
}
