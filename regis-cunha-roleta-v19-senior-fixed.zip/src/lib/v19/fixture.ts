/** Same deterministic sample as scripts/v19_reference.py fixture_history. Chronological (oldest first). */
export function fixtureHistory(length = 120): number[] {
  const nums: number[] = [];
  for (let i = 0; i < length; i += 1) {
    if (i % 11 === 0) nums.push(0);
    else if (i % 7 === 0) nums.push(32);
    else if (i % 5 === 0) nums.push(17);
    else nums.push((i * 13 + 5) % 37);
  }
  return nums;
}
