import type { Signal, SignalPhase, SignalType, Spin } from "@/lib/analise/roulette";
import { classificarNumero, expandirAlvos, type EstrategiaV19 } from "@/lib/v19/classify";
import { DEFAULT_V19 } from "@/lib/v19/constants";
import { minerarPadroesAoVivo, type PadraoMinerado } from "@/lib/v19/quant";
import { analisarNumerosPlenosSniper, type SniperSinal } from "@/lib/v19/sniper";
import { analisarTerminaisDinamicos, type TermoSinal } from "@/lib/v19/termo";
import { acertouAlvos, custoAcumulado, lucroGreen } from "@/lib/v19/payout";
import { raioXDaMesa, type RaioXMesa } from "@/lib/v19/raiox";
import { backtestEstrategias } from "@/lib/v19/backtest";
import type { FocusStrategy, StrategyWeights } from "@/lib/config/strategies";

export type V19RuntimeConfig = {
  amostra: number;
  atrasoMin: number;
  vizinhosSniper: number;
  momentumMin: number;
  minAssertividade: number;
  maxGales: number;
  termHits: number;
  termViz: number;
  cooldown: number;
  minConsensus: number;
  confirmationSpins: number;
  weights: StrategyWeights;
  focus: FocusStrategy;
  stopWin: number;
  stopLoss: number;
  maxReds: number;
  fichaBase: number;
  sniperEnabled: boolean;
  termoEnabled: boolean;
  multsGales: string[];
};

export const defaultRuntime = (): V19RuntimeConfig => ({
  amostra: DEFAULT_V19.amostra,
  atrasoMin: DEFAULT_V19.atrasoMin,
  vizinhosSniper: DEFAULT_V19.vizinhosSniper,
  momentumMin: DEFAULT_V19.momentumMin,
  minAssertividade: DEFAULT_V19.minAssertividade,
  maxGales: DEFAULT_V19.maxGales,
  termHits: DEFAULT_V19.termHits,
  termViz: DEFAULT_V19.termViz,
  cooldown: DEFAULT_V19.cooldown,
  minConsensus: 2,
  confirmationSpins: 1,
  weights: { sniper: 1, termo: 0.9, quant: 1, model: 0.65 },
  focus: null,
  stopWin: DEFAULT_V19.stopWin,
  stopLoss: DEFAULT_V19.stopLoss,
  maxReds: DEFAULT_V19.maxReds,
  fichaBase: DEFAULT_V19.fichaBase,
  sniperEnabled: true,
  termoEnabled: true,
  multsGales: [...DEFAULT_V19.multsGales],
});

export type EntradaSessao = {
  hora: string;
  estrategia: string;
  numero: number;
  resultado: "GREEN" | "RED";
  gale: number;
  valor: number;
};

export type MesaInfo = {
  historico: number[];
  cooldownSniper: number;
  ultimoAlvoSniper: number | null;
  cooldownTerm: number;
  ultimoAlvoTerm: string | null;
};

export type BancaState = {
  greens: number;
  reds: number;
  redsConsecutivos: number;
  lucroVirtual: number;
  bancaInicial: number;
  greensPorGale: Record<number, number>;
  redsPorGale: Record<number, number>;
  entradas: EntradaSessao[];
  curvaLucro: number[];
};

export function emptyBanca(bancaInicial = DEFAULT_V19.bancaInicial): BancaState {
  return {
    greens: 0,
    reds: 0,
    redsConsecutivos: 0,
    lucroVirtual: 0,
    bancaInicial,
    greensPorGale: {},
    redsPorGale: {},
    entradas: [],
    curvaLucro: [0],
  };
}

export function chronologicalFromSpins(spins: Spin[]): number[] {
  return [...spins].map((spin) => spin.number).reverse();
}

export function phaseFromGale(galeAtual: number, pending: boolean, result?: "GREEN" | "RED"): SignalPhase {
  if (result === "GREEN") return "GREEN";
  if (result === "RED") return "RED";
  if (!pending) return "OBSERVANDO";
  const clamped = Math.max(0, Math.min(6, Math.floor(galeAtual)));
  return `G${clamped}` as SignalPhase;
}

export function galeLabel(gale: number): string {
  return gale <= 0 ? "DIRETA" : `G${gale}`;
}

function typeOfSinal(sinal: { gatilho_str: string; is_termo?: boolean; origem_quant?: boolean; tipo?: SignalType }): SignalType {
  if (sinal.tipo) return sinal.tipo;
  if (sinal.is_termo) return "TERMO";
  if (sinal.origem_quant || sinal.gatilho_str.includes("QUANT")) return "QUANT";
  if (sinal.gatilho_str.includes("SNIPER")) return "SNIPER";
  return "MODELO";
}

export type CandidateSignal = {
  nome: string;
  gatilho_str: string;
  aposta_str: string;
  alvos: string[];
  max_gales: number;
  mults_gales: string[];
  gale_atual: number;
  pct: number;
  is_termo?: boolean;
  origem_quant?: boolean;
  tipo?: SignalType;
  alvo_central?: number | string;
  est_obj?: EstrategiaV19 | null;
};

export function candidateToSignal(sinal: CandidateSignal, triggerSpin: Spin | undefined, now = new Date().toISOString()): Signal {
  const targets = expandirAlvos(sinal.alvos)
    .map((item) => Number.parseInt(item, 10))
    .filter((n) => Number.isInteger(n) && n >= 0 && n <= 36);
  const type = typeOfSinal(sinal);
  return {
    id: `v19-${type.toLowerCase()}-${triggerSpin?.id ?? now}-${sinal.alvos.slice(0, 6).join("-")}`,
    type,
    tone: type === "SNIPER" ? "ember" : type === "TERMO" ? "sage" : type === "QUANT" ? "blue" : "stone",
    title: sinal.nome,
    trigger: sinal.gatilho_str,
    targets: targets.length ? targets : expandirAlvos(sinal.alvos).map((item) => Number(item)).filter((n) => !Number.isNaN(n)),
    score: sinal.pct,
    strength: Math.min(96, Math.round(sinal.pct)),
    filters: [
      { id: "assertividade", name: "Assertividade backtest", points: sinal.pct, reason: `${sinal.pct.toFixed(1)}% na amostra` },
    ],
    greens: 0,
    reds: 0,
    maxGales: sinal.max_gales,
    createdAt: triggerSpin?.createdAt ?? now,
    triggerSpinId: triggerSpin?.id ?? "unknown",
    active: true,
    result: "PENDING",
    spinsSince: 0,
    phase: "SINAL_ATIVO",
    consensus: 1,
    consensusTotal: 1,
    explanation: [
      {
        strategy: type,
        score: sinal.pct,
        weight: 1,
        weighted: sinal.pct,
        summary: sinal.gatilho_str,
        candidates: targets,
      },
    ],
    galeStep: 0,
  };
}

export function resolverSinalAtivo(args: {
  sinal: CandidateSignal;
  numero: number;
  tags: string[];
  banca: BancaState;
  config: V19RuntimeConfig;
  hora?: string;
}): {
  sinal: CandidateSignal | null;
  banca: BancaState;
  resolved?: { resultado: "GREEN" | "RED"; valor: number; gale: number };
  galeAtivado?: number;
} {
  const { sinal, numero, tags, config } = args;
  const banca = { ...args.banca, greensPorGale: { ...args.banca.greensPorGale }, redsPorGale: { ...args.banca.redsPorGale }, entradas: [...args.banca.entradas], curvaLucro: [...args.banca.curvaLucro] };
  const hora = args.hora ?? new Date().toISOString().slice(11, 19);
  const hit = acertouAlvos(numero, tags, sinal.aposta_str, sinal.alvos);

  if (hit) {
    const { lucro } = lucroGreen({
      apostaStr: sinal.aposta_str,
      numero,
      tags,
      galeAtual: sinal.gale_atual,
      fichaBase: config.fichaBase,
      mults: sinal.mults_gales,
    });
    banca.greens += 1;
    banca.redsConsecutivos = 0;
    banca.lucroVirtual += lucro;
    banca.greensPorGale[sinal.gale_atual] = (banca.greensPorGale[sinal.gale_atual] ?? 0) + 1;
    banca.entradas.unshift({
      hora,
      estrategia: sinal.nome,
      numero,
      resultado: "GREEN",
      gale: sinal.gale_atual,
      valor: lucro,
    });
    if (banca.entradas.length > 300) banca.entradas.length = 300;
    pushLucro(banca);
    if (sinal.est_obj) sinal.est_obj.greens = (sinal.est_obj.greens ?? 0) + 1;
    return { sinal: null, banca, resolved: { resultado: "GREEN", valor: lucro, gale: sinal.gale_atual } };
  }

  if (sinal.gale_atual < sinal.max_gales) {
    const next = { ...sinal, gale_atual: sinal.gale_atual + 1 };
    return { sinal: next, banca, galeAtivado: next.gale_atual };
  }

  const { custo } = custoAcumulado({
    apostaStr: sinal.aposta_str,
    galeAtual: sinal.gale_atual,
    fichaBase: config.fichaBase,
    mults: sinal.mults_gales,
  });
  banca.reds += 1;
  banca.redsConsecutivos += 1;
  banca.lucroVirtual -= custo;
  banca.redsPorGale[sinal.gale_atual] = (banca.redsPorGale[sinal.gale_atual] ?? 0) + 1;
  banca.entradas.unshift({
    hora,
    estrategia: sinal.nome,
    numero,
    resultado: "RED",
    gale: sinal.gale_atual,
    valor: -custo,
  });
  if (banca.entradas.length > 300) banca.entradas.length = 300;
  pushLucro(banca);
  if (sinal.est_obj) sinal.est_obj.reds = (sinal.est_obj.reds ?? 0) + 1;
  return { sinal: null, banca, resolved: { resultado: "RED", valor: -custo, gale: sinal.gale_atual } };
}

function pushLucro(banca: BancaState) {
  if (!banca.curvaLucro.length || banca.curvaLucro[banca.curvaLucro.length - 1] !== banca.lucroVirtual) {
    banca.curvaLucro.push(banca.lucroVirtual);
    if (banca.curvaLucro.length > 60) banca.curvaLucro.splice(0, banca.curvaLucro.length - 60);
  }
}

export type LiveSnapshot = {
  historico: number[];
  last: number | null;
  raiox: RaioXMesa | null;
  mined: PadraoMinerado[];
  sniper: SniperSinal | null;
  termo: TermoSinal | null;
  estrategias: ReturnType<typeof backtestEstrategias>;
  leader: { nome: string; pct: number } | null;
};

export function avaliarMesa(historico: number[], estrategias: EstrategiaV19[], config: V19RuntimeConfig): LiveSnapshot {
  const mined = minerarPadroesAoVivo(historico, config.maxGales);
  const sniper = config.sniperEnabled
    ? analisarNumerosPlenosSniper(historico, {
        janelaAmostra: config.amostra,
        atrasoMin: config.atrasoMin,
        qtdVizinhos: config.vizinhosSniper,
        momentumMin: config.momentumMin,
        minMeta: config.minAssertividade,
        maxGales: config.maxGales,
      })
    : null;
  const termo = config.termoEnabled
    ? analisarTerminaisDinamicos(historico, {
        janelaAmostra: config.amostra,
        minHits: config.termHits,
        qtdVizinhos: config.termViz,
        minMeta: config.minAssertividade,
        maxGales: config.maxGales,
      })
    : null;
  const ranked = backtestEstrategias(historico, estrategias);
  const withPct = ranked.filter((est) => (est.greens ?? 0) + (est.reds ?? 0) >= 3);
  const leader = withPct.sort((a, b) => (b.pct ?? 0) - (a.pct ?? 0))[0];
  return {
    historico,
    last: historico.length ? historico[historico.length - 1] : null,
    raiox: raioXDaMesa(historico, config.amostra),
    mined,
    sniper,
    termo,
    estrategias: ranked,
    leader: leader ? { nome: leader.nome ?? leader.gatilho_str, pct: leader.pct ?? 0 } : null,
  };
}
