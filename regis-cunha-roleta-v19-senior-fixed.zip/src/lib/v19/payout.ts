import { SETORES_FISICOS, TERMINAIS_MAP } from "@/lib/v19/constants";

export function parseGaleFactor(raw: string | undefined, galeIdx: number): number {
  if (galeIdx === 0) return 1;
  const cleaned = (raw ?? "2").replace("x", "");
  const parsed = Number.parseFloat(cleaned);
  return Number.isFinite(parsed) ? parsed : 2 ** galeIdx;
}

export function tokensDaAposta(apostaStr: string): string[] {
  return apostaStr.replace(/,/g, " ").split(/\s+/).filter(Boolean);
}

export function expandirToken(token: string): { fichas: number; alvos: string[]; multiplier: number } {
  if (token in SETORES_FISICOS) {
    return {
      fichas: SETORES_FISICOS[token as keyof typeof SETORES_FISICOS].length,
      alvos: SETORES_FISICOS[token as keyof typeof SETORES_FISICOS].map(String),
      multiplier: 36,
    };
  }
  if (token in TERMINAIS_MAP) {
    return { fichas: TERMINAIS_MAP[token].length, alvos: TERMINAIS_MAP[token], multiplier: 36 };
  }
  if (["B", "R", "P", "O", "L", "H"].includes(token)) {
    return { fichas: 1, alvos: [token], multiplier: 2 };
  }
  if (["D1", "D2", "D3", "C1", "C2", "C3"].includes(token)) {
    return { fichas: 1, alvos: [token], multiplier: 3 };
  }
  return { fichas: 1, alvos: [token], multiplier: 36 };
}

export function acertouAlvos(numero: number, tags: string[], apostaStr: string, alvos: string[]): boolean {
  const tokens = tokensDaAposta(apostaStr);
  const verificacao: string[] = [];
  for (const token of tokens) {
    if (token in SETORES_FISICOS) verificacao.push(...SETORES_FISICOS[token as keyof typeof SETORES_FISICOS].map(String));
    else if (token in TERMINAIS_MAP) verificacao.push(...TERMINAIS_MAP[token]);
    else verificacao.push(token);
  }
  if (verificacao.includes(String(numero))) return true;
  return alvos.some((alvo) => tags.includes(alvo));
}

export function custoAcumulado(args: {
  apostaStr: string;
  galeAtual: number;
  fichaBase: number;
  mults: string[];
  startGale?: number;
}): { totalFichas: number; custo: number } {
  const tokens = tokensDaAposta(args.apostaStr);
  let totalFichas = 0;
  for (const token of tokens) totalFichas += expandirToken(token).fichas;
  const startGale = args.startGale ?? 0;
  let custo = 0;
  for (let g = startGale; g <= args.galeAtual; g += 1) {
    const fator = parseGaleFactor(g === 0 ? undefined : args.mults[g - 1], g);
    custo += totalFichas * args.fichaBase * fator;
  }
  return { totalFichas, custo };
}

export function lucroGreen(args: {
  apostaStr: string;
  numero: number;
  tags: string[];
  galeAtual: number;
  fichaBase: number;
  mults: string[];
  fantasma?: boolean;
}): { lucro: number; custo: number; premio: number } {
  const tokens = tokensDaAposta(args.apostaStr);
  let totalFichas = 0;
  let premioBrutoUnitario = 0;
  for (const token of tokens) {
    const mapped = expandirToken(token);
    totalFichas += mapped.fichas;
    if (mapped.alvos.includes(String(args.numero)) || mapped.alvos.some((alvo) => args.tags.includes(alvo))) {
      premioBrutoUnitario += mapped.multiplier;
    }
  }
  const { custo } = custoAcumulado({
    apostaStr: args.apostaStr,
    galeAtual: args.galeAtual,
    fichaBase: args.fichaBase,
    mults: args.mults,
  });
  if (args.fantasma && args.galeAtual === 0) return { lucro: 0, custo, premio: 0 };
  const fatorGale = parseGaleFactor(args.galeAtual === 0 ? undefined : args.mults[args.galeAtual - 1], args.galeAtual);
  const premio = premioBrutoUnitario * (args.fichaBase * fatorGale);
  return { lucro: premio - custo, custo, premio };
}
