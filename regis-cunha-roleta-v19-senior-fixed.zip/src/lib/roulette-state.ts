export { emptyState, connectTable as getRouletteState } from "@/lib/coleta/api";
