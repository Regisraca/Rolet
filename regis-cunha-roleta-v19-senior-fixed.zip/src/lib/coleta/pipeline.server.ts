import { fetchTable, readLivePage } from "@/lib/coleta/casinoscores.server";
import { listGiros, openSession, upsertGiros } from "@/lib/banco/spins.server";
import type { TableId } from "@/lib/config/tables";
import type { RouletteState, Spin } from "@/lib/analise/roulette";

function mergeById(primary: Spin[], secondary: Spin[]) {
  const map = new Map<string, Spin>();
  for (const item of secondary) map.set(item.id, item);
  for (const item of primary) map.set(item.id, item);
  return [...map.values()].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
}

export async function captureCycle(
  tableId: TableId,
  sessionId: string | null,
  deep: boolean,
): Promise<RouletteState> {
  const live = deep ? await fetchTable(tableId, sessionId, 5) : await readLivePage(tableId, sessionId);
  let inserted = 0;
  if (live.spins.length > 0) {
    try {
      inserted = await upsertGiros(tableId, sessionId, live.spins);
    } catch (error) {
      console.error("persist giros failed", error);
    }
  }
  let stored: Spin[] = [];
  try {
    stored = await listGiros(tableId, 1000);
  } catch (error) {
    console.error("list giros failed", error);
  }
  const spins = mergeById(live.spins, stored);
  if (live.source.status !== "online" && spins.length === 0) {
    return { ...live, sessionId, inserted };
  }
  return {
    spins,
    sessionId,
    inserted,
    source:
      live.source.status === "online"
        ? live.source
        : {
            ...live.source,
            message: spins.length
              ? `${live.source.message} Histórico local preservado.`
              : live.source.message,
          },
  };
}

export async function captureOnConnect(tableId: TableId): Promise<RouletteState> {
  let sessionId: string;
  try {
    sessionId = await openSession(tableId);
  } catch (error) {
    console.error("open session failed", error);
    sessionId = `mem_${tableId}_${Date.now().toString(36)}`;
  }
  return captureCycle(tableId, sessionId, true);
}
