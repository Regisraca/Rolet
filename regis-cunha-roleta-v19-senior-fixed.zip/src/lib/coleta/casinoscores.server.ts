import { enrichSpin, isValidPocket, numberColor, type LuckyNumber, type PocketColor, type RouletteState, type Spin } from "@/lib/analise/roulette";
import { TABLES, type TableId } from "@/lib/config/tables";
import { DEEP_HISTORY_PAGES, LIVE_PAGE_SIZE } from "@/lib/config/app";

const API_BASE = "https://api-cs.casino.org/svc-evolution-game-events/api";
const CACHE_TTL_MS = 2_200;
const FETCH_TIMEOUT_MS = 12_000;

type RawLucky = {
  number?: number;
  roundedMultiplier?: number;
  multiplier?: number;
};

type RawEvent = {
  id?: string;
  totalWinners?: number;
  data?: {
    id?: string;
    startedAt?: string;
    settledAt?: string;
    status?: string;
    table?: { id?: string; name?: string };
    result?: {
      outcome?: { number?: number; type?: string; color?: string };
      luckyNumbersList?: RawLucky[];
      lightningMultiplier?: number;
      superBoost?: boolean;
    };
  };
};

type CacheEntry = { at: number; state: RouletteState };

const cache = new Map<string, CacheEntry>();

function asColor(value: string | undefined, number: number): PocketColor {
  const normalized = value?.toLowerCase();
  if (normalized === "red") return "red";
  if (normalized === "black") return "black";
  if (normalized === "green") return "green";
  return numberColor(number);
}

function parseLucky(list: RawLucky[] | undefined, lightning: number | undefined): LuckyNumber[] {
  if (!list?.length) return [];
  return list
    .filter((item) => typeof item.number === "number" && item.number >= 0 && item.number <= 36)
    .map((item) => ({
      number: item.number as number,
      multiplier: item.roundedMultiplier ?? item.multiplier ?? lightning ?? null,
    }));
}

export function parseEvents(raw: unknown, tableId: TableId, sessionId: string | null): Spin[] {
  if (!Array.isArray(raw)) return [];
  const table = TABLES[tableId];
  const spins: Spin[] = [];
  const seen = new Set<string>();
  for (const event of raw as RawEvent[]) {
    const number = event.data?.result?.outcome?.number;
    if (!isValidPocket(number)) continue;
    const settledAt = event.data?.settledAt;
    if (!settledAt) continue;
    const sourceEventId = String(event.id ?? event.data?.id ?? `${settledAt}-${number}`);
    if (seen.has(sourceEventId)) continue;
    seen.add(sourceEventId);
    const lightning = event.data?.result?.lightningMultiplier ?? null;
    const luckyNumbers = parseLucky(event.data?.result?.luckyNumbersList, lightning ?? undefined);
    const matched = luckyNumbers.find((item) => item.number === number);
    spins.push(
      enrichSpin({
        id: `${tableId}:${sourceEventId}`,
        sourceEventId,
        number,
        color: asColor(event.data?.result?.outcome?.color, number),
        createdAt: settledAt,
        luckyNumbers,
        multiplier: lightning ?? matched?.multiplier ?? null,
        totalWinners: typeof event.totalWinners === "number" ? event.totalWinners : null,
        tableId,
        provider: table.providerLabel,
        sessionId,
      }),
    );
  }
  return spins;
}

async function fetchPage(tableId: TableId, page: number): Promise<{ spins: Spin[]; total: number | null; error?: string }> {
  const table = TABLES[tableId];
  const url = `${API_BASE}/${table.apiPath}?page=${page}&size=${LIVE_PAGE_SIZE}&sort=data.settledAt,desc&duration=${table.duration}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        Accept: "application/json",
        Origin: "https://www.casino.org",
        Referer: table.pageUrl,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
      },
    });
    if (!response.ok) return { spins: [], total: null, error: `A fonte respondeu ${response.status}.` };
    const totalHeader = response.headers.get("x-total-count");
    const total = totalHeader ? Number(totalHeader) : null;
    const payload: unknown = await response.json();
    return {
      spins: parseEvents(payload, tableId, null),
      total: Number.isFinite(total) ? total : null,
    };
  } catch (error) {
    const aborted = error instanceof Error && error.name === "AbortError";
    return {
      spins: [],
      total: null,
      error: aborted ? "A leitura da mesa excedeu o tempo limite." : "Não foi possível consultar a fonte de resultados.",
    };
  } finally {
    clearTimeout(timer);
  }
}

function mergeSpins(groups: Spin[][]) {
  const map = new Map<string, Spin>();
  for (const group of groups) {
    for (const spin of group) {
      if (!map.has(spin.id)) map.set(spin.id, spin);
    }
  }
  return [...map.values()].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
}

export async function fetchTable(
  tableId: TableId,
  sessionId: string | null,
  pages = 1,
): Promise<RouletteState> {
  const table = TABLES[tableId];
  const first = await fetchPage(tableId, 0);
  if (first.error) {
    return {
      spins: [],
      sessionId,
      inserted: 0,
      source: {
        status: "error",
        origin: "CasinoScores",
        table: table.label,
        provider: table.providerLabel,
        message: first.error,
        lastEventAt: null,
        totalAvailable: null,
      },
    };
  }
  const groups = [first.spins.map((spin) => ({ ...spin, sessionId }))];
  const extra = Math.min(Math.max(pages, 1), DEEP_HISTORY_PAGES) - 1;
  for (let page = 1; page <= extra; page += 1) {
    const next = await fetchPage(tableId, page);
    if (next.error || next.spins.length === 0) break;
    groups.push(next.spins.map((spin) => ({ ...spin, sessionId })));
  }
  const spins = mergeSpins(groups);
  if (spins.length === 0) {
    return {
      spins: [],
      sessionId,
      inserted: 0,
      source: {
        status: "error",
        origin: "CasinoScores",
        table: table.label,
        provider: table.providerLabel,
        message: "Mesa conectada, mas nenhum giro foi encontrado no histórico.",
        lastEventAt: null,
        totalAvailable: first.total,
      },
    };
  }
  return {
    spins,
    sessionId,
    inserted: 0,
    source: {
      status: "online",
      origin: "CasinoScores · feed público",
      table: table.label,
      provider: table.providerLabel,
      message: "Recebendo resultados ao vivo.",
      lastEventAt: spins[0]?.createdAt ?? null,
      totalAvailable: first.total,
    },
  };
}

export async function readLivePage(tableId: TableId, sessionId: string | null): Promise<RouletteState> {
  const key = `${tableId}:${sessionId ?? "none"}`;
  const cached = cache.get(key);
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) return cached.state;
  const state = await fetchTable(tableId, sessionId, 1);
  if (state.source.status === "online") cache.set(key, { at: Date.now(), state });
  return state;
}
