import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { TABLE_IDS, TABLES, isTableId } from "@/lib/config/tables";
import type { RouletteState } from "@/lib/analise/roulette";

const TableInput = z.object({
  tableId: z.enum(TABLE_IDS),
  sessionId: z.string().nullable().optional(),
  deep: z.boolean().optional(),
});

export function emptyState(tableId: string, message = "Mesa desconectada. Nenhum dado inventado."): RouletteState {
  const table = isTableId(tableId) ? TABLES[tableId] : TABLES["auto-roulette"];
  return {
    spins: [],
    sessionId: null,
    inserted: 0,
    source: {
      status: "idle",
      origin: "CasinoScores",
      table: table.label,
      provider: table.providerLabel,
      message,
      lastEventAt: null,
      totalAvailable: null,
    },
  };
}

export const connectTable = createServerFn({ method: "POST" })
  .validator((data: unknown) => TableInput.parse(data))
  .handler(async ({ data }): Promise<RouletteState> => {
    const { captureOnConnect } = await import("@/lib/coleta/pipeline.server");
    return captureOnConnect(data.tableId);
  });

export const scanTable = createServerFn({ method: "POST" })
  .validator((data: unknown) => TableInput.parse(data))
  .handler(async ({ data }): Promise<RouletteState> => {
    const { captureCycle } = await import("@/lib/coleta/pipeline.server");
    return captureCycle(data.tableId, data.sessionId ?? null, Boolean(data.deep));
  });

export const pauseTable = createServerFn({ method: "POST" })
  .validator((data: unknown) =>
    z.object({ sessionId: z.string(), tableId: z.enum(TABLE_IDS) }).parse(data),
  )
  .handler(async ({ data }) => {
    const { closeSession } = await import("@/lib/banco/spins.server");
    try {
      await closeSession(data.sessionId);
    } catch (error) {
      console.error("close session failed", error);
    }
    return { ok: true as const };
  });

export const loadTableHistory = createServerFn({ method: "GET" })
  .validator((data: unknown) => z.object({ tableId: z.enum(TABLE_IDS) }).parse(data))
  .handler(async ({ data }): Promise<RouletteState> => {
    try {
      const { listGiros } = await import("@/lib/banco/spins.server");
      const spins = await listGiros(data.tableId, 1000);
      const table = TABLES[data.tableId];
      if (spins.length === 0) return emptyState(data.tableId);
      return {
        spins,
        sessionId: null,
        inserted: 0,
        source: {
          status: "idle",
          origin: "Banco local",
          table: table.label,
          provider: table.providerLabel,
          message: "Histórico persistido desta mesa. Conecte para atualizar ao vivo.",
          lastEventAt: spins[0]?.createdAt ?? null,
          totalAvailable: spins.length,
        },
      };
    } catch {
      return emptyState(data.tableId);
    }
  });
