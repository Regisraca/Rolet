/**
 * Adapter de coleta via Playwright.
 *
 * O projeto original captura resultados pela API pública da CasinoScores,
 * não por automação de browser. Este módulo define o contrato da pipeline
 * para uma futura integração Playwright (desktop / worker dedicado):
 *
 *   conectar mesa
 *     → localizar área de resultados
 *     → capturar novo resultado
 *     → validar (0–36, evento distinto)
 *     → gravar no banco
 *     → atualizar dashboard
 *     → executar filtros
 *     → atualizar sinal
 *
 * Importante: dois números iguais consecutivos NÃO são duplicata automática.
 * A identidade do giro é o evento da mesa (id + horário + estado), não o número.
 *
 * Neste ambiente web a coleta ativa continua sendo o adapter CasinoScores.
 */

export type PlaywrightCapturePlan = {
  tableUrl: string;
  resultsSelector: string;
  pollMs: number;
};

export const PLAYWRIGHT_AVAILABLE = false;

export const PLAYWRIGHT_PLAN: PlaywrightCapturePlan = {
  tableUrl: "",
  resultsSelector: "[data-role='recent-results'], .recent-results, .roulette-history",
  pollMs: 2500,
};

export function playwrightUnsupportedReason() {
  return "Playwright não estava no projeto original e não roda contra a mesa ao vivo neste preview. A pipeline de coleta usa o mesmo feed público de resultados já existente.";
}
