import { enrichSpin, type Spin } from "@/lib/analise/roulette";
import { getSql } from "@/lib/db";
import { TABLES, type TableId } from "@/lib/config/tables";

type GiroRow = {
  id: string;
  source_event_id: string;
  mesa_id: string;
  sessao_id: string | null;
  provedor: string;
  numero: number;
  cor: string;
  paridade: string;
  duzia: number;
  coluna: number;
  terminal: number;
  faixa: string;
  horario: string;
  multiplicador: string | null;
  ganhadores: number | null;
  lucky_json: string | null;
};

function rowToSpin(row: GiroRow): Spin {
  let luckyNumbers: Spin["luckyNumbers"] = [];
  if (row.lucky_json) {
    try {
      luckyNumbers = JSON.parse(row.lucky_json) as Spin["luckyNumbers"];
    } catch {
      luckyNumbers = [];
    }
  }
  return enrichSpin({
    id: row.id,
    sourceEventId: row.source_event_id,
    number: Number(row.numero),
    createdAt: typeof row.horario === "string" ? row.horario : new Date(row.horario).toISOString(),
    luckyNumbers,
    multiplier: row.multiplicador ? Number(row.multiplicador) : null,
    totalWinners: row.ganhadores === null ? null : Number(row.ganhadores),
    tableId: row.mesa_id,
    provider: row.provedor,
    sessionId: row.sessao_id,
  });
}

export async function openSession(tableId: TableId) {
  const sql = await getSql();
  const table = TABLES[tableId];
  const id = `ses_${tableId}_${Date.now().toString(36)}`;
  await sql`
    insert into sessoes (id, mesa_id, provedor, status)
    values (${id}, ${tableId}, ${table.providerLabel}, ${"capturing"})
  `;
  return id;
}

export async function closeSession(sessionId: string) {
  const sql = await getSql();
  await sql`
    update sessoes
    set status = ${"paused"}, stopped_at = now()
    where id = ${sessionId}
  `;
}

export async function upsertGiros(tableId: TableId, sessionId: string | null, spins: Spin[]) {
  if (spins.length === 0) return 0;
  const sql = await getSql();
  let inserted = 0;
  for (const spin of spins) {
    const rows = await sql`
      insert into giros (
        id, source_event_id, mesa_id, sessao_id, provedor, numero, cor, paridade,
        duzia, coluna, terminal, faixa, horario, multiplicador, ganhadores, lucky_json
      )
      values (
        ${spin.id},
        ${spin.sourceEventId},
        ${tableId},
        ${sessionId},
        ${spin.provider},
        ${spin.number},
        ${spin.color},
        ${spin.parity},
        ${spin.dozen},
        ${spin.column},
        ${spin.terminal},
        ${spin.highLow},
        ${spin.createdAt},
        ${spin.multiplier === null ? null : String(spin.multiplier)},
        ${spin.totalWinners},
        ${JSON.stringify(spin.luckyNumbers)}
      )
      on conflict (id) do nothing
      returning id
    `;
    if (rows.length > 0) inserted += 1;
  }
  return inserted;
}

export async function listGiros(tableId: TableId, limit = 1000) {
  const sql = await getSql();
  const rows = await sql<GiroRow>`
    select id, source_event_id, mesa_id, sessao_id, provedor, numero, cor, paridade,
           duzia, coluna, terminal, faixa, horario, multiplicador, ganhadores, lucky_json
    from giros
    where mesa_id = ${tableId}
    order by horario desc
    limit ${limit}
  `;
  return rows.map(rowToSpin);
}

export async function countGiros(tableId: TableId) {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`
    select count(*)::int as n from giros where mesa_id = ${tableId}
  `;
  return rows[0]?.n ?? 0;
}
