export const TABLE_IDS = [
  "auto-roulette",
  "immersive-roulette",
  "mega-fire-blaze",
  "mega-roulette",
] as const;

export type TableId = (typeof TABLE_IDS)[number];
export type TableProvider = "evolution" | "playtech" | "pragmatic";

export type TableConfig = {
  id: TableId;
  label: string;
  shortLabel: string;
  provider: TableProvider;
  providerLabel: string;
  apiPath: string;
  duration: number;
  pageUrl: string;
  description: string;
};

export const TABLES: Record<TableId, TableConfig> = {
  "auto-roulette": {
    id: "auto-roulette",
    label: "Auto Roulette",
    shortLabel: "Auto",
    provider: "evolution",
    providerLabel: "Evolution",
    apiPath: "autoroulette",
    duration: 1,
    pageUrl: "https://www.casino.org/casinoscores/pt-br/auto-roulette/",
    description: "Roleta automática da Evolution. Giro rápido, histórico estável.",
  },
  "immersive-roulette": {
    id: "immersive-roulette",
    label: "Immersive Roulette",
    shortLabel: "Immersive",
    provider: "evolution",
    providerLabel: "Evolution",
    apiPath: "immersiveroulette",
    duration: 1,
    pageUrl: "https://www.casino.org/casinoscores/pt-br/immersive-roulette/",
    description: "Mesa imersiva da Evolution, com dealer ao vivo.",
  },
  "mega-fire-blaze": {
    id: "mega-fire-blaze",
    label: "Mega Fire Blaze",
    shortLabel: "Fire Blaze",
    provider: "playtech",
    providerLabel: "Playtech",
    apiPath: "megafireblazeroulette",
    duration: 30,
    pageUrl: "https://www.casino.org/casinoscores/pt-br/mega-fire-blaze-roulette/",
    description: "Playtech com números sortudos e Super Boost.",
  },
  "mega-roulette": {
    id: "mega-roulette",
    label: "Mega Roulette",
    shortLabel: "Mega",
    provider: "pragmatic",
    providerLabel: "Pragmatic",
    apiPath: "megaroulette",
    duration: 1,
    pageUrl: "https://www.casino.org/casinoscores/pt-br/mega-roulette/",
    description: "Pragmatic Play com multiplicadores nos números sortudos.",
  },
};

export const TABLE_LIST = TABLE_IDS.map((id) => TABLES[id]);

export function isTableId(value: string): value is TableId {
  return (TABLE_IDS as readonly string[]).includes(value);
}
