export const APP_NAME = "RÉGIS CUNHA ROLETA";
export const APP_SHORT_NAME = "RÉGIS CUNHA";
export const APP_TAGLINE = "v19.0 — cilindro europeu, Quant Lab e gestão de banca";
export const APP_VERSION = "v19.0";

export const ANALYSIS_WINDOWS = [20, 50, 60, 100, 250, 500] as const;
export type AnalysisWindow = (typeof ANALYSIS_WINDOWS)[number];

export const DEFAULT_WINDOW: AnalysisWindow = 60;
export const DEFAULT_MIN_SCORE = 80;
export const DEFAULT_MAX_GALES = 2;
export const MAX_SIGNAL_TARGETS = 24;
export const MAX_SIGNALS = 60;
export const MIN_HISTORY_FOR_SIGNAL = 20;
export const MIN_BACKTEST_SIGNALS = 15;
export const SCAN_INTERVAL_MS = 2500;
export const DEEP_HISTORY_PAGES = 10;
export const LIVE_PAGE_SIZE = 100;

export const DISCLAIMER =
  "Leitura estatística do cilindro europeu. Não executa apostas. Chrome/Telegram do Python original não estão neste ambiente web.";
