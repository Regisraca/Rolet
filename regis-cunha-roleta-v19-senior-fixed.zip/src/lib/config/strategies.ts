import {
  DEFAULT_MAX_GALES,
  DEFAULT_MIN_SCORE,
  MAX_SIGNAL_TARGETS,
  MIN_HISTORY_FOR_SIGNAL,
} from "@/lib/config/app";

export type StrategyWeights = {
  sniper: number;
  termo: number;
  quant: number;
  model: number;
};

export type SniperParams = {
  window: number;
  shortWindow: number;
  zoneRadius: number;
  recencyDecay: number;
  atrasoMin: number;
  momentumMin: number;
  minZoneHits: number;
  maxCandidates: number;
  minScore: number;
};

export type TermoParams = {
  shortWindow: number;
  mediumWindow: number;
  longWindow: number;
  topTerminals: number;
  minHits: number;
  zoneNeighbors: number;
  maxCandidates: number;
  minScore: number;
};

export type QuantParams = {
  window: number;
  pairLookback: number;
  maxCandidates: number;
  minScore: number;
  minCount: number;
};

export type ModelParams = {
  minAgreement: number;
  maxCandidates: number;
  minScore: number;
};

export type FocusStrategy = "SNIPER" | "TERMO" | "QUANT" | "MODELO" | null;

export type StrategyEngineConfig = {
  minHistory: number;
  minScore: number;
  minConsensus: number;
  maxCandidates: number;
  maxGales: number;
  cooldownSpins: number;
  confirmationSpins: number;
  weights: StrategyWeights;
  sniper: SniperParams;
  termo: TermoParams;
  quant: QuantParams;
  model: ModelParams;
  focus: FocusStrategy;
};

export const DEFAULT_STRATEGY_WEIGHTS: StrategyWeights = {
  sniper: 1,
  termo: 0.9,
  quant: 1,
  model: 0.65,
};

export const DEFAULT_SNIPER_PARAMS: SniperParams = {
  window: 50,
  shortWindow: 12,
  zoneRadius: 2,
  recencyDecay: 0.9,
  atrasoMin: 30,
  momentumMin: 3,
  minZoneHits: 4,
  maxCandidates: 6,
  minScore: 10,
};

export const DEFAULT_TERMO_PARAMS: TermoParams = {
  shortWindow: 12,
  mediumWindow: 37,
  longWindow: 100,
  topTerminals: 2,
  minHits: 8,
  zoneNeighbors: 1,
  maxCandidates: 8,
  minScore: 8,
};

export const DEFAULT_QUANT_PARAMS: QuantParams = {
  window: 100,
  pairLookback: 200,
  maxCandidates: 6,
  minScore: 8,
  minCount: 3,
};

export const DEFAULT_MODEL_PARAMS: ModelParams = {
  minAgreement: 2,
  maxCandidates: 6,
  minScore: 8,
};

export const DEFAULT_STRATEGY_CONFIG: StrategyEngineConfig = {
  minHistory: Math.max(24, MIN_HISTORY_FOR_SIGNAL),
  minScore: DEFAULT_MIN_SCORE,
  minConsensus: 2,
  maxCandidates: MAX_SIGNAL_TARGETS,
  maxGales: DEFAULT_MAX_GALES,
  cooldownSpins: 3,
  confirmationSpins: 1,
  weights: DEFAULT_STRATEGY_WEIGHTS,
  sniper: DEFAULT_SNIPER_PARAMS,
  termo: DEFAULT_TERMO_PARAMS,
  quant: DEFAULT_QUANT_PARAMS,
  model: DEFAULT_MODEL_PARAMS,
  focus: null,
};

export const MIN_SCORE_PRESETS = [10, 14, 16, 20, 24] as const;
export const SCORE_SWEEP_VALUES = [10, 15, 20, 25] as const;
export const COOLDOWN_PRESETS = [0, 2, 3, 5, 8] as const;
export const CONSENSUS_PRESETS = [1, 2, 3] as const;

export type EngineOverrides = {
  minScore?: number;
  maxGales?: number;
  analysisWindow?: number;
  weights?: Partial<StrategyWeights>;
  cooldownSpins?: number;
  minConsensus?: number;
  confirmationSpins?: number;
  maxCandidates?: number;
  focus?: FocusStrategy;
};

export function buildEngineConfig(overrides: EngineOverrides = {}): StrategyEngineConfig {
  const analysisWindow = overrides.analysisWindow;
  const sniperWindow = analysisWindow ?? DEFAULT_SNIPER_PARAMS.window;
  const quantWindow = analysisWindow ?? DEFAULT_QUANT_PARAMS.window;
  return {
    ...DEFAULT_STRATEGY_CONFIG,
    minScore: overrides.minScore ?? DEFAULT_STRATEGY_CONFIG.minScore,
    maxGales: overrides.maxGales ?? DEFAULT_STRATEGY_CONFIG.maxGales,
    cooldownSpins: overrides.cooldownSpins ?? DEFAULT_STRATEGY_CONFIG.cooldownSpins,
    minConsensus: overrides.minConsensus ?? DEFAULT_STRATEGY_CONFIG.minConsensus,
    confirmationSpins: overrides.confirmationSpins ?? DEFAULT_STRATEGY_CONFIG.confirmationSpins,
    maxCandidates: overrides.maxCandidates ?? DEFAULT_STRATEGY_CONFIG.maxCandidates,
    weights: { ...DEFAULT_STRATEGY_WEIGHTS, ...overrides.weights },
    sniper: {
      ...DEFAULT_SNIPER_PARAMS,
      window: sniperWindow,
      maxCandidates: Math.min(DEFAULT_SNIPER_PARAMS.maxCandidates, overrides.maxCandidates ?? DEFAULT_SNIPER_PARAMS.maxCandidates),
    },
    termo: {
      ...DEFAULT_TERMO_PARAMS,
      longWindow: analysisWindow ?? DEFAULT_TERMO_PARAMS.longWindow,
      maxCandidates: Math.min(DEFAULT_TERMO_PARAMS.maxCandidates, overrides.maxCandidates ?? DEFAULT_TERMO_PARAMS.maxCandidates),
    },
    quant: {
      ...DEFAULT_QUANT_PARAMS,
      window: quantWindow,
      pairLookback: Math.max(DEFAULT_QUANT_PARAMS.pairLookback, quantWindow),
      maxCandidates: Math.min(DEFAULT_QUANT_PARAMS.maxCandidates, overrides.maxCandidates ?? DEFAULT_QUANT_PARAMS.maxCandidates),
    },
    model: {
      ...DEFAULT_MODEL_PARAMS,
      minAgreement: overrides.minConsensus ?? DEFAULT_MODEL_PARAMS.minAgreement,
      maxCandidates: Math.min(DEFAULT_MODEL_PARAMS.maxCandidates, overrides.maxCandidates ?? DEFAULT_MODEL_PARAMS.maxCandidates),
    },
    focus: overrides.focus ?? null,
  };
}
