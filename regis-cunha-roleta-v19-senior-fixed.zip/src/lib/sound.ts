let ctx: AudioContext | null = null;

function getContext() {
  if (typeof window === "undefined") return null;
  const AudioCtor =
    window.AudioContext ||
    (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtor) return null;
  ctx ??= new AudioCtor();
  return ctx;
}

export async function playSignalTone() {
  const audio = getContext();
  if (!audio) return;
  if (audio.state === "suspended") await audio.resume().catch(() => undefined);
  const now = audio.currentTime;
  const osc = audio.createOscillator();
  const gain = audio.createGain();
  osc.type = "triangle";
  osc.frequency.setValueAtTime(492, now);
  osc.frequency.exponentialRampToValueAtTime(740, now + 0.16);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.08, now + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.28);
  osc.connect(gain);
  gain.connect(audio.destination);
  osc.start(now);
  osc.stop(now + 0.3);
}
