import { minePatterns, wilsonLowerBound } from "@/lib/analise/quant";
import { computeWindowStats } from "@/lib/analise/stats";
import type { QuantParams } from "@/lib/config/strategies";
import type { StrategyContext, StrategyOutput, StrategyReason } from "@/lib/types/strategy";
import { countsOf, emptyStrategy, lastSeenOf, round1, statusFromScore, toRanked } from "@/lib/strategies/helpers";

const BASELINE = 1 / 37;

export function runQuant(ctx: StrategyContext, params: QuantParams): StrategyOutput {
  const required = Math.max(30, Math.min(params.window, 40));
  const history = ctx.history;
  if (history.length < required) {
    return emptyStrategy("QUANT", "DADOS_INSUFICIENTES", history.length, required, params.window, ctx.timestamp, [
      { code: "history", text: `QUANT precisa de ${required} giros. Há ${history.length}.` },
    ]);
  }

  const window = Math.min(params.window, history.length);
  const sample = history.slice(0, window);
  const spins = ctx.spins.slice(0, window);
  const counts = countsOf(sample);
  const stats = computeWindowStats(spins, window);
  const patterns = minePatterns(spins, Math.min(params.pairLookback, spins.length));
  const expected = sample.length * BASELINE;

  const numberScores = Array.from({ length: 37 }, () => 0);
  const reasons: StrategyReason[] = [];
  const hot = stats.hot.filter((item) => item.count >= params.minCount);
  const delayed = stats.delayed.filter((item) => item.lastSeen >= 24);

  for (let number = 0; number <= 36; number += 1) {
    const count = counts[number];
    const wilson = wilsonLowerBound(count, sample.length);
    const edge = wilson - BASELINE;
    if (count >= params.minCount && edge > 0) {
      numberScores[number] += edge * 220 + (count - expected);
    } else if (count >= expected * 1.6 && count >= 2) {
      numberScores[number] += (count - expected) * 1.4;
    }
    const delay = lastSeenOf(sample, number);
    if (delay >= 32 && count <= expected) {
      numberScores[number] += Math.min(4, (delay - 24) / 10);
    }
  }

  const last = sample[0];
  if (last !== undefined) {
    const continuations = patterns.pairs.filter((pair) => pair.a === last && pair.count >= 2);
    for (const pair of continuations) {
      numberScores[pair.b] += pair.count * 1.8;
    }
    if (continuations[0]) {
      reasons.push({
        code: "pattern",
        text: `Padrão histórico ${last} → ${continuations[0].b} (${continuations[0].count}x na amostra)`,
      });
    }
  }

  if (hot[0]) {
    reasons.push({
      code: "frequency",
      text: `${hot[0].number} saiu ${hot[0].count}x na janela de ${window} (esperado ${round1(expected)})`,
    });
  }
  if (delayed[0]) {
    reasons.push({
      code: "delay",
      text: `${delayed[0].number} atrasado ${delayed[0].lastSeen} giros`,
    });
  }

  const rankedNumbers = numberScores
    .map((score, number) => ({ number, score }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score);

  const lead = rankedNumbers[0];
  let score = 0;
  if (lead) {
    const count = counts[lead.number];
    const wilson = wilsonLowerBound(count, sample.length);
    const edge = wilson - BASELINE;
    score += Math.max(0, edge) * 180 + Math.min(8, lead.score);
    if (edge > 0) {
      reasons.push({
        code: "wilson",
        text: `Wilson lower bound de ${lead.number} acima da baseline 1/37`,
      });
    }
  }

  if (patterns.concentration > 0.12) {
    score += Math.min(4, (patterns.concentration - 0.1) * 30);
    reasons.push({ code: "hhi", text: `Concentração estatística de terminais (HHI ${patterns.concentration.toFixed(3)})` });
  }

  const candidates = toRanked(
    rankedNumbers.map((item) => item.number),
    numberScores,
    "QUANT",
    params.maxCandidates,
  );
  const finalScore = round1(Math.min(18, score));
  const status = statusFromScore(finalScore, params.minScore, candidates.length > 0 && finalScore >= params.minScore * 0.5);

  if (status === "OBSERVANDO") {
    reasons.push({ code: "watch", text: "Sem desvio estatístico relevante frente à baseline." });
  }

  return {
    strategy: "QUANT",
    candidates,
    score: finalScore,
    reasons: reasons.slice(0, 4),
    window,
    timestamp: ctx.timestamp,
    status,
    requiredSpins: required,
    availableSpins: history.length,
  };
}
