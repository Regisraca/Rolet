import { getWheelNeighbors, WHEEL_ORDER } from "@/lib/analise/roulette";
import type { RankedCandidate, StrategyId, StrategyOutput, StrategyReason, StrategyStatus } from "@/lib/types/strategy";

export function round1(value: number) {
  return Math.round(value * 10) / 10;
}

export function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

export function wheelIndex(number: number) {
  return WHEEL_ORDER.indexOf(number as (typeof WHEEL_ORDER)[number]);
}

export function circularPocketDistance(a: number, b: number) {
  const ia = wheelIndex(a);
  const ib = wheelIndex(b);
  if (ia < 0 || ib < 0) return 18;
  const delta = Math.abs(ia - ib);
  return Math.min(delta, WHEEL_ORDER.length - delta);
}

export function meanCircularDistance(history: number[]) {
  if (history.length < 2) return 18.5;
  let sum = 0;
  let count = 0;
  for (let i = 0; i < history.length - 1; i += 1) {
    sum += circularPocketDistance(history[i], history[i + 1]);
    count += 1;
  }
  return count > 0 ? sum / count : 18.5;
}

export function numbersForTerminal(terminal: number) {
  return Array.from({ length: 37 }, (_, number) => number).filter((number) => number % 10 === terminal);
}

export function terminalSize(terminal: number) {
  return numbersForTerminal(terminal).length;
}

export function lastSeenOf(history: number[], number: number) {
  const index = history.indexOf(number);
  return index < 0 ? history.length : index;
}

export function lastSeenAny(history: number[], numbers: number[]) {
  let best = history.length;
  for (const number of numbers) {
    const seen = lastSeenOf(history, number);
    if (seen < best) best = seen;
  }
  return best;
}

export function countsOf(history: number[]) {
  const counts = Array.from({ length: 37 }, () => 0);
  for (const number of history) {
    if (number >= 0 && number <= 36) counts[number] += 1;
  }
  return counts;
}

export function wheelDensity(history: number[], radius: number, decay: number) {
  const density = Array.from({ length: 37 }, () => 0);
  history.forEach((number, index) => {
    const weight = decay ** index;
    const idx = wheelIndex(number);
    if (idx < 0) return;
    for (let offset = -radius; offset <= radius; offset += 1) {
      const pocket = WHEEL_ORDER[(idx + offset + WHEEL_ORDER.length) % WHEEL_ORDER.length];
      const kernel = 1 - Math.abs(offset) / (radius + 1);
      density[pocket] += weight * kernel;
    }
  });
  return density;
}

export function densestPocket(density: number[]) {
  let best = 0;
  for (let i = 1; i < density.length; i += 1) {
    if (density[i] > density[best]) best = i;
  }
  return best;
}

export function zoneHits(history: number[], center: number, radius: number) {
  const zone = getWheelNeighbors(center, radius);
  return history.filter((number) => zone.includes(number)).length;
}

export function candidateFingerprint(numbers: number[]) {
  return [...numbers].sort((a, b) => a - b).join("-");
}

export function overlapCount(a: number[], b: number[]) {
  const set = new Set(a);
  return b.filter((number) => set.has(number)).length;
}

export function similarSets(a: number[], b: number[], ratio = 0.5) {
  if (a.length === 0 || b.length === 0) return false;
  const needed = Math.max(1, Math.ceil(Math.min(a.length, b.length) * ratio));
  return overlapCount(a, b) >= needed;
}

export function emptyStrategy(
  strategy: StrategyId,
  status: StrategyStatus,
  available: number,
  required: number,
  window: number,
  timestamp: string,
  reasons: StrategyReason[] = [],
): StrategyOutput {
  return {
    strategy,
    candidates: [],
    score: 0,
    reasons,
    window,
    timestamp,
    status,
    requiredSpins: required,
    availableSpins: available,
  };
}

export function toRanked(numbers: number[], scores: number[], strategy: StrategyId, limit: number): RankedCandidate[] {
  return numbers
    .map((number) => ({ number, score: round1(scores[number] ?? 0), votes: [strategy] as StrategyId[] }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score || a.number - b.number)
    .slice(0, limit);
}

export function statusFromScore(score: number, minScore: number, hasCandidates: boolean): StrategyStatus {
  if (!hasCandidates) return "OBSERVANDO";
  if (score >= minScore) return "PRONTO";
  if (score >= minScore * 0.45) return "CANDIDATO";
  return "OBSERVANDO";
}
