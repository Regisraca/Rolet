import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { buildEngineConfig } from "../config/strategies.ts";
import { clusteredSpins, shortSpins, uniformSpins } from "../engine/fixtures.ts";
import { runIndependentStrategies } from "../engine/strategy-engine.ts";
import { combineConsensus } from "../engine/consensus-engine.ts";

const config = buildEngineConfig({ minScore: 10, minConsensus: 2, analysisWindow: 80 });

describe("estratégias independentes", () => {
  it("SNIPER aponta candidatos na zona física concentrada", () => {
    const [sniper] = runIndependentStrategies(clusteredSpins(80), config);
    assert.equal(sniper.strategy, "SNIPER");
    assert.notEqual(sniper.status, "DADOS_INSUFICIENTES");
    assert.ok(sniper.candidates.length > 0, "sniper deve devolver candidatos");
    assert.ok(sniper.score > 0, "sniper deve ter score");
    const numbers = sniper.candidates.map((item) => item.number);
    assert.ok(
      numbers.some((number) => [2, 25, 17, 34, 6].includes(number)),
      `zona de 17 esperada, veio ${numbers.join(",")}`,
    );
  });

  it("TERMO converte terminal quente em números candidatos", () => {
    const outputs = runIndependentStrategies(clusteredSpins(80), config);
    const termo = outputs.find((item) => item.strategy === "TERMO");
    assert.ok(termo);
    assert.notEqual(termo.status, "DADOS_INSUFICIENTES");
    assert.ok(termo.candidates.length > 0);
    const terminals = new Set(termo.candidates.map((item) => item.number % 10));
    assert.ok(terminals.has(2), `terminais ${[...terminals].join(",")}`);
  });

  it("QUANT usa frequência/atraso e devolve score", () => {
    const outputs = runIndependentStrategies(clusteredSpins(90), config);
    const quant = outputs.find((item) => item.strategy === "QUANT");
    assert.ok(quant);
    assert.notEqual(quant.status, "DADOS_INSUFICIENTES");
    assert.ok(quant.candidates.length > 0);
    assert.ok(quant.score >= 0);
  });

  it("MODELO ranqueia a interseção entre as três", () => {
    const outputs = runIndependentStrategies(clusteredSpins(90), config);
    const modelo = outputs.find((item) => item.strategy === "MODELO");
    assert.ok(modelo);
    const consensus = combineConsensus(outputs, config);
    assert.ok(consensus.ranking.length > 0);
    const agreed = consensus.ranking.filter((item) => item.votes.length >= 2);
    assert.ok(agreed.length > 0, "deve haver números com pelo menos 2 votos");
  });

  it("histórico curto devolve DADOS INSUFICIENTES e não inventa candidatos fortes", () => {
    const outputs = runIndependentStrategies(shortSpins(8), config);
    assert.ok(outputs.every((item) => item.status === "DADOS_INSUFICIENTES" || item.candidates.length === 0));
    const consensus = combineConsensus(outputs, config);
    assert.equal(consensus.status, "DADOS_INSUFICIENTES");
    assert.equal(consensus.ranking.length, 0);
  });

  it("distribuição uniforme não dispara consenso PRONTO", () => {
    const outputs = runIndependentStrategies(uniformSpins(80), config);
    const consensus = combineConsensus(outputs, config);
    assert.notEqual(consensus.status, "PRONTO");
  });
});
