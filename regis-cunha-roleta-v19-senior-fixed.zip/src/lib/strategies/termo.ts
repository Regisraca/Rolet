import type { TermoParams } from "@/lib/config/strategies";
import type { StrategyContext, StrategyOutput, StrategyReason } from "@/lib/types/strategy";
import {
  emptyStrategy,
  lastSeenAny,
  numbersForTerminal,
  round1,
  statusFromScore,
  terminalSize,
  toRanked,
} from "@/lib/strategies/helpers";

type TerminalStat = {
  terminal: number;
  short: number;
  medium: number;
  long: number;
  delay: number;
  score: number;
  expectedShort: number;
  expectedMedium: number;
  expectedLong: number;
};

function windowHits(history: number[], size: number, terminal: number) {
  const sample = history.slice(0, Math.min(size, history.length));
  return sample.filter((number) => number % 10 === terminal).length;
}

function expectedHits(sampleSize: number, terminal: number) {
  return (sampleSize * terminalSize(terminal)) / 37;
}

export function runTermo(ctx: StrategyContext, params: TermoParams): StrategyOutput {
  const required = params.mediumWindow;
  const history = ctx.history;
  if (history.length < required) {
    return emptyStrategy("TERMO", "DADOS_INSUFICIENTES", history.length, required, params.mediumWindow, ctx.timestamp, [
      { code: "history", text: `TERMO precisa de ${required} giros. Há ${history.length}.` },
    ]);
  }

  const stats: TerminalStat[] = Array.from({ length: 10 }, (_, terminal) => {
    const short = windowHits(history, params.shortWindow, terminal);
    const medium = windowHits(history, params.mediumWindow, terminal);
    const long = windowHits(history, params.longWindow, terminal);
    const delay = lastSeenAny(history, numbersForTerminal(terminal));
    const expectedShort = expectedHits(Math.min(params.shortWindow, history.length), terminal);
    const expectedMedium = expectedHits(Math.min(params.mediumWindow, history.length), terminal);
    const expectedLong = expectedHits(Math.min(params.longWindow, history.length), terminal);
    const shortRatio = expectedShort > 0 ? short / expectedShort : 0;
    const mediumRatio = expectedMedium > 0 ? medium / expectedMedium : 0;
    const longRatio = expectedLong > 0 ? long / expectedLong : 0;
    const freq = Math.max(0, shortRatio - 1) * 6 + Math.max(0, mediumRatio - 1) * 4 + Math.max(0, longRatio - 1) * 2;
    const expectedGap = 37 / terminalSize(terminal);
    const delayScore = delay >= expectedGap * 1.8 ? Math.min(5, (delay - expectedGap) / 6) : 0;
    return {
      terminal,
      short,
      medium,
      long,
      delay,
      expectedShort,
      expectedMedium,
      expectedLong,
      score: freq + delayScore,
    };
  }).sort((a, b) => b.score - a.score);

  const lastThree = history.slice(0, 3).map((number) => number % 10);
  const sequenceSame = lastThree.length === 3 && lastThree.every((terminal) => terminal === lastThree[0]);
  const sequencePair = lastThree.length >= 2 && lastThree[0] === lastThree[1];

  const longSample = history.slice(0, Math.min(params.longWindow, history.length));
  const shares = Array.from({ length: 10 }, (_, terminal) => {
    const hits = longSample.filter((number) => number % 10 === terminal).length;
    return longSample.length ? hits / longSample.length : 0;
  });
  const hhi = shares.reduce((sum, share) => sum + share * share, 0);
  const randomHhi = 10 * (0.1 * 0.1);
  const concentration = hhi - randomHhi;

  const top = stats.filter((item) => item.score > 0).slice(0, params.topTerminals);
  const reasons: StrategyReason[] = [];
  let score = 0;

  if (top[0] && top[0].score > 0) {
    score += Math.min(14, top[0].score);
    const lead = top[0];
    if (lead.short / Math.max(0.01, lead.expectedShort) > 1.2) {
      reasons.push({
        code: "short",
        text: `T${lead.terminal} acima da média na janela curta (${lead.short}/${params.shortWindow})`,
      });
    } else if (lead.medium / Math.max(0.01, lead.expectedMedium) > 1.15) {
      reasons.push({
        code: "medium",
        text: `T${lead.terminal} acima da média na janela média (${lead.medium}/${params.mediumWindow})`,
      });
    } else {
      reasons.push({
        code: "delay",
        text: `T${lead.terminal} com atraso ${lead.delay} giros`,
      });
    }
  }

  if (top[1] && top[1].score >= 2) {
    score += Math.min(6, top[1].score * 0.6);
    reasons.push({
      code: "second",
      text: `T${top[1].terminal} também concentrado`,
    });
  }

  if (sequenceSame) {
    score += 5;
    reasons.push({ code: "sequence", text: `Sequência de T${lastThree[0]} nos últimos 3 giros` });
  } else if (sequencePair) {
    score += 2.5;
    reasons.push({ code: "repeat", text: `T${lastThree[0]} repetiu no giro anterior` });
  }

  if (concentration > 0.02) {
    score += Math.min(4, concentration * 40);
    reasons.push({ code: "hhi", text: `Concentração de terminais acima do acaso` });
  }

  const numberScores = Array.from({ length: 37 }, () => 0);
  for (const item of top) {
    for (const number of numbersForTerminal(item.terminal)) {
      numberScores[number] = item.score + (history[0] !== undefined && history[0] % 10 === item.terminal ? 1 : 0);
    }
  }

  const candidateNumbers = top.flatMap((item) => numbersForTerminal(item.terminal));
  const candidates = toRanked(candidateNumbers, numberScores, "TERMO", params.maxCandidates);
  const finalScore = round1(Math.min(18, score));
  const strong = Boolean(top[0] && top[0].score >= 4 && candidates.length > 0);
  const status = statusFromScore(finalScore, params.minScore, strong);

  if (status === "OBSERVANDO") {
    reasons.push({ code: "watch", text: "Terminais sem desvio relevante nas três janelas." });
  }

  return {
    strategy: "TERMO",
    candidates,
    score: finalScore,
    reasons: reasons.slice(0, 4),
    window: Math.min(params.longWindow, history.length),
    timestamp: ctx.timestamp,
    status,
    requiredSpins: required,
    availableSpins: history.length,
  };
}
