import { getWheelNeighbors, sectorOf } from "@/lib/analise/roulette";
import type { SniperParams } from "@/lib/config/strategies";
import type { StrategyContext, StrategyOutput, StrategyReason } from "@/lib/types/strategy";
import {
  densestPocket,
  emptyStrategy,
  meanCircularDistance,
  round1,
  statusFromScore,
  toRanked,
  wheelDensity,
  zoneHits,
} from "@/lib/strategies/helpers";

export function runSniper(ctx: StrategyContext, params: SniperParams): StrategyOutput {
  const window = Math.min(params.window, ctx.history.length);
  const history = ctx.history.slice(0, window);
  const required = Math.max(params.shortWindow, 16);

  if (history.length < required) {
    return emptyStrategy("SNIPER", "DADOS_INSUFICIENTES", history.length, required, params.window, ctx.timestamp, [
      { code: "history", text: `SNIPER precisa de ${required} giros. Há ${history.length}.` },
    ]);
  }

  const short = history.slice(0, Math.min(params.shortWindow, history.length));
  const density = wheelDensity(history, params.zoneRadius, params.recencyDecay);
  const peak = densestPocket(density);
  const zone = getWheelNeighbors(peak, params.zoneRadius);
  const hits = zoneHits(short, peak, params.zoneRadius);
  const expected = (short.length * zone.length) / 37;
  const concentration = expected > 0 ? hits / expected : 0;
  const tightness = 1 - meanCircularDistance(short) / 18.5;

  const slices = 3;
  const sliceSize = Math.max(6, Math.floor(Math.min(24, history.length) / slices));
  const sectors = Array.from({ length: slices }, (_, index) => {
    const slice = history.slice(index * sliceSize, (index + 1) * sliceSize);
    const counts = { P1: 0, P2: 0, P3: 0 };
    for (const number of slice) {
      const sector = sectorOf(number);
      if (sector !== "zero") counts[sector] += 1;
    }
    return (Object.entries(counts) as ["P1" | "P2" | "P3", number][]).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "P1";
  });
  let recurrence = 1;
  for (let i = 1; i < sectors.length; i += 1) {
    if (sectors[i] === sectors[0]) recurrence += 1;
  }

  const last = history[0];
  const lastZoneHits = last === undefined ? 0 : zoneHits(short, last, params.zoneRadius);
  const lastRepeat = last === undefined ? 0 : short.filter((number) => number === last).length;

  let score = 0;
  const reasons: StrategyReason[] = [];

  if (hits >= params.minZoneHits && concentration >= 1.8) {
    const part = clampPart((concentration - 1) * 6, 0, 12);
    score += part;
    reasons.push({
      code: "concentration",
      text: `Região física concentrada: ${hits}/${short.length} na zona de ${peak} (esperado ${round1(expected)})`,
    });
  }

  if (tightness >= 0.35) {
    const part = clampPart(tightness * 7, 0, 8);
    score += part;
    reasons.push({
      code: "distance",
      text: `Distância média na roda ${round1(meanCircularDistance(short))} bolsas`,
    });
  }

  if (recurrence >= 2) {
    score += recurrence * 2.2;
    reasons.push({
      code: "recurrence",
      text: `Setor ${sectors[0]} recorrente em ${recurrence} janelas`,
    });
  }

  if (lastZoneHits >= params.minZoneHits) {
    score += Math.min(6, lastZoneHits);
    reasons.push({
      code: "neighbors",
      text: `Zona do ${last} com ${lastZoneHits} hits na janela curta`,
    });
  }

  if (lastRepeat >= 2) {
    score += 2 + lastRepeat;
    reasons.push({
      code: "repeat",
      text: `${last} repetiu ${lastRepeat}x na janela curta`,
    });
  }

  const candidateScores = Array.from({ length: 37 }, (_, number) => density[number] * 4 + (zone.includes(number) ? concentration : 0));
  const candidates = toRanked(zone, candidateScores, "SNIPER", params.maxCandidates);
  const finalScore = round1(Math.min(18, score));
  const strong = hits >= params.minZoneHits && concentration >= 1.8 && candidates.length > 0;
  const status = statusFromScore(finalScore, params.minScore, strong);

  if (candidates.length === 0 || status === "OBSERVANDO") {
    reasons.push({ code: "watch", text: "Sem zona física com evidência suficiente." });
  }

  return {
    strategy: "SNIPER",
    candidates,
    score: finalScore,
    reasons: reasons.slice(0, 4),
    window,
    timestamp: ctx.timestamp,
    status,
    requiredSpins: required,
    availableSpins: history.length,
  };
}

function clampPart(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}
