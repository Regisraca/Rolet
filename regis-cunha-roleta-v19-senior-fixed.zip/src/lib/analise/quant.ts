import { getWheelNeighbors, type Spin } from "@/lib/analise/roulette";

export function wilsonLowerBound(hits: number, n: number, z = 1.96) {
  if (n <= 0) return 0;
  const p = hits / n;
  const z2 = z * z;
  const denom = 1 + z2 / n;
  const center = p + z2 / (2 * n);
  const margin = z * Math.sqrt((p * (1 - p) + z2 / (4 * n)) / n);
  return Math.max(0, (center - margin) / denom);
}

export function expectedHitRate(coverage: number, attempts: number) {
  const miss = Math.max(0, (37 - coverage) / 37);
  return 1 - miss ** Math.max(1, attempts);
}

export type PatternPair = { a: number; b: number; count: number };
export type PatternReport = {
  sample: number;
  pairs: PatternPair[];
  terminalShare: { terminal: number; share: number }[];
  neighborRecovery: number | null;
  longestColorStreak: { label: string; length: number };
  concentration: number;
};

export function minePatterns(spins: Spin[], window = 200): PatternReport {
  const sample = spins.slice(0, window);
  const pairMap = new Map<string, PatternPair>();
  for (let i = 0; i < sample.length - 1; i += 1) {
    const a = sample[i + 1].number;
    const b = sample[i].number;
    const key = `${a}->${b}`;
    const current = pairMap.get(key) ?? { a, b, count: 0 };
    current.count += 1;
    pairMap.set(key, current);
  }

  const terminals = Array.from({ length: 10 }, () => 0);
  for (const spin of sample) terminals[spin.terminal] += 1;
  const terminalShare = terminals
    .map((count, terminal) => ({ terminal, share: sample.length ? count / sample.length : 0 }))
    .sort((a, b) => b.share - a.share);

  let recovered = 0;
  let delayed = 0;
  const lastIndex = Array.from({ length: 37 }, () => -1);
  sample.forEach((spin, index) => {
    const prev = lastIndex[spin.number];
    if (prev >= 0) {
      const gap = index - prev;
      if (gap >= 6) {
        delayed += 1;
        const neighbors = getWheelNeighbors(spin.number, 2);
        const windowAfter = sample.slice(Math.max(0, prev - 3), prev);
        if (windowAfter.some((item) => neighbors.includes(item.number))) recovered += 1;
      }
    }
    lastIndex[spin.number] = index;
  });

  let longest = { label: "—", length: 0 };
  let runLabel = "";
  let run = 0;
  for (const spin of [...sample].reverse()) {
    const label = spin.color;
    if (label === runLabel) run += 1;
    else {
      if (run > longest.length) longest = { label: runLabel || label, length: run };
      runLabel = label;
      run = 1;
    }
  }
  if (run > longest.length) longest = { label: runLabel, length: run };

  const shares = terminalShare.map((item) => item.share);
  const concentration = shares.reduce((sum, share) => sum + share * share, 0);

  return {
    sample: sample.length,
    pairs: [...pairMap.values()].sort((a, b) => b.count - a.count).slice(0, 8),
    terminalShare: terminalShare.slice(0, 5),
    neighborRecovery: delayed > 0 ? recovered / delayed : null,
    longestColorStreak: longest,
    concentration,
  };
}

export function unitsForCoverage(coverage: number, gale: 0 | 1 | 2) {
  const multiplier = 2 ** gale;
  return coverage * multiplier;
}

export function netIfHit(coverage: number, gale: 0 | 1 | 2) {
  const multiplier = 2 ** gale;
  return (36 - coverage) * multiplier;
}

export function missCost(coverage: number, maxGales: number) {
  let cost = 0;
  for (let gale = 0; gale <= maxGales; gale += 1) cost += coverage * 2 ** gale;
  return cost;
}
