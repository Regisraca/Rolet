export const WHEEL_ORDER = [
  0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24,
  16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26,
] as const;

export const RED_NUMBERS = new Set([
  1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36,
]);

export const WHEEL_SECTORS = {
  P1: [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27],
  P2: [13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1],
  P3: [20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26],
} as const;

export type PocketColor = "green" | "red" | "black";
export type SignalType = "SNIPER" | "TERMO" | "QUANT" | "MODELO";
export type SignalTone = "ember" | "sage" | "stone" | "blue";
export type SignalPhase =
  | "OBSERVANDO"
  | "CANDIDATO"
  | "CONFIRMACAO"
  | "SINAL_ATIVO"
  | "G0"
  | "G1"
  | "G2"
  | "G3"
  | "G4"
  | "G5"
  | "G6"
  | "GREEN"
  | "RED";
export type SignalResult = "GREEN" | "RED" | "PENDING";
export type ConnectorStatus =
  | "disconnected"
  | "connecting"
  | "connected"
  | "capturing"
  | "paused"
  | "error";
export type SourceStatus = "online" | "connecting" | "unavailable" | "error" | "idle";
export type Parity = "par" | "ímpar" | "zero";
export type HighLow = "baixa" | "alta" | "zero";

export type LuckyNumber = {
  number: number;
  multiplier: number | null;
};

export type Spin = {
  id: string;
  sourceEventId: string;
  number: number;
  color: PocketColor;
  createdAt: string;
  luckyNumbers: LuckyNumber[];
  multiplier: number | null;
  totalWinners: number | null;
  parity: Parity;
  dozen: 0 | 1 | 2 | 3;
  column: 0 | 1 | 2 | 3;
  terminal: number;
  highLow: HighLow;
  tableId: string;
  provider: string;
  sessionId: string | null;
};

export type RouletteSource = {
  status: SourceStatus;
  origin: string;
  table: string;
  provider: string;
  message: string;
  lastEventAt: string | null;
  totalAvailable: number | null;
};

export type RouletteState = {
  spins: Spin[];
  source: RouletteSource;
  sessionId: string | null;
  inserted: number;
};

export type FilterHit = {
  id: string;
  name: string;
  points: number;
  reason: string;
};

export type StrategyContribution = {
  strategy: SignalType;
  score: number;
  weight: number;
  weighted: number;
  summary: string;
  candidates: number[];
};

export type Signal = {
  id: string;
  type: SignalType;
  tone: SignalTone;
  title: string;
  trigger: string;
  targets: number[];
  score: number;
  strength: number;
  filters: FilterHit[];
  greens: number;
  reds: number;
  maxGales: number;
  createdAt: string;
  triggerSpinId: string;
  active: boolean;
  result: SignalResult;
  spinsSince: number;
  phase: SignalPhase;
  consensus: number;
  consensusTotal: number;
  explanation: StrategyContribution[];
  galeStep?: number;
  resolvedAt?: string;
  resolvedNumber?: number;
  resolvedSpinId?: string;
  galeHit?: number;
  apostaStr?: string;
  galeAtual?: number;
  isTermo?: boolean;
  alvoCentral?: number | string;
};

export function isRed(number: number) {
  return RED_NUMBERS.has(number);
}

export function numberColor(number: number): PocketColor {
  if (number === 0) return "green";
  return isRed(number) ? "red" : "black";
}

export function getWheelNeighbors(number: number, amount = 2) {
  const index = WHEEL_ORDER.indexOf(number as (typeof WHEEL_ORDER)[number]);
  if (index < 0) return [number];
  const length = WHEEL_ORDER.length;
  return Array.from({ length: amount * 2 + 1 }, (_, offset) => {
    return WHEEL_ORDER[(index + offset - amount + length) % length];
  });
}

export function formatRelativeTime(value: string, now = Date.now()) {
  const seconds = Math.max(0, Math.floor((now - new Date(value).getTime()) / 1000));
  if (seconds < 8) return "agora";
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} h`;
  return `${Math.floor(hours / 24)} d`;
}

export function dozenOf(number: number): 0 | 1 | 2 | 3 {
  if (number <= 0) return 0;
  if (number <= 12) return 1;
  if (number <= 24) return 2;
  return 3;
}

export function columnOf(number: number): 0 | 1 | 2 | 3 {
  if (number <= 0) return 0;
  const mod = number % 3;
  if (mod === 1) return 1;
  if (mod === 2) return 2;
  return 3;
}

export function terminalOf(number: number) {
  return number % 10;
}

export function parityOf(number: number): Parity {
  if (number === 0) return "zero";
  return number % 2 === 0 ? "par" : "ímpar";
}

export function highLowOf(number: number): HighLow {
  if (number === 0) return "zero";
  return number <= 18 ? "baixa" : "alta";
}

export function sectorOf(number: number): "P1" | "P2" | "P3" | "zero" {
  if (WHEEL_SECTORS.P1.includes(number as (typeof WHEEL_SECTORS.P1)[number])) return "P1";
  if (WHEEL_SECTORS.P2.includes(number as (typeof WHEEL_SECTORS.P2)[number])) return "P2";
  return "P3";
}

export function colorLabel(number: number) {
  const tone = numberColor(number);
  if (tone === "green") return "Verde";
  if (tone === "red") return "Vermelho";
  return "Preto";
}

export function enrichSpin(
  partial: Omit<Spin, "parity" | "dozen" | "column" | "terminal" | "highLow" | "color"> & {
    color?: PocketColor;
  },
): Spin {
  return {
    ...partial,
    color: partial.color ?? numberColor(partial.number),
    parity: parityOf(partial.number),
    dozen: dozenOf(partial.number),
    column: columnOf(partial.number),
    terminal: terminalOf(partial.number),
    highLow: highLowOf(partial.number),
  };
}

export function isValidPocket(number: unknown): number is number {
  return typeof number === "number" && Number.isInteger(number) && number >= 0 && number <= 36;
}

export function tagForNumber(number: number, tag: string) {
  if (tag === "D1") return number >= 1 && number <= 12;
  if (tag === "D2") return number >= 13 && number <= 24;
  if (tag === "D3") return number >= 25 && number <= 36;
  if (tag === "C1") return number > 0 && number % 3 === 1;
  if (tag === "C2") return number > 0 && number % 3 === 2;
  if (tag === "C3") return number > 0 && number % 3 === 0;
  if (tag === "R") return isRed(number);
  if (tag === "B") return number > 0 && !isRed(number);
  if (tag === "P") return number > 0 && number % 2 === 0;
  if (tag === "O") return number % 2 === 1;
  if (tag === "L") return number > 0 && number <= 18;
  if (tag === "H") return number >= 19;
  if (tag === "P1") return WHEEL_SECTORS.P1.includes(number as (typeof WHEEL_SECTORS.P1)[number]);
  if (tag === "P2") return WHEEL_SECTORS.P2.includes(number as (typeof WHEEL_SECTORS.P2)[number]);
  if (tag === "P3") return WHEEL_SECTORS.P3.includes(number as (typeof WHEEL_SECTORS.P3)[number]);
  return false;
}

export function connectorLabel(status: ConnectorStatus) {
  if (status === "disconnected") return "Desconectado";
  if (status === "connecting") return "Conectando";
  if (status === "connected") return "Conectado";
  if (status === "capturing") return "Capturando";
  if (status === "paused") return "Pausado";
  return "Erro";
}

export function captureLabel(status: ConnectorStatus) {
  if (status === "capturing") return "Capturando";
  if (status === "paused") return "Pausado";
  if (status === "connected") return "Pronta";
  if (status === "connecting") return "Aguardando";
  if (status === "error") return "Falha";
  return "Parada";
}
