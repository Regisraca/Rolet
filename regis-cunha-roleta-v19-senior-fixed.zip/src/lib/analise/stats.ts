import type { AnalysisWindow } from "@/lib/config/app";
import {
  dozenOf,
  columnOf,
  isRed,
  numberColor,
  type Spin,
} from "@/lib/analise/roulette";

export type WindowStats = {
  total: number;
  red: number;
  black: number;
  green: number;
  even: number;
  odd: number;
  low: number;
  high: number;
  dozens: [number, number, number];
  columns: [number, number, number];
  hot: { number: number; count: number; lastSeen: number }[];
  cold: { number: number; count: number; lastSeen: number }[];
  delayed: { number: number; lastSeen: number; count: number }[];
  terminals: { terminal: number; count: number }[];
  repeats: { number: number; streak: number };
  streaks: {
    color: { label: string; length: number };
    parity: { label: string; length: number };
    dozen: { label: string; length: number };
  };
};

function lastSeenOf(sample: Spin[], number: number) {
  const index = sample.findIndex((spin) => spin.number === number);
  return index < 0 ? sample.length : index;
}

function streakOf<T>(sample: Spin[], read: (spin: Spin) => T | null) {
  if (sample.length === 0) return { label: "—", length: 0 };
  const first = read(sample[0]);
  if (first === null) return { label: "—", length: 0 };
  let length = 0;
  for (const spin of sample) {
    if (read(spin) !== first) break;
    length += 1;
  }
  return { label: String(first), length };
}

export function computeWindowStats(spins: Spin[], window: AnalysisWindow | number): WindowStats {
  const sample = spins.slice(0, window);
  const counts = Array.from({ length: 37 }, () => 0);
  let red = 0;
  let black = 0;
  let green = 0;
  let even = 0;
  let odd = 0;
  let low = 0;
  let high = 0;
  const dozens: [number, number, number] = [0, 0, 0];
  const columns: [number, number, number] = [0, 0, 0];
  const terminals = Array.from({ length: 10 }, () => 0);

  for (const spin of sample) {
    counts[spin.number] += 1;
    if (spin.number === 0) green += 1;
    else if (isRed(spin.number)) red += 1;
    else black += 1;
    if (spin.number > 0) {
      if (spin.number % 2 === 0) even += 1;
      else odd += 1;
      if (spin.number <= 18) low += 1;
      else high += 1;
      dozens[dozenOf(spin.number) - 1] += 1;
      columns[columnOf(spin.number) - 1] += 1;
    }
    terminals[spin.number % 10] += 1;
  }

  const ranked = counts.map((count, number) => ({
    number,
    count,
    lastSeen: lastSeenOf(sample, number),
  }));

  let streak = 0;
  if (sample[0]) {
    for (const spin of sample) {
      if (spin.number !== sample[0].number) break;
      streak += 1;
    }
  }

  return {
    total: sample.length,
    red,
    black,
    green,
    even,
    odd,
    low,
    high,
    dozens,
    columns,
    hot: [...ranked].filter((item) => item.count > 0).sort((a, b) => b.count - a.count || a.lastSeen - b.lastSeen).slice(0, 8),
    cold: [...ranked].sort((a, b) => a.count - b.count || b.lastSeen - a.lastSeen).slice(0, 8),
    delayed: [...ranked].sort((a, b) => b.lastSeen - a.lastSeen || a.count - b.count).slice(0, 8),
    terminals: terminals.map((count, terminal) => ({ terminal, count })).sort((a, b) => b.count - a.count),
    repeats: { number: sample[0]?.number ?? -1, streak },
    streaks: {
      color: streakOf(sample, (spin) => (spin.number === 0 ? null : numberColor(spin.number))),
      parity: streakOf(sample, (spin) => (spin.number === 0 ? null : spin.parity)),
      dozen: streakOf(sample, (spin) => (spin.dozen === 0 ? null : `D${spin.dozen}`)),
    },
  };
}

export function pct(value: number, total: number) {
  if (total <= 0) return 0;
  return Math.round((value / total) * 100);
}
