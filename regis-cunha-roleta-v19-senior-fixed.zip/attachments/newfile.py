import os
import csv
import json
import time
import logging
import urllib.request
import urllib.parse
import threading
import warnings
import subprocess
import math
from datetime import datetime
from typing import Any
import tkinter as tk
from tkinter import messagebox, ttk
from playwright.sync_api import sync_playwright
import sqlite3
from datetime import date, datetime
def inicializar_banco():
    conn = sqlite3.connect('gestao_banca.db')
    cursor = conn.cursor()
    # Cria a tabela para guardar o histórico dos dias, garantindo que a data seja única
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS historico_diario (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data_registro DATE UNIQUE,
            mes_ano TEXT,
            lucro REAL
        )
    ''')
    conn.commit()
    conn.close()

# Executa a função imediatamente ao abrir o script
inicializar_banco()
try:
    import winsound
except ImportError:
    winsound = None

logging.basicConfig(
    filename='bot_errors.log',
    level=logging.ERROR,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

warnings.filterwarnings("ignore")

APP_NOME = "RÉGIS CUNHA ROLETA"
APP_VERSAO = "v19.0"

CONFIG_FILE = "config.json"
FAVORITOS_FILE = "favoritos.json"
AUDIT_FILE = "sessao_historico.json"
RELATORIOS_DIR = "relatorios"

# Blindagem de conexão: tempo máximo (s) sem novos números antes de reciclar a mesa
TIMEOUT_SEM_LEITURA = 180
# Limites de memória para sessões longas (evita crescimento infinito de widgets/séries)
MAX_ENTRADAS_HISTORICO = 300
MAX_PONTOS_GRAFICO = 60

TAGS_VALIDAS = {
    "R", "B", "D1", "D2", "D3", "C1", "C2", "C3", 
    "P", "O", "L", "H", "N", "P1", "P2", "P3", 
    "T0", "T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9"
}.union({str(i) for i in range(37)})

VERMELHOS = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}

SETORES_FISICOS = {
    "P1": {0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27},
    "P2": {13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1},
    "P3": {20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26}
}

TERMINAIS_MAP = {
    "T0": ["0", "10", "20", "30"],
    "T1": ["1", "11", "21", "31"],
    "T2": ["2", "12", "22", "32"],
    "T3": ["3", "13", "23", "33"],
    "T4": ["4", "14", "24", "34"],
    "T5": ["5", "15", "25", "35"],
    "T6": ["6", "16", "26", "36"],
    "T7": ["7", "17", "27"],
    "T8": ["8", "18", "28"],
    "T9": ["9", "19", "29"]
}

# Quantos números cada tag cobre na mesa (usado para medir risco/cobertura real)
NUMEROS_POR_TAG = {}

# ORDEM FÍSICA DA ROLETA EUROPEIA
RODA_EUROPEIA = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26]

class RoletaAoVivo:
    def __init__(self, master, app_ref):
        self.app = app_ref
        self.top = tk.Toplevel(master)
        self.top.title(f"{APP_NOME} {APP_VERSAO} • ROLETA AO VIVO")
        self.top.geometry("1180x900")
        self.top.minsize(1080, 700)
        self.top.configure(bg="#070A10")
        self.top.protocol("WM_DELETE_WINDOW", self.esconder)

   # 🎨 PALETA PREMIUM COM CORES VIVAS
        self.bg = "#070A10"
        self.panel = "#0D111B"
        self.panel3 = "#0A0F17"
        self.panel2 = "#111827"
        self.border = "#1E293B"
        self.text = "#E5E7EB"
        self.muted = "#718096"
        self.cyan = "#22D3EE"
        self.green = "#34D399"
        self.amber = "#FBBF24"
        self.red = "#FB7185"
        self.purple = "#A78BFA"
        self.neon_green = "#00FF88"
        self.neon_red = "#FF1744"
        self.glow_cyan = "#00FFFF"

        # ── SISTEMA DE SCROLL (ROLETA) ──
        self.main_canvas = tk.Canvas(self.top, bg=self.bg, highlightthickness=0)
        self.main_scrollbar = ttk.Scrollbar(self.top, orient="vertical", command=self.main_canvas.yview)
        
        shell = tk.Frame(self.main_canvas, bg=self.bg)
        self.shell_window = self.main_canvas.create_window((0, 0), window=shell, anchor="nw")
        
        self.main_canvas.configure(yscrollcommand=self.main_scrollbar.set)
        self.main_canvas.pack(side="left", fill="both", expand=True)
        self.main_scrollbar.pack(side="right", fill="y")
        
        def configure_shell(event):
            self.main_canvas.configure(scrollregion=self.main_canvas.bbox("all"))
        def configure_canvas(event):
            self.main_canvas.itemconfig(self.shell_window, width=event.width)
            
        shell.bind("<Configure>", configure_shell)
        self.main_canvas.bind("<Configure>", configure_canvas)

        def _on_mousewheel_roleta(event):
            widget = event.widget
            if isinstance(widget, (tk.Listbox, tk.Text)):
                return
            if widget.winfo_toplevel() == self.top:
                self.main_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
                
        self.top.bind_all("<MouseWheel>", _on_mousewheel_roleta, add="+")

        # Container Principal
        pad_frame = tk.Frame(shell, bg=self.bg)
        pad_frame.pack(fill="both", expand=True, padx=16, pady=16)

# --- HEADER COM CORES E GLOW ---
        header = tk.Frame(pad_frame, bg=self.bg)
        header.pack(fill="x", pady=(0, 12))

# Header com borda glow
        header_bg = tk.Frame(header, bg=self.panel, highlightbackground=self.glow_cyan, highlightthickness=2)
        header_bg.pack(fill="x", padx=2, pady=2)

        title_box = tk.Frame(header_bg, bg=self.panel)
        title_box.pack(fill="x", padx=16, pady=(12, 8))

# Título com neon
        tk.Label(title_box, text="🎰 PAINEL DA ROLETA AO VIVO", bg=self.panel, 
         fg=self.glow_cyan, font=("Segoe UI", 18, "bold")).pack(anchor="w")

# Subtítulo colorido
        sub_frame = tk.Frame(title_box, bg=self.panel)
        sub_frame.pack(anchor="w", pady=(2, 0))

        tk.Label(sub_frame, text="⚡ TERMINAL DE OPERAÇÕES", bg=self.panel, fg=self.neon_green, 
         font=("Segoe UI", 9, "bold")).pack(side="left")
        tk.Label(sub_frame, text=" & ", bg=self.panel, fg=self.muted, 
         font=("Segoe UI", 9, "bold")).pack(side="left")
        tk.Label(sub_frame, text="INTELIGÊNCIA", bg=self.panel, fg=self.glow_cyan, 
         font=("Segoe UI", 9, "bold")).pack(side="left")
        tk.Label(sub_frame, text="LABORATÓRIO", bg=self.panel, fg=self.amber, 
         font=("Segoe UI", 9, "bold")).pack(side="left")

# Status com indicador animado
        status_frame = tk.Frame(title_box, bg="#0A2224", highlightbackground=self.glow_cyan, 
                       highlightthickness=1)
        status_frame.pack(side="right", padx=(10, 0))

        self.status_dot = tk.Label(status_frame, text="●", bg="#0A2224", 
                           fg=self.neon_green, font=("Segoe UI", 14, "bold"))
        self.status_dot.pack(side="left", padx=(8, 2))

        tk.Label(status_frame, text=" SYSTEM ONLINE ", bg="#0A2224", 
         fg=self.text, font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 8))

# Botão de Gestão de Banca (Onde você desenhou o quadrado vermelho)
        self.btn_abrir_gestao = tk.Button(title_box, text="📈 GESTÃO DE BANCA", 
                                          command=lambda: GestaoBancaDashboard(self.top, self.app), 
                                          bg="#D97706", fg="#FFFFFF", activebackground="#F59E0B", 
                                          activeforeground="#FFFFFF", relief="flat", bd=0, 
                                          font=("Segoe UI", 8, "bold"), cursor="hand2", padx=12, pady=6)
        self.btn_abrir_gestao.pack(side="right", padx=(0, 10))
        btn_close = tk.Button(title_box, text="✖ FECHAR PAINEL", command=self.esconder, 
                      bg=self.panel2, fg=self.neon_red, activebackground="#240810", 
                      activeforeground="#FDA4AF", relief="flat", bd=0, 
                      font=("Segoe UI", 8, "bold"), cursor="hand2", padx=12, pady=6)
        btn_close.pack(side="right")

        tk.Frame(pad_frame, bg=self.border, height=1).pack(fill="x", pady=(0, 14))

        content = tk.Frame(pad_frame, bg=self.bg)
        content.pack(fill="both", expand=True)

        # --- LADO ESQUERDO: CILINDRO & HISTÓRICO ---
        left = tk.Frame(content, bg=self.bg)
        left.pack(side="left", fill="y", padx=(0, 12))
        tk.Frame(left, width=480, height=1, bg=self.bg).pack() 

        wheel_card = tk.Frame(left, bg=self.panel, highlightbackground=self.border, highlightthickness=1)
        wheel_card.pack(fill="x", pady=(0, 10))
        
        wheel_header = tk.Frame(wheel_card, bg=self.panel)
        wheel_header.pack(fill="x", padx=14, pady=(12, 0))
        tk.Label(wheel_header, text="CILINDRO FÍSICO", bg=self.panel, fg=self.cyan, font=("Segoe UI", 10, "bold")).pack(side="left")

        self.canvas = tk.Canvas(wheel_card, width=470, height=470, bg=self.panel, highlightthickness=0, bd=0)
        self.canvas.pack(pady=(10, 10))

        # Esteira de Histórico (Últimos 14)
        history_card = tk.Frame(left, bg=self.panel, highlightbackground=self.border, highlightthickness=1)
        history_card.pack(fill="x")
        tk.Label(history_card, text="ÚLTIMOS RESULTADOS", bg=self.panel, fg=self.muted, font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=14, pady=(8, 0))
        
        self.canvas_history = tk.Canvas(history_card, width=470, height=50, bg=self.panel, highlightthickness=0, bd=0)
        self.canvas_history.pack(pady=(4, 10))

        # --- LADO DIREITO: DASHBOARD ESTATÍSTICO ---
        right = tk.Frame(content, bg=self.bg)
        right.pack(side="left", fill="both", expand=True)

        # 1. 4 KPI Cards 
        kpi_grid = tk.Frame(right, bg=self.bg)
        kpi_grid.pack(fill="x", pady=(0, 10))
        for c in range(4): kpi_grid.columnconfigure(c, weight=1)

        def _kpi_box(parent, col, title, color):
            box = tk.Frame(parent, bg=self.panel, highlightbackground=self.border, highlightthickness=1)
            box.grid(row=0, column=col, sticky="nsew", padx=(0 if col==0 else 4, 0 if col==3 else 4))
            tk.Label(box, text=title, bg=self.panel, fg=self.muted, font=("Segoe UI", 7, "bold")).pack(anchor="center", pady=(8, 2))
            lbl = tk.Label(box, text="0", bg=self.panel, fg=color, font=("Segoe UI", 16, "bold"))
            lbl.pack(anchor="center", pady=(0, 8))
            return lbl

        self.lbl_v_greens = _kpi_box(kpi_grid, 0, "GREENS", self.green)
        self.lbl_v_reds   = _kpi_box(kpi_grid, 1, "REDS", self.red)
        self.lbl_v_assert = _kpi_box(kpi_grid, 2, "ASSERTIVIDADE", self.cyan)
        self.lbl_v_lucro  = _kpi_box(kpi_grid, 3, "LUCRO VIRTUAL", self.amber)

        # 2. CAIXA DE OPERAÇÃO UNIFICADA (Sinal + Gale)
        self.op_card = tk.Frame(right, bg=self.panel2, highlightbackground=self.border, highlightthickness=1)
        self.op_card.pack(fill="x", pady=(0, 10), ipadx=10, ipady=15)
        
        self.lbl_op_title = tk.Label(self.op_card, text="STATUS DA OPERAÇÃO", bg=self.panel2, fg=self.muted, font=("Segoe UI", 9, "bold"))
        self.lbl_op_title.pack(pady=(0, 5))
        
        self.lbl_op_alvo = tk.Label(self.op_card, text="📡 Escaneando Cilindro...", bg=self.panel2, fg=self.text, font=("Segoe UI", 14, "bold"))
        self.lbl_op_alvo.pack(pady=(0, 5))

        self.lbl_op_desc = tk.Label(self.op_card, text="Aguardando quebra de assimetria institucional.", bg=self.panel2, fg=self.muted, font=("Segoe UI", 10))
        self.lbl_op_desc.pack()

        # 3. GRID DO RAIO-X (3x2) — caixas compactas e simétricas
        stats_card = tk.Frame(right, bg=self.panel, highlightbackground=self.border, highlightthickness=1)
        stats_card.pack(fill="x", pady=(0, 10))
        tk.Label(stats_card, text="RAIO-X DA MESA", bg=self.panel, fg=self.cyan, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=14, pady=(12, 8))

        stats_grid = tk.Frame(stats_card, bg=self.panel)
        stats_grid.pack(fill="x", padx=14, pady=(0, 12))
        for c in range(3): stats_grid.columnconfigure(c, weight=1, uniform="raiox")
        for r in range(2): stats_grid.rowconfigure(r, uniform="raiox")

        def _stat_box(parent, row, col, title, attr, color):
            box = tk.Frame(parent, bg=self.panel2, highlightbackground=self.border, highlightthickness=1)
            box.grid(row=row, column=col, sticky="nsew", padx=4, pady=4)
            tk.Label(box, text=title, bg=self.panel2, fg=self.muted, font=("Segoe UI", 7, "bold")).pack(anchor="w", padx=8, pady=(6, 2))
            lbl = tk.Label(box, text="--", bg=self.panel2, fg=color, font=("Segoe UI", 9, "bold"),
                           justify="left", anchor="nw", height=4)
            lbl.pack(fill="x", padx=8, pady=(0, 6))
            setattr(self, attr, lbl)

        _stat_box(stats_grid, 0, 0, "🔥 PLENOS", "lbl_hot_nums", self.amber)
        _stat_box(stats_grid, 0, 1, "🌀 TERMINAIS", "lbl_terminals", self.cyan)
        _stat_box(stats_grid, 0, 2, "🎨 CORES", "lbl_cores", self.text)
        
        _stat_box(stats_grid, 1, 0, "⚖️ PARIDADE", "lbl_paridade", self.text)
        _stat_box(stats_grid, 1, 1, "📏 DÚZIAS", "lbl_duzias", self.text)
        _stat_box(stats_grid, 1, 2, "📊 COLUNAS", "lbl_colunas", self.text)

        # 4. GRÁFICO DE LUCRO REAL-TIME (Colocado na ordem correta, acima do lab)
        profit_card = tk.Frame(right, bg=self.panel, highlightbackground=self.border, highlightthickness=1)
        profit_card.pack(fill="x", pady=(0, 10))
        tk.Label(profit_card, text="📈 CURVA DE LUCRO ", bg=self.panel, fg=self.cyan, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=14, pady=(10, 6))
        
        self.canvas_profit = tk.Canvas(profit_card, width=470, height=100, bg="#0A0F17", highlightthickness=0, bd=0)
        self.canvas_profit.pack(pady=(0, 10))

        # 5. HISTÓRICO DE ENTRADAS DA SESSÃO (auditoria ao vivo)
        entradas_card = tk.Frame(right, bg=self.panel, highlightbackground=self.border, highlightthickness=1)
        entradas_card.pack(fill="x", pady=(0, 10))

        entradas_header = tk.Frame(entradas_card, bg=self.panel)
        entradas_header.pack(fill="x", padx=14, pady=(10, 6))
        tk.Label(entradas_header, text="HISTÓRICO DE ENTRADAS DA SESSÃO", bg=self.panel, fg=self.cyan,
                 font=("Segoe UI", 9, "bold")).pack(side="left")
        self.lbl_winrate_gale = tk.Label(entradas_header, text="DIRETA 0 • G1 0 • G2 0", bg=self.panel,
                                         fg=self.muted, font=("Consolas", 8, "bold"))
        self.lbl_winrate_gale.pack(side="right")

        entradas_body = tk.Frame(entradas_card, bg=self.panel3, highlightbackground=self.border, highlightthickness=1)
        entradas_body.pack(fill="x", padx=14, pady=(0, 12))

        scroll_entradas = tk.Scrollbar(entradas_body, orient="vertical", bg=self.panel3, troughcolor=self.panel3,
                                       activebackground=self.cyan, bd=0, highlightthickness=0)
        scroll_entradas.pack(side="right", fill="y")

        self.listbox_entradas_sessao = tk.Listbox(
            entradas_body, bg=self.panel3, fg=self.text, font=("Consolas", 8, "bold"),
            bd=0, highlightthickness=0, activestyle="none", selectbackground="#123E42",
            selectforeground=self.text, yscrollcommand=scroll_entradas.set, height=6
        )
        self.listbox_entradas_sessao.pack(side="left", fill="both", expand=True, padx=4, pady=4)
        scroll_entradas.config(command=self.listbox_entradas_sessao.yview)

        # 6. LABORATÓRIO QUANT (AUTÔNOMO)
        quant_card = tk.Frame(right, bg=self.panel, highlightbackground=self.border, highlightthickness=1)
        quant_card.pack(fill="both", expand=True) # Este sim fica com expand=True para ocupar o restinho do rodapé
        tk.Label(quant_card, text="06 • LABORATÓRIO QUANT (AUTÔNOMO)", bg=self.panel, fg=self.purple, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=14, pady=(10, 6))
        
        quant_body = tk.Frame(quant_card, bg=self.panel)
        quant_body.pack(fill="both", expand=True, padx=14, pady=(0, 10))
        
        # Listbox de padrões
        list_frame = tk.Frame(quant_body, bg=self.panel3, highlightbackground=self.border, highlightthickness=1)
        list_frame.pack(fill="both", expand=True)
        
        scroll_quant = tk.Scrollbar(list_frame, orient="vertical", bg=self.panel3, troughcolor=self.panel3,
                                   activebackground=self.cyan, bd=0, highlightthickness=0)
        scroll_quant.pack(side="right", fill="y")
        
        self.listbox_quant = tk.Listbox(
            list_frame, bg=self.panel3, fg=self.green, font=("Consolas", 8, "bold"),
            bd=0, highlightthickness=0, activestyle="none", selectbackground="#2D1B4E",
            selectforeground=self.text, yscrollcommand=scroll_quant.set, height=6
        )
        self.listbox_quant.pack(side="left", fill="both", expand=True, padx=4, pady=4)
        scroll_quant.config(command=self.listbox_quant.yview)
        
        # Botão de aplicação
        self.btn_aplicar_quant = tk.Button(quant_body, text="⚡ APLICAR AO ROBÔ", command=self.aplicar_padrao_selecionado,
                                           bg=self.cyan, fg="#041015", activebackground="#67E8F9",
                                           activeforeground="#041015", relief="flat", bd=0, cursor="hand2",
                                           font=("Segoe UI", 9, "bold"), padx=15, pady=6)
        self.btn_aplicar_quant.pack(fill="x", pady=(8, 0))

        # Estado para o gráfico de lucro
        self.historico_lucro_chart = [0.0]

        # Armazenamento temporário para backtest
        self.mesa_info_temp = {}

        # Armazenamento para padrões minerados
        self.padroes_minerados = []

        # Assinaturas de estado para evitar redesenhos redundantes (gerenciador de memória do canvas)
        self._assinatura_cilindro = None
        self._assinatura_grafico = None
        self._assinatura_quant = None

        self.visivel = True
        self.top.update_idletasks()
        self._desenhar_cilindro([], [])
        self._desenhar_historico([])
        self._desenhar_grafico_lucro()
        self._animar_dot_status()

    def esconder(self):
        self.visivel = False
        self.top.withdraw()

    def mostrar(self):
        self.visivel = True
        self.top.deiconify()

    def _animar_dot_status(self):
        """Anima o indicador de status piscando"""
        cores = [self.neon_green, self.glow_cyan, self.amber, self.neon_red]
        idx = 0
        
        def _trocar_dot():
            nonlocal idx
            if not self.visivel:
                return
            try:
                if not self.top.winfo_exists():
                    return
                self.status_dot.config(fg=cores[idx % len(cores)])
                idx += 1
                self.top.after(800, _trocar_dot)
            except (tk.TclError, AttributeError):
                return
        
        _trocar_dot()

    def adicionar_entrada_historico(self, estrategia, numero, resultado, gale, valor):
        """Insere uma entrada liquidada (GREEN/RED) no topo do histórico da sessão."""
        try:
            hora = datetime.now().strftime('%H:%M:%S')
            nivel = "DIRETA" if not gale else f"G{gale}"
            resultado_fmt = str(resultado).upper()
            valor_fmt = f"{float(valor):+.2f}".replace("+", "+R$ ").replace("-", "-R$ ")
            linha = f"[{hora}] {estrategia} | Num: {numero} | {nivel} | {resultado_fmt} ({valor_fmt})"

            self.listbox_entradas_sessao.insert(0, linha)
            cor = self.green if resultado_fmt == "GREEN" else self.red
            self.listbox_entradas_sessao.itemconfig(0, foreground=cor)

            excedente = self.listbox_entradas_sessao.size() - MAX_ENTRADAS_HISTORICO
            if excedente > 0:
                self.listbox_entradas_sessao.delete(MAX_ENTRADAS_HISTORICO, tk.END)
        except Exception as e:
            logging.error(f"Erro ao inserir entrada no histórico da sessão: {e}")

    def atualizar_metricas_gale(self, greens_por_gale):
        """Exibe a eficácia de cada nível de gale (entrada direta, G1, G2...)."""
        try:
            niveis = sorted(greens_por_gale.keys())
            partes = []
            for nivel in niveis:
                rotulo = "DIRETA" if nivel == 0 else f"G{nivel}"
                partes.append(f"{rotulo} {greens_por_gale[nivel]}")
            self.lbl_winrate_gale.config(text=" • ".join(partes) if partes else "SEM GREENS")
        except Exception as e:
            logging.error(f"Erro ao atualizar métricas por gale: {e}")

    def limpar_historico_entradas(self):
        try:
            self.listbox_entradas_sessao.delete(0, tk.END)
            self.historico_lucro_chart = [0.0]
            self._assinatura_grafico = None
            self._desenhar_grafico_lucro()
        except Exception as e:
            logging.error(f"Erro ao limpar histórico de entradas: {e}")

    def _desenhar_historico(self, historico):
        self.canvas_history.delete("all")
        if not historico:
            self.canvas_history.create_text(235, 25, text="📭 SEM DADOS AINDA", 
                                           fill=self.muted, font=("Segoe UI", 8, "bold"))
            return
            
        ultimos = historico[-14:] 
        raio = 14
        espaco = 32
        inicio_x = 235 - ((len(ultimos) * espaco) / 2) + 16
        
        for i, num in enumerate(ultimos):
            cx = inicio_x + (i * espaco)
            cy = 25
            
            if num == 0: 
                cor_bg, cor_fg = self.neon_green, "#000000"
            elif num in VERMELHOS: 
                cor_bg, cor_fg = self.neon_red, "#FFFFFF"
            else: 
                cor_bg, cor_fg = "#1F293B", "#FFFFFF"
            
            borda = self.glow_cyan if i == len(ultimos)-1 else self.border
            espessura = 3 if i == len(ultimos)-1 else 1
            
            if espessura > 2:
                self.canvas_history.create_oval(cx-raio-4, cy-raio-4, cx+raio+4, cy+raio+4, 
                                               outline=borda, width=2, stipple="gray50")
            
            self.canvas_history.create_oval(cx-raio, cy-raio, cx+raio, cy+raio, 
                                           fill=cor_bg, outline=borda, width=espessura)
            self.canvas_history.create_text(cx, cy, text=str(num), fill=cor_fg, 
                                           font=("Segoe UI", 10, "bold"))

    def _desenhar_grafico_lucro(self):
        assinatura = (len(self.historico_lucro_chart),
                      round(self.historico_lucro_chart[-1], 2) if self.historico_lucro_chart else None)
        if assinatura == self._assinatura_grafico:
            return
        self._assinatura_grafico = assinatura

        self.canvas_profit.delete("all")
        
        if not self.historico_lucro_chart or len(self.historico_lucro_chart) < 2:
            self.canvas_profit.create_text(235, 50, text="📊 AGUARDANDO DADOS DE LUCRO", 
                                          fill=self.muted, font=("Segoe UI", 8, "bold"))
            return
        
        canvas_width = 470
        canvas_height = 100
        padding = 10
        
        lucro_atual = self.historico_lucro_chart[-1]
        cor_linha = self.neon_green if lucro_atual >= 0 else self.neon_red
        
        min_val = min(self.historico_lucro_chart)
        max_val = max(self.historico_lucro_chart)
        
        if max_val == min_val:
            max_val += 1
            min_val -= 1
        
        range_val = max_val - min_val
        
        if min_val <= 0 <= max_val:
            zero_y = canvas_height - padding - ((0 - min_val) / range_val) * (canvas_height - 2 * padding)
            self.canvas_profit.create_line(padding, zero_y, canvas_width - padding, zero_y, 
                                          fill=self.border, width=1, dash=(2, 2))
        
        pontos = []
        num_pontos = len(self.historico_lucro_chart)
        
        for i, valor in enumerate(self.historico_lucro_chart):
            x = padding + (i / (num_pontos - 1)) * (canvas_width - 2 * padding)
            y = canvas_height - padding - ((valor - min_val) / range_val) * (canvas_height - 2 * padding)
            pontos.append((x, y))
        
        if len(pontos) >= 2:
            # Sombra da linha
            shadow_points = [(x, y+2) for x, y in pontos]
            self.canvas_profit.create_line(shadow_points, fill="#000000", width=4, smooth=True)
            
            self.canvas_profit.create_line(pontos, fill=cor_linha, width=3, smooth=True)
            self.canvas_profit.create_line(pontos, fill=cor_linha, width=1, smooth=True, stipple="gray25")
            
            ultimo_x, ultimo_y = pontos[-1]
            for r in range(3):
                self.canvas_profit.create_oval(ultimo_x-r*3, ultimo_y-r*3, 
                                              ultimo_x+r*3, ultimo_y+r*3, 
                                              fill="", outline=cor_linha, width=1, stipple="gray50")
            self.canvas_profit.create_oval(ultimo_x-4, ultimo_y-4, ultimo_x+4, ultimo_y+4, 
                                          fill=cor_linha, outline="")
            
            self.canvas_profit.create_text(ultimo_x + 10, ultimo_y, text=f"{lucro_atual:+.2f}", 
                                          fill=cor_linha, font=("Segoe UI", 8, "bold"), anchor="w")
        # Determinar cor baseada no lucro atual
        lucro_atual = self.historico_lucro_chart[-1]
        cor_linha = self.green if lucro_atual >= 0 else self.red
        
        # Calcular escala
        min_val = min(self.historico_lucro_chart)
        max_val = max(self.historico_lucro_chart)
        
        if max_val == min_val:
            max_val += 1
            min_val -= 1
        
        range_val = max_val - min_val
        
        # Desenhar linha zero se estiver no range
        if min_val <= 0 <= max_val:
            zero_y = canvas_height - padding - ((0 - min_val) / range_val) * (canvas_height - 2 * padding)
            self.canvas_profit.create_line(padding, zero_y, canvas_width - padding, zero_y, fill=self.border, width=1, dash=(2, 2))
        
        # Calcular pontos
        pontos = []
        num_pontos = len(self.historico_lucro_chart)
        
        for i, valor in enumerate(self.historico_lucro_chart):
            x = padding + (i / (num_pontos - 1)) * (canvas_width - 2 * padding)
            y = canvas_height - padding - ((valor - min_val) / range_val) * (canvas_height - 2 * padding)
            pontos.append((x, y))
        
        # Desenhar linha
        if len(pontos) >= 2:
            self.canvas_profit.create_line(pontos, fill=cor_linha, width=2, smooth=True)
            
            # Desenhar ponto final
            ultimo_x, ultimo_y = pontos[-1]
            self.canvas_profit.create_oval(ultimo_x-3, ultimo_y-3, ultimo_x+3, ultimo_y+3, fill=cor_linha, outline="")
            
            # Desenhar valor atual
            self.canvas_profit.create_text(ultimo_x + 10, ultimo_y, text=f"{lucro_atual:+.2f}", fill=cor_linha, font=("Segoe UI", 8, "bold"), anchor="w")

    def _desenhar_cilindro(self, historico, alvos_expandidos):
        try: janela = int(self.app.ent_amostra.get().strip())
        except Exception: janela = 60

        assinatura = (janela, len(historico), historico[-1] if historico else None,
                      tuple(sorted(alvos_expandidos or [])))
        if assinatura == self._assinatura_cilindro:
            return
        self._assinatura_cilindro = assinatura

        self.canvas.delete("all")
        cx, cy = 235, 235
        r_out, r_in, r_heat = 205, 158, 98
        passo = 360 / 37
        
        ultimos_amostra = historico[-janela:] if historico else []
        contagem = {n: ultimos_amostra.count(n) for n in range(37)}

        offset_topo = 90 + (passo / 2)

        for i, numero in enumerate(RODA_EUROPEIA):
            angulo_inicio = offset_topo - (i * passo)
            
            if numero == 0: 
                cor_bg = self.neon_green
            elif numero in VERMELHOS: 
                cor_bg = self.neon_red
            else: 
                cor_bg = "#1a1a1a"

            is_alvo = alvos_expandidos and str(numero) in alvos_expandidos
            cor_borda = self.glow_cyan if is_alvo else "#1a1a1a"
            largura_borda = 3 if is_alvo else 1

            self.canvas.create_arc(cx-r_out, cy-r_out, cx+r_out, cy+r_out, 
                                  start=angulo_inicio, extent=-passo, 
                                  fill=cor_bg, outline=cor_borda, width=largura_borda)
            
            hits = contagem.get(numero, 0)
            cor_heat = self.panel2 if hits == 0 else "#0055ff" if hits == 1 else self.amber if hits == 2 else self.neon_red
            self.canvas.create_arc(cx-r_in, cy-r_in, cx+r_in, cy+r_in, 
                                  start=angulo_inicio, extent=-passo, 
                                  fill=cor_heat, outline=self.panel, width=1)
            
            mid_angle = 90 - (i * passo)
            rad = math.radians(mid_angle)
            tx = cx + 181 * math.cos(rad)
            ty = cy - 181 * math.sin(rad)
            
# Força o texto de todos os números a ficarem sempre visíveis e em destaque
            if is_alvo:
                cor_texto = self.glow_cyan
                fonte = ("Segoe UI", 10, "bold")
            elif hits >= 3:
                cor_texto = self.amber
                fonte = ("Segoe UI", 10, "bold")
            else:
                cor_texto = "#ffffff"  # Branco puro para nunca sumir
                fonte = ("Segoe UI", 8, "bold")
            
            self.canvas.create_text(tx, ty, text=str(numero), fill=cor_texto, font=fonte)

        self.canvas.create_oval(cx-r_heat, cy-r_heat, cx+r_heat, cy+r_heat, 
                               fill=self.panel, outline=self.glow_cyan, width=2)
        
        if historico:
            ult = historico[-1]
            if ult in RODA_EUROPEIA:
                idx_ult = RODA_EUROPEIA.index(ult)
                mid_angle_bola = 90 - (idx_ult * passo)
                rad_bola = math.radians(mid_angle_bola)
                bx = cx + 137 * math.cos(rad_bola)
                by = cy - 137 * math.sin(rad_bola)
                
                # Efeito de GLOW na bola
                for r in range(3):
                    self.canvas.create_oval(bx-r*6, by-r*6, bx+r*6, by+r*6, 
                                           fill="", outline=self.glow_cyan, width=1, stipple="gray50")
                
                self.canvas.create_oval(bx-6, by-6, bx+6, by+6, fill="#000000", outline="")
                self.canvas.create_oval(bx-5, by-5, bx+5, by+5, fill=self.glow_cyan, outline="#FFFFFF", width=2)
                self.canvas.create_oval(bx-2, by-4, bx+1, by-1, fill="#FFFFFF", outline="", stipple="gray25")

            self.canvas.create_text(cx, cy-15, text="⚡ ÚLTIMO", fill=self.glow_cyan, 
                                   font=("Segoe UI", 8, "bold"))
            
            if ult == 0:
                cor_ult = self.neon_green
            elif ult in VERMELHOS:
                cor_ult = self.neon_red
            else:
                cor_ult = "#ffffff"
                
            self.canvas.create_text(cx, cy+10, text=str(ult), fill=cor_ult, 
                                   font=("Segoe UI", 28, "bold"))
        else:
            self.canvas.create_text(cx, cy, text="🎰 AGUARDANDO\n GIROS", 
                                   fill=self.muted, font=("Segoe UI", 10, "bold"), justify="center")

    @staticmethod
    def expandir_alvos(alvos):
        """Converte tags de setor/terminal em números plenos, preservando tags externas."""
        expandidos = []
        for alvo in alvos:
            alvo = str(alvo)
            if alvo in SETORES_FISICOS:
                expandidos.extend(str(n) for n in sorted(SETORES_FISICOS[alvo]))
            elif alvo in TERMINAIS_MAP:
                expandidos.extend(TERMINAIS_MAP[alvo])
            else:
                expandidos.append(alvo)
        return list(dict.fromkeys(expandidos))

    @staticmethod
    def _vizinhos_roda(numero, raio=2):
        """Devolve o número e seus vizinhos físicos no cilindro europeu."""
        try:
            pos = RODA_EUROPEIA.index(int(numero))
        except ValueError:
            return [str(numero)]
        total = len(RODA_EUROPEIA)
        return [str(RODA_EUROPEIA[(pos + d) % total]) for d in range(-raio, raio + 1)]

    def _gerar_catalogo_padroes(self, historico_nums):
        """Monta o universo de hipóteses cruzando todas as categorias + números plenos."""
        catalogo = []
        familias = [
            ("DÚZIA", ["D1", "D2", "D3"], {"D1": "1ª Dúzia", "D2": "2ª Dúzia", "D3": "3ª Dúzia"}),
            ("COLUNA", ["C1", "C2", "C3"], {"C1": "Coluna 1", "C2": "Coluna 2", "C3": "Coluna 3"}),
            ("COR", ["R", "B"], {"R": "Vermelho", "B": "Preto"}),
            ("PARIDADE", ["P", "O"], {"P": "Par", "O": "Ímpar"}),
            ("METADE", ["L", "H"], {"L": "Baixas 1-18", "H": "Altas 19-36"}),
            ("SETOR", ["P1", "P2", "P3"], {"P1": "Setor 1", "P2": "Setor 2", "P3": "Setor 3"}),
        ]

        for familia, tags, rotulos in familias:
            for tag in tags:
                complementares = [t for t in tags if t != tag]
                for repeticoes in (2, 3):
                    gatilho = [tag] * repeticoes
                    catalogo.append((
                        gatilho, complementares,
                        f"Quebra {repeticoes}x {rotulos[tag]} ➔ {'/'.join(rotulos[c] for c in complementares)}",
                        familia
                    ))
                    catalogo.append((
                        gatilho, [tag],
                        f"Tendência {repeticoes}x {rotulos[tag]} ➔ {rotulos[tag]}",
                        familia
                    ))

        # TERMINAIS: repetição, puxada de vizinhos numéricos e espelho
        for d in range(10):
            tag = f"T{d}"
            vizinhos = [f"T{(d + 1) % 10}", f"T{(d - 1) % 10}"]
            catalogo.append(([tag], [tag], f"Puxada Terminal {d} ➔ T{d}", "TERMINAL"))
            catalogo.append(([tag], vizinhos, f"Terminal {d} ➔ vizinhos {vizinhos[0]}/{vizinhos[1]}", "TERMINAL"))
            catalogo.append(([tag, tag], [tag] + vizinhos, f"Terminal {d} 2x ➔ cluster T{d}", "TERMINAL"))

        # NÚMEROS PLENOS: hipóteses geradas a partir dos números quentes da amostra
        amostra = historico_nums[-120:]
        contagem = {}
        for n in amostra:
            contagem[n] = contagem.get(n, 0) + 1
        quentes = [n for n, c in sorted(contagem.items(), key=lambda x: x[1], reverse=True)[:6] if c >= 2]

        for num in quentes:
            catalogo.append((
                [str(num)], [str(num)],
                f"Repetição do Pleno {num}", "PLENO"
            ))
            catalogo.append((
                [str(num)], self._vizinhos_roda(num, raio=2),
                f"Pleno {num} ➔ vizinhos físicos (5 fichas)", "PLENO"
            ))
            catalogo.append((
                [str(num)], [f"T{num % 10}"],
                f"Pleno {num} ➔ Terminal {num % 10}", "PLENO"
            ))

        return catalogo

    @staticmethod
    def _simular_padrao(historico_tags, gatilho_seq, alvos_expandidos, max_gales):
        """Backtest de um padrão: devolve greens, reds e o pior drawdown de reds seguidos."""
        greens = 0
        reds = 0
        max_drawdown = 0
        drawdown_atual = 0
        alvos = set(alvos_expandidos)

        tamanho = len(gatilho_seq)
        i = tamanho
        total = len(historico_tags)

        while i < total:
            sub_hist = historico_tags[i - tamanho:i]
            if all(g in sub_hist[idx] for idx, g in enumerate(gatilho_seq)):
                acertou = False
                gale_usado = 0
                for g in range(max_gales + 1):
                    if i + g >= total:
                        break
                    gale_usado = g
                    if alvos.intersection(historico_tags[i + g]):
                        acertou = True
                        break

                if acertou:
                    greens += 1
                    drawdown_atual = 0
                else:
                    reds += 1
                    drawdown_atual += 1
                    max_drawdown = max(max_drawdown, drawdown_atual)

                i += (gale_usado + 1)
            else:
                i += 1

        return greens, reds, max_drawdown

    @staticmethod
    def _numeros_cobertos(alvos_expandidos):
        """Quantidade real de casas da mesa cobertas pelos alvos (risco efetivo da entrada)."""
        if not NUMEROS_POR_TAG:
            for n in range(37):
                for tag in classificar_numero(n):
                    NUMEROS_POR_TAG.setdefault(tag, set()).add(n)
        casas = set()
        for alvo in alvos_expandidos:
            casas.update(NUMEROS_POR_TAG.get(str(alvo), set()))
        return len(casas)

    @staticmethod
    def _limite_inferior_wilson(greens, total):
        """Limite inferior de Wilson (95%): pune assertividade alta com amostra pequena."""
        if total <= 0:
            return 0.0
        z = 1.96
        p = greens / total
        denominador = 1 + (z ** 2) / total
        centro = p + (z ** 2) / (2 * total)
        margem = z * math.sqrt((p * (1 - p) + (z ** 2) / (4 * total)) / total)
        return max(0.0, (centro - margem) / denominador) * 100

    def _minerar_padroes_ao_vivo(self, historico_nums):
        """Minera assimetrias cruzando todas as categorias e filtra apenas as de alta probabilidade."""
        if len(historico_nums) < 20:
            return []

        historico_tags = [classificar_numero(num) for num in historico_nums]
        max_gales = 2
        candidatos = []

        for gatilho_seq, alvos_seq, nome_padrao, familia in self._gerar_catalogo_padroes(historico_nums):
            alvos_expandidos = self.expandir_alvos(alvos_seq)
            cobertura = len(alvos_expandidos)
            numeros_cobertos = self._numeros_cobertos(alvos_expandidos)
            if numeros_cobertos > 24:  # descarta hipóteses que cobrem quase toda a mesa
                continue

            greens, reds, max_drawdown = self._simular_padrao(
                historico_tags, gatilho_seq, alvos_expandidos, max_gales
            )
            operacoes = greens + reds
            # Plenos disparam pouco: exigem amostra menor, mas o filtro de Wilson segue punindo
            if operacoes < (4 if familia == "PLENO" else 6):
                continue

            assertividade = greens / operacoes * 100
            confianca = self._limite_inferior_wilson(greens, operacoes)
            # Assertividade esperada só pelo acaso, dado o nº de casas e os gales disponíveis
            aleatorio = (1 - ((37 - numeros_cobertos) / 37) ** (max_gales + 1)) * 100
            # Vantagem sobre o acaso; a versão conservadora usa o piso de Wilson
            vantagem = assertividade - aleatorio
            vantagem_conf = confianca - aleatorio
            score = vantagem_conf - (max_drawdown * 4)
            # Só interessa assimetria real: cobrir meia mesa com gales não é edge
            if vantagem < 5 or vantagem_conf <= 0:
                continue

            candidatos.append({
                "nome": nome_padrao,
                "familia": familia,
                "gatilho": list(gatilho_seq),
                "alvos": list(alvos_seq),
                "alvos_expandidos": alvos_expandidos,
                "cobertura": cobertura,
                "numeros_cobertos": numeros_cobertos,
                "greens": greens,
                "reds": reds,
                "total_entradas": operacoes,
                "assertividade": assertividade,
                "confianca": confianca,
                "aleatorio": aleatorio,
                "vantagem": vantagem,
                "vantagem_conf": vantagem_conf,
                "max_drawdown": max_drawdown,
                "score": score,
                "max_gales": max_gales
            })

        # Filtro de excelência com relaxamento progressivo (evita painel vazio em amostras curtas)
        for meta_assertividade, meta_drawdown in ((85, 1), (85, 2), (78, 2), (70, 3)):
            selecionados = [
                c for c in candidatos
                if c["assertividade"] >= meta_assertividade and c["max_drawdown"] <= meta_drawdown
            ]
            if selecionados:
                selecionados.sort(key=lambda x: x["score"], reverse=True)
                return selecionados[:12]

        return []

    def aplicar_padrao_selecionado(self):
        """Aplica o padrão selecionado ao robô principal"""
        selecao = self.listbox_quant.curselection()
        if not selecao:
            messagebox.showwarning("Aviso", "Selecione um padrão na lista para aplicar!")
            return
        
        idx = selecao[0]
        if idx >= len(self.padroes_minerados):
            return
        
        padrao = self.padroes_minerados[idx]
        
        try:
            alvos_expandidos = padrao.get("alvos_expandidos") or self.expandir_alvos(padrao["alvos"])
            max_gales = int(padrao.get("max_gales", 2))

            nova_est = {
                "nome": f"QUANT • {padrao['nome']}",
                "gatilho_str": " ".join(padrao["gatilho"]),
                "gatilho": padrao["gatilho"],
                "ausencia": False,
                "aposta_str": " ".join(alvos_expandidos),
                "alvos": alvos_expandidos,
                "max_gales": max_gales,
                "mults_gales": ["2x", "4x"][:max_gales] or ["2x"],
                "greens": 0,
                "reds": 0,
                "origem_quant": True
            }

            # Entra no topo da fila: padrões minerados têm prioridade sobre Sniper e Termo-Física
            self.app.estrategias.insert(0, nova_est)
            self.app.salvar_config()
            self.app.atualizar_listbox_estrategias()
            self.app.registrar_log(
                f"⚡ SINAL QUANT aplicado ao robô: {padrao['nome']} "
                f"({padrao['assertividade']:.0f}% | edge +{padrao.get('vantagem', 0):.0f}% | "
                f"{padrao.get('numeros_cobertos', padrao['cobertura'])} casas | MaxReds {padrao['max_drawdown']})"
            )

            messagebox.showinfo("Sucesso", f"Estratégia '{padrao['nome']}' aplicada no topo da fila do robô!")
            
        except Exception as e:
            logging.error(f"Erro ao aplicar padrão: {e}")
            messagebox.showerror("Erro", f"Erro ao aplicar padrão: {str(e)}")

    def atualizar_dados_ao_vivo(self, mesa_info, sinal_ativo=None):
        if not self.visivel: return

        historico = mesa_info.get("historico_numeros_brutos", [])

        try: janela = int(self.app.ent_amostra.get().strip())
        except Exception: janela = 60
        
        # 1. KPI CARDS ATUALIZADOS SEM SOBREPOSIÇÃO
        t = self.app.greens + self.app.reds
        a = (self.app.greens / t * 100) if t > 0 else 0
        sinal_lucro = "+" if self.app.lucro_virtual >= 0 else "-"
        
        self.lbl_v_greens.config(text=str(self.app.greens))
        self.lbl_v_reds.config(text=str(self.app.reds))
        self.lbl_v_assert.config(text=f"{a:.1f}%")
        self.lbl_v_lucro.config(text=f"{sinal_lucro}R$ {abs(self.app.lucro_virtual):.2f}")

        # 2. CILINDRO E HISTÓRICO
        # Série do gráfico cresce apenas quando o P&L muda, com janela fixa (anti memory leak)
        if not self.historico_lucro_chart or self.historico_lucro_chart[-1] != self.app.lucro_virtual:
            self.historico_lucro_chart.append(self.app.lucro_virtual)
            if len(self.historico_lucro_chart) > MAX_PONTOS_GRAFICO:
                del self.historico_lucro_chart[:-MAX_PONTOS_GRAFICO]

        # Armazenar informações temporárias para backtest
        self.mesa_info_temp = {
            "historico_numeros_brutos": historico
        }
        alvos_expandidos = self.expandir_alvos(sinal_ativo["alvos"]) if sinal_ativo else []


        self._desenhar_cilindro(historico, alvos_expandidos)
        self._desenhar_historico(historico)
        self._desenhar_grafico_lucro()
        
        # 3. CAIXA DE OPERAÇÃO UNIFICADA
        if sinal_ativo:
            gale_atual = int(sinal_ativo.get("gale_atual", 0) or 0)
            tipo = "IA TERMO-FÍSICA" if sinal_ativo.get("is_termo") else ("MODO SNIPER" if "SNIPER" in sinal_ativo.get('gatilho_str', '') else "INTELIGÊNCIA G2")
            nome = sinal_ativo.get('nome', sinal_ativo.get('gatilho_str', 'Desconhecido'))
            
            if gale_atual > 0:
                mults = sinal_ativo.get("mults_gales") or ["2x", "4x", "8x", "16x", "32x", "64x"]
                idx = gale_atual - 1
                fator = mults[idx] if idx < len(mults) else f"{2 ** gale_atual}x"
                
                self.op_card.config(bg="#2D1A00", highlightbackground=self.amber)
                self.lbl_op_title.config(text=f"⚠️ ATENÇÃO: GALE {gale_atual} ATIVADO (FATOR {fator})", fg=self.amber, bg="#2D1A00")
                self.lbl_op_alvo.config(text=f"Alvo: {nome}", fg="#ffffff", bg="#2D1A00")
                self.lbl_op_desc.config(text=f"Cobertura em andamento: {len(alvos_expandidos)} fichas enviadas.\nAumentando risco para recuperação.", fg=self.amber, bg="#2D1A00")
            else:
                self.op_card.config(bg="#002D2D", highlightbackground=self.cyan)
                self.lbl_op_title.config(text=f"🟢 SINAL {tipo} DETECTADO", fg=self.cyan, bg="#002D2D")
                self.lbl_op_alvo.config(text=f"Alvo Principal: {nome}", fg="#ffffff", bg="#002D2D")
                self.lbl_op_desc.config(text=f"Cobertura: {len(alvos_expandidos)} fichas | Assertividade Base: {sinal_ativo.get('pct', 0.0):.1f}%", fg=self.cyan, bg="#002D2D")
        else:
            self.op_card.config(bg=self.panel2, highlightbackground=self.border)
            self.lbl_op_title.config(text="STATUS DA OPERAÇÃO", fg=self.muted, bg=self.panel2)
            self.lbl_op_alvo.config(text="📡 Escaneando Cilindro...", fg=self.text, bg=self.panel2)
            self.lbl_op_desc.config(text="Aguardando quebra de assimetria institucional.", fg=self.muted, bg=self.panel2)
            
        # 4. ESTATÍSTICAS DA MESA (COM QUEBRA DE LINHA \n PARA NÃO ESTICAR O GRID)
        if len(historico) > 0:
            ultimos_amostra = historico[-janela:]
            tot = len(ultimos_amostra)
            
            cont_nums = {n: ultimos_amostra.count(n) for n in set(ultimos_amostra)}
            top_nums = sorted(cont_nums.items(), key=lambda x: x[1], reverse=True)[:5]
            str_nums = "\n".join([f"{n} ({c}x)" for n, c in top_nums]) if top_nums else "--"
            self.lbl_hot_nums.config(text=str_nums)
            
            cont_terms = {i: 0 for i in range(10)}
            for n in ultimos_amostra: cont_terms[n % 10] += 1
            top_terms = sorted(cont_terms.items(), key=lambda x: x[1], reverse=True)[:3]
            str_terms = "\n".join([f"Terminal {t} ({c}x)" for t, c in top_terms]) if top_terms else "--"
            self.lbl_terminals.config(text=str_terms)

            def calc_pct(count): return (count / tot * 100) if tot > 0 else 0
            
            r = sum(1 for n in ultimos_amostra if n in VERMELHOS)
            b = sum(1 for n in ultimos_amostra if n not in VERMELHOS and n != 0)
            z = sum(1 for n in ultimos_amostra if n == 0)
            self.lbl_cores.config(text=f"🔴 Vermelho: {calc_pct(r):.0f}%\n⚫ Preto: {calc_pct(b):.0f}%\n🟢 Zero: {calc_pct(z):.0f}%")

            d1 = sum(1 for n in ultimos_amostra if 1 <= n <= 12)
            d2 = sum(1 for n in ultimos_amostra if 13 <= n <= 24)
            d3 = sum(1 for n in ultimos_amostra if 25 <= n <= 36)
            self.lbl_duzias.config(text=f"1ª Dúzia: {calc_pct(d1):.0f}%\n2ª Dúzia: {calc_pct(d2):.0f}%\n3ª Dúzia: {calc_pct(d3):.0f}%")

            c1 = sum(1 for n in ultimos_amostra if n != 0 and n % 3 == 1)
            c2 = sum(1 for n in ultimos_amostra if n != 0 and n % 3 == 2)
            c3 = sum(1 for n in ultimos_amostra if n != 0 and n % 3 == 0)
            self.lbl_colunas.config(text=f"Coluna 1: {calc_pct(c1):.0f}%\nColuna 2: {calc_pct(c2):.0f}%\nColuna 3: {calc_pct(c3):.0f}%")

            par = sum(1 for n in ultimos_amostra if n != 0 and n % 2 == 0)
            impar = sum(1 for n in ultimos_amostra if n != 0 and n % 2 != 0)
            self.lbl_paridade.config(text=f"Par: {calc_pct(par):.0f}%\nÍmpar: {calc_pct(impar):.0f}%")

        # 5. LABORATÓRIO QUANT AUTÔNOMO (remineramos apenas quando a amostra muda)
        assinatura_quant = (len(historico), historico[-1] if historico else None)
        if assinatura_quant != self._assinatura_quant:
            self._assinatura_quant = assinatura_quant
            self.listbox_quant.delete(0, tk.END)
            if len(historico) < 20:
                self.padroes_minerados = []
                self.listbox_quant.insert(tk.END, f"⏳ Coletando base de dados... ({len(historico)}/20 giros)")
            else:
                padroes = self._minerar_padroes_ao_vivo(historico)
                self.padroes_minerados = padroes
                if not padroes:
                    self.listbox_quant.insert(tk.END, "🔍 Escaneando... Nenhuma assimetria de alta probabilidade no momento.")
                else:
                    for p in padroes:
                        self.listbox_quant.insert(
                            tk.END,
                            f"[{p['assertividade']:.0f}% • edge +{p['vantagem']:.0f}%] {p['nome']} | "
                            f"G:{p['greens']} R:{p['reds']} | Casas:{p['numeros_cobertos']} | MaxReds:{p['max_drawdown']}"
                        )
                        cor = self.green if p["assertividade"] >= 85 else self.amber
                        self.listbox_quant.itemconfig(tk.END, foreground=cor)


def iniciar_chrome_automatico():
    caminhos_chrome = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expanduser(r"~\AppData\Local\Google\Chrome\Application\chrome.exe")
    ]
    
    chrome_path = None
    for p in caminhos_chrome:
        if os.path.exists(p):
            chrome_path = p
            break
            
    if not chrome_path:
        return False, "Google Chrome não encontrado nos caminhos padrões do Windows!"

    debug_dir = r"C:\ChromeDebug"
    os.makedirs(debug_dir, exist_ok=True)

    cmd = [
        chrome_path,
        "--remote-debugging-port=9222",
        f"--user-data-dir={debug_dir}"
    ]
    
    try:
        subprocess.Popen(cmd)
        time.sleep(3) 
        return True, "Chrome iniciado com sucesso na porta 9222!"
    except Exception as e:
        return False, f"Erro ao disparar o Chrome: {e}"

def executar_aposta_real(page: Any, aposta_str: str, qtd_cliques: int = 1) -> bool:
    tokens = aposta_str.replace(",", " ").split()
    alvos_finais = []
    
    for t in tokens:
        if t in SETORES_FISICOS:
            alvos_finais.extend([str(n) for n in SETORES_FISICOS[t]])
        elif t in TERMINAIS_MAP:
            alvos_finais.extend(TERMINAIS_MAP[t])
        else:
            alvos_finais.append(t)

    digitos = [a for a in alvos_finais if a.isdigit()]
    outros = [a for a in alvos_finais if not a.isdigit()]

    js_mapping = {
        "R": '[data-automation-locator="betPlace.spots50x50-red"]',
        "B": '[data-automation-locator="betPlace.spots50x50-black"]',
        "D1": '[data-automation-locator="betPlace.dozen-1st12"]',
        "D2": '[data-automation-locator="betPlace.dozen-2nd12"]',
        "D3": '[data-automation-locator="betPlace.dozen-3rd12"]',
        "C1": '[data-automation-locator="betPlace.column-1"]',
        "C2": '[data-automation-locator="betPlace.column-2"]',
        "C3": '[data-automation-locator="betPlace.column-3"]',
        "P": '[data-automation-locator="betPlace.spots50x50-even"]',
        "O": '[data-automation-locator="betPlace.spots50x50-odd"]',
        "L": '[data-automation-locator="betPlace.spots50x50-1to18"]',
        "H": '[data-automation-locator="betPlace.spots50x50-19to36"]'
    }

    script_golden_injector = """([digitos, outros, mapa, cliques]) => {
        let interagiu = false;

        function simulateNativeClick(el) {
            if (!el) return;
            const rect = el.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0) return;
            const x = rect.left + rect.width / 2;
            const y = rect.top + rect.height / 2;

            const dot = document.createElement('div');
            dot.style.position = 'fixed';
            dot.style.left = (x - 8) + 'px';
            dot.style.top = (y - 8) + 'px';
            dot.style.width = '16px';
            dot.style.height = '16px';
            dot.style.backgroundColor = '#00ffff'; 
            dot.style.border = '2px solid white';
            dot.style.borderRadius = '50%';
            dot.style.pointerEvents = 'none';
            dot.style.zIndex = '2147483647';
            dot.style.boxShadow = '0 0 12px #00ffff';
            document.body.appendChild(dot);
            setTimeout(() => { dot.style.opacity = '0'; dot.style.transform = 'scale(3)'; setTimeout(() => dot.remove(), 500); }, 10);

            const events = ['pointerover', 'pointerenter', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'];
            events.forEach(e => {
                el.dispatchEvent(new MouseEvent(e, { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y }));
            });
        }

        function isSafe(el) {
            let curr = el;
            while (curr && curr !== document.body && curr !== document.documentElement) {
                let cls = typeof curr.className === 'string' ? curr.className.toLowerCase() : 
                        (curr.className && typeof curr.className.baseVal === 'string' ? curr.className.baseVal.toLowerCase() : "");
                let id = typeof curr.id === 'string' ? curr.id.toLowerCase() : "";
                let role = typeof curr.getAttribute === 'function' ? (curr.getAttribute('data-role') || "").toLowerCase() : "";
                
                if (cls.includes('racetrack') || id.includes('racetrack') || cls.includes('neighbour') ||
                    cls.includes('history') || cls.includes('recent') || cls.includes('statistic') || cls.includes('chat') ||
                    id.includes('history') || id.includes('recent') || role.includes('recent') || 
                    cls.includes('timer') || cls.includes('limit') || cls.includes('panel')) {
                    return false;
                }
                curr = curr.parentElement;
            }
            return true;
        }

        if (digitos && digitos.length > 0) {
            digitos.forEach(n => {
                let clicked = false;
                let selectors = [
                    `[data-automation-locator="betPlace.straight-${n}"]`,
                    `[data-automation-locator*="straight-${n}"]`
                ];
                
                for (let sel of selectors) {
                    let els = document.querySelectorAll(sel);
                    for (let el of els) {
                        if (isSafe(el)) {
                            for(let i = 0; i < cliques; i++){
                                simulateNativeClick(el);
                            }
                            interagiu = true;
                            clicked = true;
                            break;
                        }
                    }
                    if (clicked) break;
                }

                if (!clicked) {
                    let fallbacks = document.querySelectorAll(`[data-number="${n}"], [data-spot="${n}"]`);
                    for (let el of fallbacks) {
                        if (isSafe(el)) {
                            for(let i = 0; i < cliques; i++){
                                simulateNativeClick(el);
                            }
                            interagiu = true;
                            clicked = true;
                            break;
                        }
                    }
                }
            });
        }

        if (outros && outros.length > 0) {
            outros.forEach(tag => {
                let cssSelector = mapa[tag];
                if (cssSelector) {
                    let els = document.querySelectorAll(cssSelector);
                    for (let el of els) {
                        if (isSafe(el)) {
                            for(let i = 0; i < cliques; i++){
                                simulateNativeClick(el);
                            }
                            interagiu = true;
                            break; 
                        }
                    }
                }
            });
        }

        return interagiu;
    }"""

    time.sleep(1.5)

    try: 
        frames = list(page.frames)
    except Exception: 
        frames = [page]

    sucesso_geral = False
    for frame in [page] + frames:
        try:
            if frame != page and frame.is_detached():
                continue
            resultado = frame.evaluate(script_golden_injector, [digitos, outros, js_mapping, qtd_cliques])
            if resultado:
                sucesso_geral = True
                break
        except Exception as e:
            logging.error(f"Erro na injeção DOM: {e}")
            continue

    return sucesso_geral

def enviar_telegram_direto(bot_token, chat_id, mensagem):
    if not bot_token or not chat_id: 
        return False, "Token ou Chat ID estão in branco!"
    try:
        url = f"https://api.telegram.org/bot{bot_token.strip()}/sendMessage"
        data = urllib.parse.urlencode({"chat_id": chat_id.strip(), "text": mensagem, "parse_mode": "Markdown"}).encode('utf-8')
        req = urllib.request.Request(url, data=data)
        with urllib.request.urlopen(req, timeout=5) as response:
            if response.status == 200: 
                return True, "Mensagem enviada!"
            return False, f"Erro Telegram {response.status}"
    except Exception as e: 
        return False, f"Erro: {e}"

def classificar_numero(num):
    tags = [str(num)]
    if num == 0: 
        tags.extend(["T0", "P1"])
    else:
        if 1 <= num <= 12: tags.append("D1")
        elif 13 <= num <= 24: tags.append("D2")
        elif 25 <= num <= 36: tags.append("D3")
        if num % 3 == 1: tags.append("C1")
        elif num % 3 == 2: tags.append("C2")
        elif num % 3 == 0: tags.append("C3")
        tags.append("L" if 1 <= num <= 18 else "H")
        tags.append("P" if num % 2 == 0 else "O")
        tags.append("R" if num in VERMELHOS else "B")
        tags.append(f"T{num % 10}")

    for setor, numeros in SETORES_FISICOS.items():
        if num in numeros:
            tags.append(setor)
            break

    return tags

def verificar_gatilho(historico_rodadas, est):
    alvo_gatilho = est["gatilho"]
    is_ausencia = est.get("ausencia", False)
    
    if not is_ausencia:
        if not historico_rodadas:
            return False
        if len(alvo_gatilho) == 1:
            elemento_esperado = alvo_gatilho[0]
            if elemento_esperado == "N":
                return True
            return elemento_esperado in historico_rodadas[-1]
        
        tam_gatilho = len(alvo_gatilho)
        if len(historico_rodadas) < tam_gatilho: 
            return False
        sub_historico = historico_rodadas[-tam_gatilho:]
        for registro_rodada, elemento_esperado in zip(sub_historico, alvo_gatilho):
            if elemento_esperado == "N": 
                continue
            if elemento_esperado not in registro_rodada: 
                return False
        return True
    else:
        try:
            limite_ausencia = int(alvo_gatilho[1])
        except (ValueError, IndexError):
            limite_ausencia = 5
        
        tag_alvo = est["tag_ausencia"]
        contador = 0
        for rodada in reversed(historico_rodadas):
            if tag_alvo in rodada:
                break
            contador += 1
        return contador >= limite_ausencia

def extrair_ultimo_numero(page):
    seletores = [
        '[data-role="recent-number"]', '[class*="recent-number"]',
        '[class*="history-item"]', '[class*="history"] [class*="number"]',
        'div[class*="recentNumbers"] span', 'div[class*="recent_numbers"] div',
        '.roulette-history-item', '.recent-numbers__number', 'span[class*="number-text"]',
        '[class*="historyList"] [class*="number"]', '[class*="resultsList"] div',
        'ul[class*="history"] li', 'div[class*="stat-number"]', 'span[class*="stat-value"]'
    ]
    try: 
        frames_atuais = list(page.frames)
    except Exception: 
        frames_atuais = []
    
    for frame in [page] + frames_atuais:
        try:
            if frame != page and frame.is_detached(): 
                continue
            for seletor in seletores:
                for el in frame.query_selector_all(seletor):
                    try:
                        texto = el.inner_text().strip()
                        if texto.isdigit() and 0 <= int(texto) <= 36: 
                            return int(texto)
                    except Exception: 
                        continue
        except Exception: 
            continue
    return None

class BotApp:
    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_NOME} • QUANT COMMAND CENTER {APP_VERSAO}")
        
        self.root.geometry("1300x700")
        self.root.minsize(1024, 680)
        try:
            self.root.state('zoomed') 
        except Exception:
            self.root.attributes('-zoomed', True)

        self.bg = "#070A10"
        self.panel = "#0D121C"
        self.panel2 = "#111827"
        self.panel3 = "#0A0F17"
        self.border = "#243246"
        self.border_soft = "#182233"
        self.text = "#E6EDF5"
        self.muted = "#7C8CA3"
        self.cyan = "#22D3EE"
        self.green = "#34D399"
        self.amber = "#FBBF24"
        self.red = "#FB7185"
        self.purple = "#A78BFA"
        self.blue = "#60A5FA"
        self.root.configure(bg=self.bg)

        self._configure_theme()

        self.dados_salvos = self.carregar_config_salva()
        self.estrategias = self.dados_salvos.get("estrategias", [])
        self.estrategias_ia_criadas = []

        for est in self.estrategias:
            if "greens" not in est: est["greens"] = 0
            if "reds" not in est: est["reds"] = 0
            if "max_gales" not in est: est["max_gales"] = 2
            if "mults_gales" not in est: est["mults_gales"] = ["2x", "4x", "8x", "16x", "32x", "64x"]

        self.rodando = False
        self.greens = 0
        self.reds = 0
        self.reds_consecutivos = 0
        self.banca_virtual = float(self.dados_salvos.get("banca_inicial", 200.0))
        self.lucro_virtual = 0.0
        self.valor_recuperacao = 0.0
        self.placar_lock = threading.Lock()
        self.hora_inicio = None

        # Telemetria da sessão (auditoria + métricas por nível de gale)
        self.entradas_sessao = []
        self.greens_por_gale = {}
        self.reds_por_gale = {}

        self.links_mesas = self.dados_salvos.get("links_mesas", {
            "Roleta (roleta-brasilei)": "https://7games.bet.br/casino/live/roleta-brasileira?provider=PTSL",
            "Roleta (brazilian-mega-)": "https://7games.bet.br/casino/live/brazilian-mega-roulette?provider=PTSL"
        })
        self.mult_entries = []
        self.radar = None

        self.main_canvas = tk.Canvas(root, bg=self.bg, highlightthickness=0)
        self.main_scrollbar = ttk.Scrollbar(root, orient="vertical", command=self.main_canvas.yview)
        
        shell = tk.Frame(self.main_canvas, bg=self.bg)
        self.shell_window = self.main_canvas.create_window((0, 0), window=shell, anchor="nw")
        
        self.main_canvas.configure(yscrollcommand=self.main_scrollbar.set)
        
        self.main_canvas.pack(side="left", fill="both", expand=True)
        self.main_scrollbar.pack(side="right", fill="y")
        
        def configure_shell(event):
            self.main_canvas.configure(scrollregion=self.main_canvas.bbox("all"))
        def configure_canvas(event):
            self.main_canvas.itemconfig(self.shell_window, width=event.width)
            
        shell.bind("<Configure>", configure_shell)
        self.main_canvas.bind("<Configure>", configure_canvas)

        def _on_mousewheel(event):
            widget = event.widget
            if isinstance(widget, (tk.Listbox, tk.Text)):
                return
            if widget.winfo_toplevel() == self.root:
                self.main_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
                
        self.root.bind_all("<MouseWheel>", _on_mousewheel)

        header = tk.Frame(shell, bg=self.bg)
        header.pack(fill="x", padx=14, pady=(12, 5)) 

        brand = tk.Frame(header, bg=self.bg)
        brand.pack(side="left", fill="x", expand=True)
        tk.Label(brand, text=APP_NOME, bg=self.bg, fg=self.cyan,
                 font=("Segoe UI", 19, "bold")).pack(anchor="w")
        tk.Label(brand, text=f"CENTRO DE COMANDO {APP_VERSAO}  •  LAB QUANT / SNIPER / TERMO-FÍSICA",
                 bg=self.bg, fg=self.muted, font=("Segoe UI", 8, "bold")).pack(anchor="w", pady=(1, 0))

        status_box = tk.Frame(header, bg="#0A2224", highlightbackground="#154548", highlightthickness=1)
        status_box.pack(side="right")
        self.lbl_header_status = tk.Label(status_box, text="● SYSTEM READY", bg="#0A2224", fg=self.green,
                                          font=("Segoe UI", 9, "bold"), padx=14, pady=8)
        self.lbl_header_status.pack()

        tk.Frame(shell, bg=self.border, height=1).pack(fill="x", padx=14, pady=(0, 5)) 

        main_frame = tk.Frame(shell, bg=self.bg)
        main_frame.pack(fill="both", expand=True, padx=14)

        left_panel = tk.Frame(main_frame, bg=self.bg)
        left_panel.pack(side="left", fill="y", padx=(0, 8))
        tk.Frame(left_panel, width=355, height=1, bg=self.bg).pack() 

        middle_panel = tk.Frame(main_frame, bg=self.bg)
        middle_panel.pack(side="left", fill="y", padx=8)
        tk.Frame(middle_panel, width=445, height=1, bg=self.bg).pack() 

        right_panel = tk.Frame(main_frame, bg=self.bg)
        right_panel.pack(side="left", fill="both", expand=True, padx=(8, 0))

        self._build_left_panel(left_panel)
        self._build_middle_panel(middle_panel)
        self._build_right_panel(right_panel)
        
        self.root.update_idletasks()

    def _configure_theme(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("HUD.TCombobox",
                        fieldbackground=self.panel2, background=self.panel2,
                        foreground=self.text, bordercolor=self.border,
                        arrowcolor=self.cyan, padding=4)
        style.map("HUD.TCombobox",
                  fieldbackground=[("readonly", self.panel2)],
                  foreground=[("readonly", self.text)])
        style.configure("HUD.Horizontal.TScale",
                        background=self.panel2, troughcolor=self.border_soft,
                        sliderthickness=12)

    def _card(self, parent, title=None, accent=None, bg=None, expand=False):
        bg = bg or self.panel
        outer = tk.Frame(parent, bg=bg, highlightbackground=self.border, highlightthickness=1)
        outer.pack(fill="both" if expand else "x", expand=expand, pady=(0, 4)) 
        if title:
            head = tk.Frame(outer, bg=bg)
            head.pack(fill="x", padx=12, pady=(6, 2)) 
            tk.Label(head, text=title.upper(), bg=bg,
                     fg=accent or self.cyan, font=("Segoe UI", 8, "bold")).pack(side="left")
        return outer

    def _label(self, parent, text, fg=None, size=8, bold=True, **kw):
        return tk.Label(parent, text=text, bg=kw.pop("bg", parent.cget("bg")),
                        fg=fg or self.text,
                        font=("Segoe UI", size, "bold" if bold else "normal"), **kw)

    def _entry(self, parent, width=None, fg=None, justify="left"):
        e = tk.Entry(parent, width=width, bg=self.panel2, fg=fg or self.text,
                     insertbackground=self.cyan, relief="flat", bd=0,
                     highlightthickness=1, highlightbackground=self.border,
                     highlightcolor=self.cyan, font=("Segoe UI", 9, "bold"), justify=justify)
        return e

    def _button(self, parent, text, command, kind="ghost", width=None):
        palette = {
            "primary": (self.cyan, "#041015", "#67E8F9"),
            "success": (self.green, "#062116", "#6EE7B7"),
            "warning": (self.amber, "#211700", "#FDE68A"),
            "danger": (self.red, "#240810", "#FDA4AF"),
            "purple": (self.purple, "#130E21", "#C4B5FD"),
            "ghost": (self.panel2, self.text, self.cyan),
        }
        bg, fg, hover = palette[kind]
        b = tk.Button(parent, text=text, command=command, width=width,
                      bg=bg, fg=fg, activebackground=hover, activeforeground="#061018",
                      relief="flat", bd=0, cursor="hand2", font=("Segoe UI", 8, "bold"),
                      padx=10, pady=4) 
        b.bind("<Enter>", lambda e, w=b, c=hover: w.configure(bg=c))
        b.bind("<Leave>", lambda e, w=b, c=bg: w.configure(bg=c))
        return b

    def _build_left_panel(self, parent):
        card = self._card(parent, "01 • MESA & OPERAÇÃO", self.cyan)
        body = tk.Frame(card, bg=self.panel)
        body.pack(fill="x", padx=12, pady=(0, 6))

        self._label(body, "ENDPOINT DO LOBBY", self.muted).pack(anchor="w", pady=(0, 2))
        url_row = tk.Frame(body, bg=self.panel)
        url_row.pack(fill="x", pady=(0, 4))
        self.ent_lobby_url = self._entry(url_row)
        self.ent_lobby_url.insert(0, self.dados_salvos.get("lobby_url", "https://7games.bet.br/casino/live/roleta?provider=PTSL"))
        self.ent_lobby_url.pack(side="left", fill="x", expand=True)
        self._button(url_row, "LER", self.ler_lobby_automatico, "primary").pack(side="right", padx=(6, 0))

        self._label(body, "MESA ALVO", self.muted).pack(anchor="w", pady=(0, 2))
        nomes_salvos = list(self.links_mesas.keys())
        self.combo_mesas = ttk.Combobox(body, font=("Segoe UI", 9), state="readonly",
                                        values=nomes_salvos, style="HUD.TCombobox")
        self.combo_mesas.pack(fill="x", pady=(0, 4), ipady=2)
        if nomes_salvos:
            self.combo_mesas.set(nomes_salvos[0])

        self._label(body, "MODO DE OPERAÇÃO", self.muted).pack(anchor="w", pady=(0, 2))
        mode_row = tk.Frame(body, bg=self.panel2, highlightbackground=self.border, highlightthickness=1)
        mode_row.pack(fill="x")
        self.var_modo = tk.StringVar(value=self.dados_salvos.get("modo_operacao", "Automático"))
        tk.Radiobutton(mode_row, text="AUTOMÁTICO", variable=self.var_modo, value="Automático",
                       bg=self.panel2, fg=self.green, selectcolor=self.panel2, activebackground=self.panel2,
                       activeforeground=self.green, font=("Segoe UI", 8, "bold")).pack(side="left", padx=8, pady=4)
        tk.Radiobutton(mode_row, text="MANUAL / SINAIS", variable=self.var_modo, value="Manual",
                       bg=self.panel2, fg=self.cyan, selectcolor=self.panel2, activebackground=self.panel2,
                       activeforeground=self.cyan, font=("Segoe UI", 8, "bold")).pack(side="left", padx=6, pady=4)

        card_risk = self._card(parent, "02 • GERENCIAMENTO DE RISCO", self.amber)
        body = tk.Frame(card_risk, bg=self.panel)
        body.pack(fill="x", padx=12, pady=(0, 6))

        grid = tk.Frame(body, bg=self.panel)
        grid.pack(fill="x")
        fields = [
            ("BANCA", "ent_banca_inicial", self.dados_salvos.get("banca_inicial", 200.0), self.green),
            ("FICHA", "ent_valor_ficha", self.dados_salvos.get("valor_ficha", 1.0), self.amber),
            ("STOP WIN", "ent_stop_win", self.dados_salvos.get("stop_win", 150), self.green),
            ("STOP LOSS", "ent_stop_loss_brl", self.dados_salvos.get("stop_loss_brl", 90), self.red),
            ("MAX REDS", "ent_max_reds", self.dados_salvos.get("max_reds", 2), self.red),
            ("MAX GALES", "ent_max_gales", self.dados_salvos.get("max_gales", 2), self.amber),
        ]
        for i, (label, attr, value, color) in enumerate(fields):
            cell = tk.Frame(grid, bg=self.panel)
            cell.grid(row=i // 2, column=i % 2, sticky="ew", padx=(0 if i % 2 == 0 else 6, 6 if i % 2 == 0 else 0), pady=2)
            self._label(cell, label, self.muted, size=7).pack(anchor="w", pady=(0, 1))
            ent = self._entry(cell, fg=color, justify="center")
            ent.insert(0, str(value))
            ent.pack(fill="x")
            setattr(self, attr, ent)
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)
        self.ent_max_gales.bind("<KeyRelease>", self.atualizar_campos_gales_dinamicos)

        gale_title = self._label(body, "MULTIPLICADORES DOS GALES", self.muted, size=7)
        gale_title.pack(anchor="w", pady=(4, 2))
        self.frame_mults_container = tk.Frame(body, bg=self.panel2, highlightbackground=self.border, highlightthickness=1)
        self.frame_mults_container.pack(fill="x", pady=(0, 4))

        val_assert_salva = float(self.dados_salvos.get("min_assertividade", 77.0))
        self.lbl_slider_val = self._label(body, f"FILTRO MÍNIMO DE ASSERTIVIDADE  •  {val_assert_salva:.0f}%", self.cyan, size=8)
        self.lbl_slider_val.pack(anchor="w", pady=(2, 2))
        self.slider_assertividade = tk.Scale(
            body, from_=50.0, to=95.0, resolution=1.0, orient="horizontal",
            showvalue=False, bg=self.panel, fg=self.text, activebackground=self.cyan,
            highlightthickness=0, troughcolor=self.border_soft, bd=0,
            command=self.ao_mudar_slider)
        self.slider_assertividade.set(val_assert_salva)
        self.slider_assertividade.pack(fill="x")

        card_strat = self._card(parent, "03 • MULTIGATILHOS & ESTRATÉGIAS", self.cyan, expand=True)
        body = tk.Frame(card_strat, bg=self.panel)
        body.pack(fill="both", expand=True, padx=12, pady=(0, 6))

        self._label(body, "GATILHO / AUSÊNCIA", self.muted, size=7).pack(anchor="w", pady=(0, 2))
        self.ent_gatilhos_multi = self._entry(body)
        self.ent_gatilhos_multi.insert(0, "D3")
        self.ent_gatilhos_multi.pack(fill="x", pady=(0, 4))

        row_aus = tk.Frame(body, bg=self.panel2, highlightbackground=self.border, highlightthickness=1)
        row_aus.pack(fill="x", pady=(0, 4))
        self.var_ausencia = tk.BooleanVar(value=False)
        self.chk_ausencia = tk.Checkbutton(row_aus, text="MODO AUSÊNCIA",
                                           variable=self.var_ausencia, bg=self.panel2, fg=self.amber,
                                           selectcolor=self.panel2, activebackground=self.panel2,
                                           activeforeground=self.amber, font=("Segoe UI", 8, "bold"))
        self.chk_ausencia.pack(anchor="w", padx=8, pady=2)

        self._label(body, "APOSTAS / COBERTURA", self.muted, size=7).pack(anchor="w", pady=(0, 2))
        self.ent_apostas_multi = self._entry(body, fg=self.amber)
        self.ent_apostas_multi.insert(0, "T1 T2 T3 T4 T5 T6 0")
        self.ent_apostas_multi.pack(fill="x", pady=(0, 4))

        btns = tk.Frame(body, bg=self.panel)
        btns.pack(fill="x", pady=(0, 4))
        self._button(btns, "＋ ADC", self.adicionar_estrategia_multi, "success").pack(side="left", fill="x", expand=True, padx=(0, 2))
        self._button(btns, "★ FAV", self.favoritar_estrategia_atual, "warning").pack(side="left", fill="x", expand=True, padx=2)
        self._button(btns, "REM", self.remover_estrategia_selecionada, "ghost").pack(side="left", fill="x", expand=True, padx=2)
        self._button(btns, "LIMP", self.limpar_todas_estrategias, "danger").pack(side="left", fill="x", expand=True, padx=(2, 0))

        list_shell = tk.Frame(body, bg=self.panel3, highlightbackground=self.border, highlightthickness=1)
        list_shell.pack(fill="both", expand=True)
        scroll = tk.Scrollbar(list_shell, orient="vertical", bg=self.panel3, troughcolor=self.panel3,
                              activebackground=self.cyan, bd=0, highlightthickness=0)
        scroll.pack(side="right", fill="y")
        
        self.listbox_estrategias = tk.Listbox(
            list_shell, bg=self.panel3, fg=self.green, font=("Consolas", 8, "bold"),
            bd=0, highlightthickness=0, activestyle="none", selectbackground="#123E42",
            selectforeground=self.text, yscrollcommand=scroll.set, height=6
        )
        self.listbox_estrategias.pack(side="left", fill="both", expand=True, padx=4, pady=4)
        scroll.config(command=self.listbox_estrategias.yview)
        self.atualizar_listbox_estrategias()

        # Botão do Laboratório de Backtest
        backtest_btn_frame = tk.Frame(parent, bg=self.bg)
        backtest_btn_frame.pack(fill="x", pady=(8, 0))
        self._button(backtest_btn_frame, "🧪 LABORATÓRIO DE BACKTEST", self.abrir_laboratorio_backtest, "purple").pack(fill="x", ipady=3)

    def _build_middle_panel(self, parent):
        card = self._card(parent, "COMMAND STATUS", self.cyan)
        body = tk.Frame(card, bg=self.panel)
        body.pack(fill="x", padx=12, pady=(0, 6))

        self.lbl_placar = self._label(body, "GREENS 0   •   REDS 0   •   ASSERTIVIDADE 0.0%", self.green, size=11)
        self.lbl_placar.pack(anchor="w", pady=(0, 2))
        self.lbl_banca_virtual = self._label(body, "BANCA VIRTUAL  R$ 200.00   •   LUCRO  +R$ 0.00", self.amber, size=9)
        self.lbl_banca_virtual.pack(anchor="w")

        self.btn_iniciar = self._button(body, "▶  INICIAR AUTO-BET", self.toggle_bot, "success")
        self.btn_iniciar.pack(fill="x", pady=(6, 4), ipady=2)

        signal_box = tk.Frame(body, bg=self.panel2, highlightbackground=self.border, highlightthickness=1)
        signal_box.pack(fill="x")
        self.lbl_sinal_status = self._label(signal_box, "● AGUARDANDO COMANDO DO OPERADOR...", self.muted, size=9)
        self.lbl_sinal_status.pack(anchor="w", padx=10, pady=5)

        card2 = self._card(parent, "SNIPER • IA DE TERMINAIS", self.purple)
        body = tk.Frame(card2, bg=self.panel)
        body.pack(fill="x", padx=12, pady=(0, 6))

        top = tk.Frame(body, bg=self.panel)
        top.pack(fill="x", pady=(0, 4))
        self.var_sniper = tk.BooleanVar(value=self.dados_salvos.get("sniper_ativo", False))
        tk.Checkbutton(top, text="SNIPER", variable=self.var_sniper, bg=self.panel, fg=self.cyan,
                       selectcolor=self.panel, activebackground=self.panel, activeforeground=self.cyan,
                       font=("Segoe UI", 8, "bold")).pack(side="left")
        self.var_term_dinamico = tk.BooleanVar(value=self.dados_salvos.get("term_dinamico", True))
        tk.Checkbutton(top, text="IA TERMINAIS", variable=self.var_term_dinamico, bg=self.panel, fg=self.cyan,
                       selectcolor=self.panel, activebackground=self.panel, activeforeground=self.cyan,
                       font=("Segoe UI", 8, "bold")).pack(side="left", padx=10)
        self._button(top, "◉ ABRIR ROLETA", self.abrir_roleta, "primary").pack(side="right")

        rows = [
            ("ATRASO", "ent_atraso_min", self.dados_salvos.get("sniper_atraso", 30), self.purple),
            ("VIZINHOS", "ent_vizinhos", self.dados_salvos.get("sniper_vizinhos", 5), self.purple),
            ("MOMENTO", "ent_momentum", self.dados_salvos.get("sniper_momentum", 3), self.purple),
            ("MIN HITS", "ent_term_hits", self.dados_salvos.get("term_hits", 6), self.cyan),
            ("VIZ. TERM", "ent_term_viz", self.dados_salvos.get("term_viz", 2), self.cyan),
            ("AMOSTRA", "ent_amostra", self.dados_salvos.get("amostra_termica", 60), self.amber),
        ]
        grid = tk.Frame(body, bg=self.panel)
        grid.pack(fill="x")
        for i, (lab, attr, val, color) in enumerate(rows):
            cell = tk.Frame(grid, bg=self.panel)
            cell.grid(row=i // 3, column=i % 3, sticky="ew", padx=2, pady=2)
            self._label(cell, lab, self.muted, size=7).pack(anchor="w")
            ent = self._entry(cell, justify="center", fg=color)
            ent.insert(0, str(val))
            ent.pack(fill="x")
            setattr(self, attr, ent)
        for c in range(3): grid.columnconfigure(c, weight=1)

        card3 = self._card(parent, "SISTEMAS PRO • DEFESA", self.amber)
        body = tk.Frame(card3, bg=self.panel)
        body.pack(fill="x", padx=12, pady=(0, 6))
        switches = [
            ("FANTASMA", "var_modo_fantasma", self.dados_salvos.get("modo_fantasma", False), self.text),
            ("ANTI-TENDÊNCIA", "var_anti_tendencia", self.dados_salvos.get("anti_tendencia", False), self.red),
            ("RECUPERAÇÃO", "var_recuperacao", self.dados_salvos.get("recuperacao", False), self.green),
            ("EXPORTAR CSV", "var_exportar_csv", self.dados_salvos.get("exportar_csv", True), self.cyan),
        ]
        switch_grid = tk.Frame(body, bg=self.panel)
        switch_grid.pack(fill="x")
        for i, (text, attr, value, color) in enumerate(switches):
            var = tk.BooleanVar(value=value)
            setattr(self, attr, var)
            tk.Checkbutton(switch_grid, text=text, variable=var, bg=self.panel2, fg=color,
                           selectcolor=self.panel2, activebackground=self.panel2,
                           activeforeground=color, font=("Segoe UI", 7, "bold"),
                           anchor="w").grid(row=i // 2, column=i % 2, sticky="ew", padx=3, pady=2)
        switch_grid.columnconfigure(0, weight=1)
        switch_grid.columnconfigure(1, weight=1)

        depth_row = tk.Frame(body, bg=self.panel)
        depth_row.pack(fill="x", pady=(4, 0))
        self._label(depth_row, "PROFUNDIDADE IA", self.muted, size=7).pack(side="left")
        self.ent_profundidade_ia = self._entry(depth_row, width=7, justify="center", fg=self.cyan)
        self.ent_profundidade_ia.insert(0, str(self.dados_salvos.get("profundidade_ia", 250)))
        self.ent_profundidade_ia.pack(side="right")

        card4 = self._card(parent, "NOTIFICAÇÕES & TELEGRAM", self.blue)
        body = tk.Frame(card4, bg=self.panel)
        body.pack(fill="x", padx=12, pady=(0, 6))
        row = tk.Frame(body, bg=self.panel)
        row.pack(fill="x", pady=2)
        self._label(row, "TOKEN", self.muted, size=7).pack(side="left")
        self.ent_tg_token = self._entry(row, width=26)
        self.ent_tg_token.insert(0, self.dados_salvos.get("tg_token", ""))
        self.ent_tg_token.pack(side="right")

        row2 = tk.Frame(body, bg=self.panel)
        row2.pack(fill="x", pady=2)
        self._label(row2, "CHAT ID", self.muted, size=7).pack(side="left")
        right = tk.Frame(row2, bg=self.panel)
        right.pack(side="right")
        self.ent_tg_chat = self._entry(right, width=18)
        self.ent_tg_chat.insert(0, self.dados_salvos.get("tg_chat", ""))
        self.ent_tg_chat.pack(side="left")
        self._button(right, "TESTAR", self.testar_envio_telegram, "primary").pack(side="left", padx=(6, 0))

        opts = tk.Frame(body, bg=self.panel2, highlightbackground=self.border, highlightthickness=1)
        opts.pack(fill="x", pady=(4, 0))
        self.var_usa_tg = tk.BooleanVar(value=self.dados_salvos.get("usa_tg", True))
        self.var_usa_som = tk.BooleanVar(value=self.dados_salvos.get("usa_som", True))
        self.var_auto_ia = tk.BooleanVar(value=self.dados_salvos.get("auto_ia", True))
        for text, var, color in [("TELEGRAM", self.var_usa_tg, self.cyan), ("SOM", self.var_usa_som, self.green), ("AUTO-IA", self.var_auto_ia, self.amber)]:
            tk.Checkbutton(opts, text=text, variable=var, bg=self.panel2, fg=color, selectcolor=self.panel2,
                           activebackground=self.panel2, activeforeground=color, font=("Segoe UI", 7, "bold")).pack(side="left", padx=6, pady=2)

        tip = tk.Frame(parent, bg="#0A0F17", highlightbackground=self.border_soft, highlightthickness=1)
        tip.pack(fill="both", expand=True)
        tk.Label(tip, text="ATALHOS REMOTOS", bg="#0A0F17", fg=self.cyan,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=12, pady=(4, 2))
        tk.Label(tip, text="/status   /iniciar   /parar   /gale N   /red N   /loss N",
                 bg="#0A0F17", fg=self.muted, font=("Consolas", 8), justify="left").pack(anchor="w", padx=12)

    def _build_right_panel(self, parent):
        frame_ia = self._card(parent, "04 • INTELIGÊNCIA ARTIFICIAL / TELEMETRIA", self.cyan)
        body = tk.Frame(frame_ia, bg=self.panel)
        body.pack(fill="x", padx=12, pady=(0, 6))

        kgrid = tk.Frame(body, bg=self.panel)
        kgrid.pack(fill="x", pady=(0, 4))

        def kpi(title, attr, color, value):
            box = tk.Frame(kgrid, bg=self.panel2, highlightbackground=self.border, highlightthickness=1)
            box.pack(side="left", fill="both", expand=True, padx=2, pady=2)
            tk.Label(box, text=title, bg=self.panel2, fg=self.muted,
                     font=("Segoe UI", 7, "bold")).pack(anchor="w", padx=9, pady=(4, 1))
            lbl = tk.Label(box, text=value, bg=self.panel2, fg=color,
                           font=("Segoe UI", 9, "bold"), justify="left", anchor="w")
            lbl.pack(fill="x", padx=9, pady=(0, 4))
            setattr(self, attr, lbl)

        kpi("ÚLTIMO NÚMERO", "lbl_ia_leitura", self.cyan, "-- | Setores: --")
        kpi("CRUZAMENTO", "lbl_ia_amostra", self.green, "0 / 0 rodadas")
        kpi("LÍDER BACKTEST", "lbl_ia_top_est", self.amber, "Nenhum")
        kpi("GREENS POR GALE", "lbl_metricas_gale", self.purple, "DIRETA 0 • G1 0 • G2 0")

        lower = tk.Frame(body, bg=self.panel)
        lower.pack(fill="x")
        kpi2 = tk.Frame(lower, bg=self.panel2, highlightbackground=self.border, highlightthickness=1)
        kpi2.pack(side="left", fill="x", expand=True, padx=(2, 4), pady=2)
        self.lbl_ia_mutacao = tk.Label(kpi2, text="🧬 REFINAMENTO: aguardando...",
                                       bg=self.panel2, fg=self.purple, font=("Consolas", 8, "bold"), anchor="w")
        self.lbl_ia_mutacao.pack(fill="x", padx=9, pady=5)
        kpi3 = tk.Frame(lower, bg=self.panel2, highlightbackground=self.border, highlightthickness=1)
        kpi3.pack(side="left", fill="x", expand=True, padx=(0, 2), pady=2)
        self.lbl_ia_analise = tk.Label(kpi3, text="ANÁLISE: aguardando...",
                                      bg=self.panel2, fg=self.muted, font=("Consolas", 8, "bold"), anchor="w")
        self.lbl_ia_analise.pack(fill="x", padx=9, pady=5)

        mem = tk.Frame(body, bg=self.panel3, highlightbackground=self.border, highlightthickness=1)
        mem.pack(fill="x", padx=2, pady=(4, 0))
        self.lbl_ia_memoria = tk.Label(mem, text="MEMÓRIA RAM VISUAL  •  [ ]", bg=self.panel3,
                                       fg=self.muted, font=("Consolas", 8), anchor="w", justify="left")
        self.lbl_ia_memoria.pack(fill="x", padx=9, pady=4)

        frame_log = self._card(parent, "05 • TERMINAL DE AÇÕES / LOGS", self.cyan, expand=True)
        log_shell = tk.Frame(frame_log, bg=self.panel3)
        log_shell.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        scroll_log = tk.Scrollbar(log_shell, orient="vertical", bg=self.panel3, troughcolor=self.panel3,
                                  activebackground=self.cyan, bd=0, highlightthickness=0)
        scroll_log.pack(side="right", fill="y")
        self.txt_log = tk.Text(log_shell, bg="#05080D", fg="#7CF5C1", font=("Consolas", 8),
                               bd=0, padx=10, pady=6, insertbackground=self.cyan,
                               selectbackground="#123E42", selectforeground=self.text,
                               wrap="word", yscrollcommand=scroll_log.set)
        self.txt_log.pack(fill="both", expand=True)
        scroll_log.config(command=self.txt_log.yview)
        self.txt_log.tag_config("green", foreground=self.green, font=("Consolas", 8, "bold"))
        self.txt_log.tag_config("red", foreground=self.red, font=("Consolas", 8, "bold"))
        self.txt_log.tag_config("amber", foreground=self.amber, font=("Consolas", 8, "bold"))
        self.txt_log.tag_config("cyan", foreground=self.cyan, font=("Consolas", 8, "bold"))
        self.txt_log.tag_config("purple", foreground=self.purple)
        self.txt_log.tag_config("muted", foreground=self.muted)
        self.txt_log.tag_config("normal", foreground=self.text)

        self.atualizar_campos_gales_dinamicos()
        threading.Thread(target=self.loop_telegram_listener, daemon=True).start()

    def abrir_roleta(self):
        if self.radar is None or not self.radar.top.winfo_exists():
            self.radar = RoletaAoVivo(self.root, self)
        else:
            self.radar.mostrar()

    def _desenhar_roleta_ao_vivo(self, mesa_info):
        if hasattr(self, "radar") and self.radar and getattr(self.radar, "visivel", False):
            sinal_ativo = None
            if mesa_info.get("sinais"):
                sinal_ativo = mesa_info["sinais"][0]
            else:
                if self.var_sniper.get():
                    sinal_ativo = self.analisar_numeros_plenos_sniper(mesa_info, silencioso=True)
                if not sinal_ativo and hasattr(self, 'var_term_dinamico') and self.var_term_dinamico.get():
                    sinal_ativo = self.analisar_terminais_dinamicos(mesa_info, silencioso=True)
                
            self.radar.atualizar_dados_ao_vivo(mesa_info, sinal_ativo)

    def limpar_todas_estrategias(self):
        if messagebox.askyesno("Aviso", "Tem certeza que deseja apagar TODAS as estratégias da lista e forçar a IA a minerar padrões do zero?"):
            self.estrategias.clear()
            self.estrategias_ia_criadas.clear()
            self.salvar_config()
            self.atualizar_listbox_estrategias()
            self.registrar_log("🧹 Limpeza total! A memória da IA foi apagada. Pronta para um novo ciclo.")

    def loop_telegram_listener(self):
        last_update_id = 0
        while True:
            token = self.ent_tg_token.get().strip()
            if token and self.var_usa_tg.get():
                url = f"https://api.telegram.org/bot{token}/getUpdates?offset={last_update_id}&timeout=5"
                try:
                    with urllib.request.urlopen(url, timeout=10) as response:
                        data = json.loads(response.read().decode())
                        if data.get("ok"):
                            for update in data.get("result", []):
                                update_id = update["update_id"]
                                last_update_id = update_id + 1
                                
                                message = update.get("message", {})
                                text = message.get("text", "").strip()
                                chat_id = str(message.get("chat", {}).get("id", ""))
                                
                                if chat_id == self.ent_tg_chat.get().strip():
                                    self.processar_comando_telegram(text)
                except Exception:
                    pass
            time.sleep(2)

    def processar_comando_telegram(self, texto):
        comando = texto.lower().split()
        if not comando: return
        
        cmd = comando[0]
        try:
            if cmd == "/status":
                sinal_lucro = "+" if self.lucro_virtual >= 0 else "-"
                banca_atual = self.banca_virtual + self.lucro_virtual
                msg = (f"📊 *STATUS DA OPERAÇÃO*\n"
                       f"✅ Greens: {self.greens}\n"
                       f"❌ Reds: {self.reds}\n"
                       f"💵 Lucro: {sinal_lucro}R$ {abs(self.lucro_virtual):.2f}\n"
                       f"💰 Banca Virtual: R$ {banca_atual:.2f}")
                self.enviar_tg_notificacao(msg)
                
            elif cmd == "/parar":
                if self.rodando:
                    self.root.after(0, self.toggle_bot)
                    self.enviar_tg_notificacao("🛑 *COMANDO ACEITO:* Robô parado remotamente.")
                else:
                    self.enviar_tg_notificacao("O robô já está parado.")
                    
            elif cmd == "/iniciar":
                if not self.rodando:
                    self.root.after(0, self.toggle_bot)
                    self.enviar_tg_notificacao("▶️ *COMANDO ACEITO:* Robô iniciado remotamente.")
                else:
                    self.enviar_tg_notificacao("O robô já está rodando.")
                    
            elif cmd == "/gale" and len(comando) > 1:
                val = int(comando[1])
                self.root.after(0, lambda: [self.ent_max_gales.delete(0, tk.END), self.ent_max_gales.insert(0, str(val)), self.atualizar_campos_gales_dinamicos(), self.salvar_config()])
                self.enviar_tg_notificacao(f"⚙️ *COMANDO ACEITO:* Max Gales alterado para {val}.")
                
            elif cmd == "/red" and len(comando) > 1:
                val = int(comando[1])
                self.root.after(0, lambda: [self.ent_max_reds.delete(0, tk.END), self.ent_max_reds.insert(0, str(val)), self.salvar_config()])
                self.enviar_tg_notificacao(f"⚙️ *COMANDO ACEITO:* Max Reds alterado para {val}.")
                
            elif cmd == "/loss" and len(comando) > 1:
                val = float(comando[1])
                self.root.after(0, lambda: [self.ent_stop_loss_brl.delete(0, tk.END), self.ent_stop_loss_brl.insert(0, str(val)), self.salvar_config()])
                self.enviar_tg_notificacao(f"⚙️ *COMANDO ACEITO:* Stop Loss alterado para R$ {val:.2f}.")
                
            elif cmd == "/win" and len(comando) > 1:
                val = float(comando[1])
                self.root.after(0, lambda: [self.ent_stop_win.delete(0, tk.END), self.ent_stop_win.insert(0, str(val)), self.salvar_config()])
                self.enviar_tg_notificacao(f"⚙️ *COMANDO ACEITO:* Stop Win alterado para R$ {val:.2f}.")
        except Exception as e:
            self.enviar_tg_notificacao(f"⚠️ Erro ao processar comando remoto: {e}")

    def ao_mudar_slider(self, valor):
        v = float(valor)
        self.lbl_slider_val.config(text=f"🎯 Filtro Mínimo de Assertividade: {v:.0f}%")
        self.salvar_config()

    def atualizar_campos_gales_dinamicos(self, event=None):
        for widget in self.frame_mults_container.winfo_children():
            widget.destroy()
        self.mult_entries = []
        try:
            qtd_gales = int(self.ent_max_gales.get().strip())
        except ValueError:
            qtd_gales = 2
        if qtd_gales < 0: qtd_gales = 0
        if qtd_gales > 6: qtd_gales = 6

        salvos_mults = ["2x", "4x", "8x", "16x", "32x", "64x"]
        row_frame = None
        for i in range(qtd_gales):
            if i % 3 == 0:
                row_frame = tk.Frame(self.frame_mults_container, bg=self.panel2)
                row_frame.pack(fill="x", pady=3)
            cell = tk.Frame(row_frame, bg=self.panel2)
            cell.pack(side="left", fill="x", expand=True, padx=4)
            tk.Label(cell, text=f"GALE {i+1}:", bg=self.panel2, fg=self.amber,
                     font=("Segoe UI", 7, "bold")).pack(side="left")
            val_padrao = salvos_mults[i] if i < len(salvos_mults) else f"{2**(i+1)}x"
            ent = tk.Entry(cell, width=5, bg="#0A0F17", fg=self.amber, bd=0, justify="center",
                           insertbackground=self.amber, highlightthickness=1,
                           highlightbackground=self.border, highlightcolor=self.amber,
                           font=("Segoe UI", 8, "bold"))
            ent.insert(0, val_padrao)
            ent.pack(side="right", ipady=4)
            self.mult_entries.append(ent)

    def ler_lobby_automatico(self):
        url = self.ent_lobby_url.get().strip()
        if not url:
            return messagebox.showwarning("Aviso", "Insira o link!")
        threading.Thread(target=self._executar_extracao_playtech_strict, args=(url,), daemon=True).start()

    def _executar_extracao_playtech_strict(self, url):
        self.registrar_log(f"Lendo mesas estritamente Playtech em: {url}")
        self.root.after(0, lambda: self.lbl_ia_analise.config(text="🌐 Lendo lobby...", fg="#00ffff"))
        try:
            with sync_playwright() as p:
                browser = p.chromium.connect_over_cdp("http://127.0.0.1:9222")
                context = browser.contexts[0]
                page = context.new_page()
                page.goto(url, timeout=30000)
                time.sleep(5)

                for sel in ['[class*="lobby"]', '[class*="menu-button"]', 'button[aria-label*="Lobby"]']:
                    try:
                        btn = page.locator(sel).first
                        if btn.count():
                            btn.click(force=True)
                            time.sleep(3)
                            break
                    except Exception:
                        continue

                links_elementos = page.query_selector_all('a[href*="roleta"], a[href*="roulette"], a[href*="table"], a[href*="live"], a[href*="playtech"]')
                mesas_dict = {}
                provedores_playtech = ["playtech", "gambling-malta.com", "ptsl", "canarinho"]
                blacklist = ["facebook", "sharer", "twitter", "whatsapp", "instagram", "login", "register", "deposit", "terms", "support", "help"]

                for el in links_elementos:
                    try:
                        href = el.get_attribute("href")
                        texto = el.inner_text().strip()
                        if href:
                            if any(b in href.lower() for b in blacklist): continue
                            if any(prov in href.lower() for prov in provedores_playtech):
                                if not href.startswith("http"):
                                    parsed_url = urllib.parse.urlparse(url)
                                    href = f"{parsed_url.scheme}://{parsed_url.netloc}{href}"
                                nome_mesa = texto.split('\n')[0] if texto else f"Roleta ({href.split('/')[-1][:15]})"
                                if len(nome_mesa) > 40: nome_mesa = nome_mesa[:40] + "..."
                                if nome_mesa not in mesas_dict:
                                    mesas_dict[nome_mesa] = href
                    except Exception:
                        continue
                
                page.close()
                self.links_mesas = mesas_dict
                nomes = list(mesas_dict.keys())
                if nomes:
                    self.root.after(0, lambda: self.combo_mesas.config(values=nomes))
                    self.root.after(0, lambda: self.combo_mesas.set(nomes[0]))
                    self.salvar_config()
                    self.registrar_log(f"Filtro concluído! Encontradas {len(nomes)} roletas Playtech e salvas.")
                    self.root.after(0, lambda: self.lbl_sinal_status.config(text=f"🟢 {len(nomes)} ROLETAS PRONTAS!", fg="#00ff88"))
                else:
                    self.registrar_log("Nenhuma roleta Playtech capturada.")
                    self.root.after(0, lambda: self.lbl_sinal_status.config(text="⚠️ NENHUMA MESA ENCONTRADA", fg="#ffaa00"))
        except Exception as e:
            self.registrar_log(f"Erro ao carregar lobby: {e}")
            self.root.after(0, lambda: self.lbl_sinal_status.config(text="❌ ERRO AO LER LOBBY", fg="#ff4444"))

    def testar_envio_telegram(self):
        t, c = self.ent_tg_token.get().strip(), self.ent_tg_chat.get().strip()
        ok, msg = enviar_telegram_direto(t, c, f"🧪 *TESTE {APP_NOME} {APP_VERSAO}!* Conexão OK. 🧠")
        if ok: 
            messagebox.showinfo("Sucesso", f"🟢 {msg}")
            self.registrar_log("Teste Telegram sucesso!")
        else: 
            messagebox.showerror("Erro", f"🔴 {msg}")

    def _classificar_log(self, mensagem):
        """Escaneia a mensagem por termos-chave e devolve a tag de cor correspondente."""
        texto = mensagem.upper()

        if "GREEN" in texto or "LUCRO: +" in texto or "STOP WIN" in texto:
            return "green"
        if "RED" in texto or "LOSS: -" in texto or "PREJUÍZO" in texto or "STOP LOSS" in texto or "LIMITES" in texto or "ERRO" in texto:
            return "red"
        if "GALE" in texto or "⚠" in texto:
            return "amber"
        if "SINAL" in texto or "SNIPER" in texto or "TERMO" in texto or "CHROME" in texto:
            return "cyan"
        if "HISTÓRICO" in texto or "LOBBY" in texto or "LIMPEZA" in texto or "RELATÓRIO" in texto or "SESSÃO" in texto:
            return "purple"
        return "normal"

    def registrar_log(self, mensagem):
        hora = datetime.now().strftime('%H:%M:%S')
        tag = self._classificar_log(mensagem)

        def _inserir_texto():
            try:
                self.txt_log.insert(tk.END, f"[{hora}] ", "muted")
                self.txt_log.insert(tk.END, f"{mensagem}\n", tag)
                # Mantém o terminal enxuto em sessões longas
                if int(self.txt_log.index("end-1c").split(".")[0]) > 800:
                    self.txt_log.delete("1.0", "200.0")
                self.txt_log.see(tk.END)
            except Exception as e:
                logging.error(f"Erro ao registrar log na interface: {e}")

        self.root.after(0, _inserir_texto)

    def registrar_entrada_sessao(self, estrategia, numero, resultado, gale, valor):
        """Consolida a entrada liquidada: métricas por gale, auditoria e painel da roleta."""
        try:
            gale = int(gale or 0)
            resultado = str(resultado).upper()
            valor = float(valor)

            with self.placar_lock:
                alvo = self.greens_por_gale if resultado == "GREEN" else self.reds_por_gale
                alvo[gale] = alvo.get(gale, 0) + 1
                self.entradas_sessao.append({
                    "hora": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    "estrategia": estrategia,
                    "numero": numero,
                    "resultado": resultado,
                    "gale": gale,
                    "valor": round(valor, 2),
                    "lucro_acumulado": round(self.lucro_virtual, 2)
                })
                metricas = dict(self.greens_por_gale)

            self.root.after(0, lambda m=metricas: self.atualizar_metricas_gale_ui(m))
            self.root.after(0, lambda: self._enviar_entrada_para_radar(estrategia, numero, resultado, gale, valor))
        except Exception as e:
            logging.error(f"Erro ao registrar entrada da sessão: {e}")

    def _enviar_entrada_para_radar(self, estrategia, numero, resultado, gale, valor):
        radar = self.radar
        if radar is None:
            return
        try:
            if radar.top.winfo_exists():
                radar.adicionar_entrada_historico(estrategia, numero, resultado, gale, valor)
        except Exception as e:
            logging.error(f"Erro ao enviar entrada para o painel da roleta: {e}")

    def atualizar_metricas_gale_ui(self, greens_por_gale):
        niveis = sorted(set(list(greens_por_gale.keys()) + [0, 1, 2]))
        texto = " • ".join(
            f"{'DIRETA' if n == 0 else f'G{n}'} {greens_por_gale.get(n, 0)}" for n in niveis
        )
        try:
            self.lbl_metricas_gale.config(text=texto)
        except Exception as e:
            logging.error(f"Erro ao atualizar KPI de gales: {e}")

        radar = self.radar
        if radar is not None:
            try:
                if radar.top.winfo_exists():
                    radar.atualizar_metricas_gale({n: greens_por_gale.get(n, 0) for n in niveis})
            except Exception as e:
                logging.error(f"Erro ao atualizar métricas de gale no radar: {e}")

    def exportar_relatorio_sessao(self, motivo):
        """Exporta CSV + JSON da sessão em /relatorios com timestamp no nome do arquivo."""
        if not self.entradas_sessao:
            return None

        with self.placar_lock:
            entradas = list(self.entradas_sessao)
            greens_gale = dict(self.greens_por_gale)
            reds_gale = dict(self.reds_por_gale)
            total = self.greens + self.reds
            assertividade = (self.greens / total * 100) if total > 0 else 0.0
            resumo = {
                "motivo_encerramento": motivo,
                "inicio": self.hora_inicio.strftime('%Y-%m-%d %H:%M:%S') if self.hora_inicio else None,
                "fim": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                "greens": self.greens,
                "reds": self.reds,
                "assertividade": round(assertividade, 2),
                "lucro_liquido": round(self.lucro_virtual, 2),
                "banca_final": round(self.banca_virtual + self.lucro_virtual, 2),
                "greens_por_gale": greens_gale,
                "reds_por_gale": reds_gale
            }

        try:
            os.makedirs(RELATORIOS_DIR, exist_ok=True)
            carimbo = datetime.now().strftime('%Y%m%d_%H%M%S')
            caminho_csv = os.path.join(RELATORIOS_DIR, f"sessao_{carimbo}.csv")
            caminho_json = os.path.join(RELATORIOS_DIR, f"sessao_{carimbo}.json")

            with open(caminho_csv, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(
                    f, fieldnames=["hora", "estrategia", "numero", "resultado", "gale", "valor", "lucro_acumulado"]
                )
                writer.writeheader()
                writer.writerows(entradas)

            with open(caminho_json, "w", encoding="utf-8") as f:
                json.dump({"resumo": resumo, "entradas": entradas}, f, indent=4, ensure_ascii=False)

            self.registrar_log(f"📁 Relatório da sessão exportado: {caminho_csv}")
            return caminho_csv
        except (IOError, OSError) as e:
            logging.error(f"Erro ao exportar relatório da sessão: {e}")
            self.registrar_log(f"⚠️ Falha ao exportar o relatório da sessão: {e}")
            return None

    def tocar_alerta(self) -> None:
        if winsound is None or not self.var_usa_som.get():
            return
        try:
            winsound.Beep(1000, 300)
            winsound.Beep(1500, 200)
        except Exception:
            pass

    def enviar_tg_notificacao(self, msg: str) -> None:
        if self.var_usa_tg.get():
            threading.Thread(target=enviar_telegram_direto, args=(self.ent_tg_token.get().strip(), self.ent_tg_chat.get().strip(), msg), daemon=True).start()

    def carregar_config_salva(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    d = json.load(f)
                    return d if isinstance(d, dict) else {"estrategias": d}
            except (IOError, json.JSONDecodeError):
                pass
        return {}

    def salvar_config(self):
        d = {
            "estrategias": self.estrategias, "tg_token": self.ent_tg_token.get().strip(),
            "tg_chat": self.ent_tg_chat.get().strip(), "usa_tg": self.var_usa_tg.get(),
            "usa_som": self.var_usa_som.get(), "auto_ia": self.var_auto_ia.get(),
            "stop_win": self.ent_stop_win.get(), "stop_loss_brl": self.ent_stop_loss_brl.get(), 
            "max_reds": self.ent_max_reds.get(), "max_gales": self.ent_max_gales.get(), 
            "lobby_url": self.ent_lobby_url.get().strip(), "modo_operacao": self.var_modo.get(), 
            "banca_inicial": self.ent_banca_inicial.get(), "valor_ficha": self.ent_valor_ficha.get(), 
            "links_mesas": self.links_mesas,
            "modo_fantasma": self.var_modo_fantasma.get(),
            "anti_tendencia": self.var_anti_tendencia.get(),
            "recuperacao": self.var_recuperacao.get(),
            "exportar_csv": self.var_exportar_csv.get(),
            "profundidade_ia": self.ent_profundidade_ia.get().strip() if hasattr(self, "ent_profundidade_ia") else 250,
            "min_assertividade": self.slider_assertividade.get() if hasattr(self, "slider_assertividade") else 80.0,
            "sniper_ativo": self.var_sniper.get() if hasattr(self, "var_sniper") else False,
            "sniper_atraso": self.ent_atraso_min.get().strip() if hasattr(self, "ent_atraso_min") else 30,
            "sniper_vizinhos": self.ent_vizinhos.get().strip() if hasattr(self, "ent_vizinhos") else 5,
            "sniper_momentum": self.ent_momentum.get().strip() if hasattr(self, "ent_momentum") else 3,
            "term_dinamico": getattr(self, "var_term_dinamico", tk.BooleanVar(value=True)).get(),
            "term_hits": self.ent_term_hits.get().strip() if hasattr(self, "ent_term_hits") else 6,
            "term_viz": self.ent_term_viz.get().strip() if hasattr(self, "ent_term_viz") else 2,
            "amostra_termica": self.ent_amostra.get().strip() if hasattr(self, "ent_amostra") else 60
        }
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f: 
                json.dump(d, f, indent=4)
        except IOError as e:
            logging.error(f"Erro ao salvar config.json: {e}")

    def salvar_auditoria(self, motivo):
        banca_final = self.banca_virtual + self.lucro_virtual
        relatorio = {
            "data": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "motivo_parada": motivo,
            "greens": self.greens,
            "reds": self.reds,
            "assertividade": self.atualizar_placar(),
            "lucro_virtual": self.lucro_virtual,
            "banca_final": banca_final
        }
        try:
            historico = []
            if os.path.exists(AUDIT_FILE):
                with open(AUDIT_FILE, "r", encoding="utf-8") as f:
                    historico = json.load(f)
            historico.append(relatorio)
            with open(AUDIT_FILE, "w", encoding="utf-8") as f:
                json.dump(historico, f, indent=4)
        except (IOError, json.JSONDecodeError) as e:
            logging.error(f"Erro ao salvar auditoria: {e}")

    def salvar_historico_csv(self, nome_mesa, numero, tags):
        if not self.var_exportar_csv.get(): return
        
        arquivo_csv = "banco_dados_roleta.csv"
        existe = os.path.exists(arquivo_csv)
        
        try:
            with open(arquivo_csv, "a", encoding="utf-8") as f:
                if not existe:
                    f.write("DataHora,Mesa,Numero,Tags\n") 
                
                data_hora = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                tags_formatadas = "-".join(tags)
                f.write(f"{data_hora},{nome_mesa},{numero},{tags_formatadas}\n")
        except Exception as e:
            logging.error(f"Erro ao salvar CSV: {e}")

    def extrair_historico_inicial(self, page):
        self.registrar_log("Acessando o painel de Resultados (.nth(4))...")
        sucesso_clique_res = False
        
        for tentativa in range(10):
            for frame in [page] + list(page.frames):
                try:
                    sidebar_icon = frame.locator("svg.sidebar-icon-svg").nth(4)
                    if sidebar_icon.is_visible(timeout=500):
                        sidebar_icon.click(force=True)
                        sucesso_clique_res = True
                        break
                except Exception:
                    continue
            if sucesso_clique_res:
                break
            time.sleep(1)
            
        time.sleep(4.0) 

        seletores_grade = [
            '.history-item-value__text--n5cYB',
            'div[class*="history-item-value__text"]',
            'div[class*="history-item-value"]'
        ]
        
        try: 
            frames_atuais = list(page.frames)
        except Exception: 
            frames_atuais = []
        
        for frame in [page] + frames_atuais:
            try:
                if frame != page and frame.is_detached(): 
                    continue
                for seletor in seletores_grade:
                    elementos = frame.query_selector_all(seletor)
                    if len(elementos) >= 10:
                        numeros_encontrados = []
                        for el in elementos:
                            try:
                                texto = el.inner_text().strip()
                                if texto.isdigit() and 0 <= int(texto) <= 36:
                                    numeros_encontrados.append(int(texto))
                            except Exception:
                                continue
                        
                        if len(numeros_encontrados) >= 10:
                            self.registrar_log(f"🎯 Grade de resultados varrida com sucesso! Capturados {len(numeros_encontrados)} números no total.")
                            return list(reversed(numeros_encontrados))
            except Exception:
                continue
        return []

    # =========================================================================
    # LÓGICA MODO SNIPER (NÚMEROS PLENOS)
    # =========================================================================
    def obter_vizinhos_cilindro(self, num, qtd):
        idx = RODA_EUROPEIA.index(num)
        tamanho = len(RODA_EUROPEIA)
        vizinhos = []
        for i in range(-qtd, qtd + 1):
            viz_idx = (idx + i) % tamanho
            vizinhos.append(RODA_EUROPEIA[viz_idx])
        return vizinhos

    def analisar_numeros_plenos_sniper(self, mesa_info, silencioso=False):
        if not self.var_sniper.get(): return None

        historico_bruto = mesa_info.get("historico_numeros_brutos", [])
        
        try: janela_amostra = int(self.ent_amostra.get().strip())
        except ValueError: janela_amostra = 60
            
        if len(historico_bruto) < janela_amostra: return None 

        try: atraso_min = int(self.ent_atraso_min.get())
        except ValueError: atraso_min = 30

        try: qtd_vizinhos = int(self.ent_vizinhos.get())
        except ValueError: qtd_vizinhos = 5

        try: momentum_min = int(self.ent_momentum.get())
        except ValueError: momentum_min = 3

        try: min_meta = self.slider_assertividade.get()
        except Exception: min_meta = 80.0

        try: max_gales_sim = int(self.ent_max_gales.get())
        except ValueError: max_gales_sim = 2

        atrasos = {}
        for n in range(37):
            try:
                idx_reverso = historico_bruto[::-1].index(n)
                atrasos[n] = idx_reverso
            except ValueError:
                atrasos[n] = len(historico_bruto)

        janela_recente = historico_bruto[-janela_amostra:]
        alvos_encontrados = []

        for n, atraso in atrasos.items():
            if atraso >= atraso_min:
                vizinhos_zona = self.obter_vizinhos_cilindro(n, qtd_vizinhos)
                acertos_zona = sum(1 for x in janela_recente if x in vizinhos_zona)

                if acertos_zona >= momentum_min:
                    alvos_encontrados.append((n, vizinhos_zona, atraso, acertos_zona))

        if alvos_encontrados:
            alvos_encontrados.sort(key=lambda x: (x[3], x[2]), reverse=True)
            
            for alvo in alvos_encontrados:
                num_alvo = alvo[0]
                
                if mesa_info.get("cooldown_sniper", 0) > 0 and mesa_info.get("ultimo_alvo_sniper") == num_alvo:
                    continue
                
                zona = alvo[1]
                atraso_alvo = alvo[2]
                
                greens_bt = 0
                reds_bt = 0
                
                i = 0
                while i < len(janela_recente) - max_gales_sim:
                    acertou_no_ciclo = False
                    g_usado = 0
                    for g in range(max_gales_sim + 1):
                        if i + g < len(janela_recente):
                            if str(janela_recente[i + g]) in map(str, zona):
                                acertou_no_ciclo = True
                                g_usado = g
                                break
                        g_usado = g
                    
                    if acertou_no_ciclo: 
                        greens_bt += 1
                    else: 
                        reds_bt += 1
                        
                    i += (g_usado + 1)
                
                total_bt = greens_bt + reds_bt
                pct_bt = (greens_bt / total_bt * 100) if total_bt > 0 else 0.0
                
                if pct_bt >= min_meta:
                    aposta_str = " ".join(map(str, zona))
                    if not silencioso:
                        self.registrar_log(f"🎯 [Sniper] Alvo {num_alvo} validado ({pct_bt:.1f}% assertividade).")
                    
                    return {
                        "nome": f"Sniper (Alvo: {num_alvo})",
                        "gatilho_str": f"🎯 MODO SNIPER [Alvo: {num_alvo} | Atr: {atraso_alvo}]",
                        "aposta_str": aposta_str,
                        "alvos": [str(x) for x in zona],
                        "alvo_central": num_alvo,
                        "max_gales": max_gales_sim,
                        "mults_gales": [ent.get() for ent in self.mult_entries],
                        "ausencia": False,
                        "greens": greens_bt,
                        "reds": reds_bt,
                        "pct": pct_bt
                    }
        return None

    # =========================================================================
    # IA: MISTURA TERMINAIS E VIZINHOS FÍSICOS (Matriz Híbrida)
    # =========================================================================
    def analisar_terminais_dinamicos(self, mesa_info, silencioso=False):
        if not hasattr(self, 'var_term_dinamico') or not self.var_term_dinamico.get(): return None

        historico_bruto = mesa_info.get("historico_numeros_brutos", [])
        
        try: janela_amostra = int(self.ent_amostra.get().strip())
        except ValueError: janela_amostra = 60
            
        if len(historico_bruto) < janela_amostra: return None 

        try: min_hits = int(self.ent_term_hits.get())
        except ValueError: min_hits = 8

        try: qtd_vizinhos = int(self.ent_term_viz.get())
        except ValueError: qtd_vizinhos = 1

        try: min_meta = self.slider_assertividade.get()
        except Exception: min_meta = 80.0

        try: max_gales_sim = int(self.ent_max_gales.get())
        except ValueError: max_gales_sim = 2

        janela_recente = historico_bruto[-janela_amostra:]
        
        cont_terms = {i: 0 for i in range(10)}
        for n in janela_recente: cont_terms[n % 10] += 1
        
        term_campeao = max(cont_terms.items(), key=lambda x: x[1])
        term_id = term_campeao[0]
        hits_term = term_campeao[1]

        if hits_term < min_hits: return None
        
        if mesa_info.get("cooldown_term", 0) > 0 and mesa_info.get("ultimo_alvo_term") == f"T{term_id}":
            return None

        numeros_base = TERMINAIS_MAP[f"T{term_id}"]
        alvos_expandidos = set()
        for num_str in numeros_base:
            viz = self.obter_vizinhos_cilindro(int(num_str), qtd_vizinhos)
            for v in viz: alvos_expandidos.add(str(v))
            
        zona = list(alvos_expandidos)
        
        greens_bt = 0
        reds_bt = 0
        i = 0
        while i < len(janela_recente) - max_gales_sim:
            acertou_no_ciclo = False
            g_usado = 0
            for g in range(max_gales_sim + 1):
                if i + g < len(janela_recente):
                    if str(janela_recente[i + g]) in zona:
                        acertou_no_ciclo = True
                        g_usado = g
                        break
                g_usado = g
            
            if acertou_no_ciclo: greens_bt += 1
            else: reds_bt += 1
            i += (g_usado + 1)
            
        total_bt = greens_bt + reds_bt
        pct_bt = (greens_bt / total_bt * 100) if total_bt > 0 else 0.0
        
        if pct_bt >= min_meta:
            aposta_str = " ".join(zona)
            if not silencioso:
                self.registrar_log(f"🌀 [Termo-Física] Validado T{term_id} + {qtd_vizinhos} Viz ➔ G:{greens_bt} R:{reds_bt} ({pct_bt:.1f}%)")
            
            return {
                "nome": f"Terminal Físico (T{term_id} + {qtd_vizinhos}V)",
                "gatilho_str": f"🌀 IA TERMO-FÍSICA [T{term_id} em Alta ({hits_term}x)]",
                "aposta_str": aposta_str,
                "alvos": zona,
                "alvo_central": f"T{term_id}",
                "is_termo": True,
                "max_gales": max_gales_sim,
                "mults_gales": [ent.get() for ent in self.mult_entries],
                "ausencia": False,
                "greens": greens_bt,
                "reds": reds_bt,
                "pct": pct_bt
            }
            
        return None

    # =========================================================================
    # CÉREBRO G2 (O DREAM TEAM INSERIDO COM BACKTEST REAL DE GALE)
    # =========================================================================
    def minerar_estrategias_autonomas_ia(self, historico_tags, historico_nums):
        if not self.var_auto_ia.get(): return
        
        candidatos_gerados = []
        
        padroes_teste = [
            (["D1", "D1"], ["D2", "D3"], "Quebra 2x D1 ➔ D2/D3"),
            (["D2", "D2"], ["D1", "D3"], "Quebra 2x D2 ➔ D1/D3"),
            (["D3", "D3"], ["D1", "D2"], "Quebra 2x D3 ➔ D1/D2"),
            (["C1", "C1"], ["C2", "C3"], "Quebra 2x C1 ➔ C2/C3"),
            (["C2", "C2"], ["C1", "C3"], "Quebra 2x C2 ➔ C1/C3"),
            (["C3", "C3"], ["C1", "C2"], "Quebra 2x C3 ➔ C1/C2"),
            (["R", "R", "R"], ["B"], "Quebra 3 Vermelhos ➔ Preto"),
            (["R", "R", "R", "R"], ["B"], "Quebra 4 Vermelhos ➔ Preto"),
            (["B", "B", "B"], ["R"], "Quebra 3 Pretos ➔ Vermelho"),
            (["B", "B", "B", "B"], ["R"], "Quebra 4 Pretos ➔ Vermelho"),
            (["P1", "P1"], ["P2", "P3"], "Fadiga 2x Setor 1 ➔ P2/P3"),
            (["P2", "P2"], ["P1", "P3"], "Fadiga 2x Setor 2 ➔ P1/P3"),
            (["P3", "P3"], ["P1", "P2"], "Fadiga 2x Setor 3 ➔ P1/P2"),
            (["0"], ["P1", "T0"], "Gatilho do Zero ➔ P1/T0")
        ]
        
        try: mg_ia = int(self.ent_max_gales.get().strip())
        except ValueError: mg_ia = 2
        mults_ia = [ent.get().strip() for ent in self.mult_entries]
        min_meta = self.slider_assertividade.get()

        for gatilho_seq, alvos_seq, nome_padrao in padroes_teste:
            greens_bt = 0
            reds_bt = 0
            tam_g = len(gatilho_seq)
            
            i = tam_g
            while i < len(historico_tags):
                sub_h = historico_tags[i-tam_g : i]
                match = True
                for idx, g_item in enumerate(gatilho_seq):
                    if g_item not in sub_h[idx]:
                        match = False
                        break
                
                if match:
                    acertou_no_ciclo = False
                    g_usado = 0
                    for g in range(mg_ia + 1):
                        if i + g < len(historico_tags):
                            num_seg = str(historico_nums[i + g])
                            tags_seg = historico_tags[i + g]
                            
                            if num_seg in alvos_seq or any(a in tags_seg for a in alvos_seq):
                                acertou_no_ciclo = True
                                g_usado = g
                                break
                        g_usado = g
                
                    if acertou_no_ciclo: greens_bt += 1
                    else: reds_bt += 1
                    
                    i += (g_usado + 1)
                else:
                    i += 1
            
            total_bt = greens_bt + reds_bt
            if total_bt >= 5:
                pct_bt = (greens_bt / total_bt) * 100
                if pct_bt >= min_meta:
                    nova_est_ia = {
                        "gatilho_str": f"🤖 IA Mapeada: {nome_padrao}",
                        "gatilho": gatilho_seq,
                        "ausencia": False,
                        "aposta_str": " ".join(alvos_seq),
                        "alvos": alvos_seq,
                        "max_gales": mg_ia,
                        "mults_gales": mults_ia,
                        "greens": greens_bt,
                        "reds": reds_bt,
                        "pct": pct_bt
                    }
                    if nova_est_ia not in self.estrategias_ia_criadas and nova_est_ia not in self.estrategias:
                        candidatos_gerados.append(nova_est_ia)

        if candidatos_gerados:
            self.estrategias_ia_criadas.extend(candidatos_gerados)
            self.root.after(0, self.atualizar_listbox_estrategias)

    def otimizar_estrategias_com_ia(self, mesa_info):
        if not self.var_auto_ia.get(): return
        min_meta = self.slider_assertividade.get()
        
        modificou = False
        for est in self.estrategias:
            g = est.get("greens", 0)
            r = est.get("reds", 0)
            total = g + r
            
            if total >= 5 and (g / total * 100) < min_meta:
                if not est.get("ausencia") and len(est["gatilho"]) >= 1 and est["gatilho"][0] != "N":
                    est["gatilho"].append(est["gatilho"][-1])
                    est["gatilho_str"] = " ".join(est["gatilho"])
                    modificou = True
                
                elif est.get("ausencia"):
                    try:
                        rodadas_atuais = int(est["gatilho"][1])
                        novo_limite = rodadas_atuais + 2
                        est["gatilho"][1] = str(novo_limite)
                        est["gatilho_str"] = f"Ausência de {est['tag_ausencia']} ({novo_limite} rodadas)"
                        modificou = True
                    except Exception:
                        pass
                        
        if modificou:
            self.salvar_config()
            self.root.after(0, self.atualizar_listbox_estrategias)

    # =========================================================================
    # BACKTEST INICIAL CORRIGIDO PARA G2
    # =========================================================================
    def fazer_backtest_inicial(self, mesa_info):
        try:
            profundidade_alvo = int(self.ent_profundidade_ia.get().strip())
        except ValueError:
            profundidade_alvo = 250

        historico_nums = mesa_info.get("historico_numeros_brutos", [])
        
        if len(historico_nums) > profundidade_alvo:
            historico_nums = historico_nums[-profundidade_alvo:]
            
        total_processado = len(historico_nums)
        self.root.after(0, lambda p=total_processado, t=profundidade_alvo: self.lbl_ia_amostra.config(text=f"📊 Cruzamento de Dados: {p} / {t} rodadas analisadas"))

        if total_processado < 10:
            return
        
        historico_tags = []
        for num in historico_nums:
            historico_tags.append(classificar_numero(num))
        
        mesa_info["historico"] = historico_tags
        mesa_info["memoria_ia"] = historico_tags[-max(25, total_processado):]
        
        top_est_nome = "Nenhuma"
        top_est_pct = -1.0

        for est in self.estrategias:
            greens_backtest = 0
            reds_backtest = 0
            
            tamanho_gatilho = len(est["gatilho"]) if not est.get("ausencia") else 5
            max_gales_sim = est.get("max_gales", 2)
            
            i = tamanho_gatilho
            while i < len(historico_tags):
                sub_hist = historico_tags[i-tamanho_gatilho : i] if not est.get("ausencia") else historico_tags[max(0, i-int(est["gatilho"][1])) : i]
                
                if verificar_gatilho(sub_hist, est):
                    acertou_no_ciclo = False
                    g_usado = 0
                    for g in range(max_gales_sim + 1):
                        if i + g < len(historico_tags):
                            num_seguinte = str(historico_nums[i + g])
                            tags_seguinte = historico_tags[i + g]
                            
                            tokens_aposta = est["aposta_str"].replace(",", " ").split()
                            alvos_verificacao = []
                            for tk_item in tokens_aposta:
                                if tk_item in SETORES_FISICOS: alvos_verificacao.extend([str(n) for n in SETORES_FISICOS[tk_item]])
                                elif tk_item in TERMINAIS_MAP: alvos_verificacao.extend(TERMINAIS_MAP[tk_item])
                                else: alvos_verificacao.append(tk_item)
                            
                            if num_seguinte in alvos_verificacao or any(alvo in tags_seguinte for alvo in est["alvos"]):
                                acertou_no_ciclo = True
                                g_usado = g
                                break
                            g_usado = g
                            
                    if acertou_no_ciclo: greens_backtest += 1
                    else: reds_backtest += 1
                    i += (g_usado + 1)
                else:
                    i += 1
            
            est["greens"] = greens_backtest
            est["reds"] = reds_backtest
            total = greens_backtest + reds_backtest
            pct = (greens_backtest / total * 100) if total > 0 else 0.0
            
            if pct > top_est_pct and total >= 3:
                top_est_pct = pct
                top_est_nome = est["gatilho_str"]
        
        if top_est_pct >= 0:
            self.root.after(0, lambda n=top_est_nome, p=top_est_pct: self.lbl_ia_top_est.config(text=f"🏆 Líder do Backtest: [{n[:20]}] ({p:.1f}%)"))

        self.otimizar_estrategias_com_ia(mesa_info)
        self.minerar_estrategias_autonomas_ia(historico_tags, historico_nums)

        self.root.after(0, self.atualizar_listbox_estrategias)

    def atualizar_listbox_estrategias(self):
        self.listbox_estrategias.delete(0, tk.END)
        todas_as_est = self.estrategias + self.estrategias_ia_criadas
        for idx, est in enumerate(todas_as_est):
            g = est.get("greens", 0)
            r = est.get("reds", 0)
            total = g + r
            pct = (g / total * 100) if total > 0 else 0.0
            tipo_label = " [IA]" if "🤖" in est['gatilho_str'] else (" [AUSÊNCIA]" if est.get("ausencia") else "")
            mg = est.get("max_gales", 2)
            self.listbox_estrategias.insert(tk.END, f"[{idx+1}]{tipo_label} {est['gatilho_str']} ➔ {est['aposta_str']} [Gales:{mg}] | [G:{g} R:{r} | {pct:.1f}%]")

    def adicionar_estrategia_multi(self):
        g_raw = self.ent_gatilhos_multi.get().strip().upper()
        a_raw = self.ent_apostas_multi.get().strip().upper()
        is_ausencia = self.var_ausencia.get()

        if not g_raw or not a_raw:
            return messagebox.showwarning("Aviso", "Preencha os gatilhos e as multi-apostas!")

        g_list = g_raw.replace(",", " ").split()
        a_list = a_raw.replace(",", " ").split()

        if is_ausencia:
            tag_alvo = g_list[0] if len(g_list) > 0 else "P1"
            rodadas = g_list[1] if len(g_list) > 1 and g_list[1].isdigit() else "6"
            gatilho_str = f"Ausência de {tag_alvo} ({rodadas} rodadas)"
            gatilho_interno = [tag_alvo, rodadas]
        else:
            gatilho_str = " ".join(g_list)
            gatilho_interno = g_list

        aposta_str = " ".join(a_list)

        try:
            max_gales_est = int(self.ent_max_gales.get().strip())
        except ValueError:
            max_gales_est = 2

        mults_est = [ent.get().strip() for ent in self.mult_entries]

        nova_est = {
            "gatilho_str": gatilho_str, 
            "gatilho": gatilho_interno, 
            "ausencia": is_ausencia,
            "tag_ausencia": g_list[0] if is_ausencia else "",
            "aposta_str": aposta_str, 
            "alvos": a_list, 
            "max_gales": max_gales_est,
            "mults_gales": mults_est,
            "greens": 0, 
            "reds": 0
        }
        self.estrategias.append(nova_est)
        self.salvar_config()
        self.atualizar_listbox_estrategias()
        self.registrar_log(f"Estratégia Adicionada: [{gatilho_str} ➔ {aposta_str}]")

    def favoritar_estrategia_atual(self):
        g_raw = self.ent_gatilhos_multi.get().strip().upper()
        a_raw = self.ent_apostas_multi.get().strip().upper()
        if not g_raw or not a_raw:
            return messagebox.showwarning("Aviso", "Preencha os campos para favoritar!")

        favs = []
        if os.path.exists(FAVORITOS_FILE):
            try:
                with open(FAVORITOS_FILE, "r", encoding="utf-8") as f:
                    favs = json.load(f)
            except Exception:
                pass

        try:
            mg = int(self.ent_max_gales.get().strip())
        except ValueError:
            mg = 2
        m_list = [ent.get().strip() for ent in self.mult_entries]

        nova_fav = {"gatilho_str": g_raw, "aposta_str": a_raw, "ausencia": self.var_ausencia.get(), "max_gales": mg, "mults_gales": m_list}
        if nova_fav not in favs:
            favs.append(nova_fav)
            with open(FAVORITOS_FILE, "w", encoding="utf-8") as f:
                json.dump(favs, f, indent=4)
            messagebox.showinfo("Sucesso", "⭐ Estratégia favoritada!")
            self.registrar_log(f"Estratégia favoritada: [{g_raw} ➔ {a_raw}]")
        else:
            messagebox.showinfo("Aviso", "Esta estratégia já está nos favoritos!")

    def remover_estrategia_selecionada(self):
        selecao = self.listbox_estrategias.curselection()
        if not selecao:
            return messagebox.showwarning("Aviso", "Selecione uma estratégia na lista para remover!")
        idx = selecao[0]
        todas = self.estrategias + self.estrategias_ia_criadas
        removida = todas[idx]
        if removida in self.estrategias:
            self.estrategias.remove(removida)
            self.salvar_config()
        else:
            self.estrategias_ia_criadas.remove(removida)
            
        self.atualizar_listbox_estrategias()
        self.registrar_log(f"Estratégia removida: [{removida['gatilho_str']} ➔ {removida['aposta_str']}]")

    def atualizar_placar(self):
        with self.placar_lock:
            t = self.greens + self.reds
            a = (self.greens / t * 100) if t > 0 else 0
            banca_atual = self.banca_virtual + self.lucro_virtual
        
        sinal_lucro = "+" if self.lucro_virtual >= 0 else "-"
        self.root.after(0, lambda: [
            self.lbl_placar.config(text=f"GREENS {self.greens}   •   REDS {self.reds}   •   ASSERTIVIDADE {a:.1f}%"),
            self.lbl_banca_virtual.config(text=f"BANCA VIRTUAL  R$ {banca_atual:.2f}   •   LUCRO  {sinal_lucro}R$ {abs(self.lucro_virtual):.2f}")
        ])
        return a

    def enviar_relatorio_sessao(self, motivo, assertividade):
        if not self.hora_inicio: return
        t = datetime.now() - self.hora_inicio
        m, s = divmod(t.seconds, 60)
        banca_atual = self.banca_virtual + self.lucro_virtual
        sinal_lucro_sessao = "+" if self.lucro_virtual >= 0 else "-"
        msg = (
            f"🏁 *SESSÃO ENCERRADA ({APP_NOME} {APP_VERSAO})*\n"
            f"Motivo: {motivo}\n\n"
            f"✅ *Greens:* {self.greens}\n"
            f"❌ *Reds:* {self.reds}\n"
            f"🎯 *Assertividade:* {assertividade:.1f}%\n"
            f"💵 *Lucro Líquido:* {sinal_lucro_sessao}R$ {abs(self.lucro_virtual):.2f}\n"
            f"💰 *Banca Atual:* R$ {banca_atual:.2f}\n"
            f"📊 *Placar Geral:* `[G: {self.greens} | R: {self.reds}]`\n"
            f"⏱️ *Tempo:* {m}m {s}s"
        )
        self.enviar_tg_notificacao(msg)

    def toggle_bot(self):
        if not self.estrategias and not self.var_auto_ia.get() and not self.var_sniper.get() and not self.var_term_dinamico.get(): 
            return messagebox.showwarning("Aviso", "Ative a Auto-IA G2, Sniper, IA Terminais ou adicione estratégias!")
        
        if not self.rodando:
            mesa_selecionada = self.combo_mesas.get()
            if not mesa_selecionada or mesa_selecionada not in self.links_mesas:
                return messagebox.showwarning("Aviso", "Selecione uma roleta válida na lista!")

            self.rodando = True
            with self.placar_lock:
                self.greens = 0
                self.reds = 0
                self.reds_consecutivos = 0
                self.valor_recuperacao = 0.0 
                try:
                    self.banca_virtual = float(self.ent_banca_inicial.get())
                except ValueError:
                    self.banca_virtual = 500.0
                self.lucro_virtual = 0.0
                self.entradas_sessao = []
                self.greens_por_gale = {}
                self.reds_por_gale = {}

            self.atualizar_metricas_gale_ui({})
            if self.radar is not None:
                try:
                    if self.radar.top.winfo_exists():
                        self.radar.limpar_historico_entradas()
                except Exception as e:
                    logging.error(f"Erro ao limpar o painel da roleta: {e}")

            for est in self.estrategias + self.estrategias_ia_criadas:
                est["greens"] = 0
                est["reds"] = 0
            self.salvar_config()
            self.atualizar_listbox_estrategias()

            self.hora_inicio = datetime.now()
            self.atualizar_placar()
            self.btn_iniciar.config(text="⏹ PARAR OPERAÇÕES", bg=self.red)
            
            modo_atual = self.var_modo.get()
            banca_atual = self.banca_virtual + self.lucro_virtual
            msg_inicio = (
                f"💰 *{APP_NOME} {APP_VERSAO} LIGADO!*\n"
                f"🎯 Mesa: `{mesa_selecionada}` | Modo: `{modo_atual}`\n"
                f"🛡️ Filtro IA Slider: `{self.slider_assertividade.get():.0f}%`\n"
                f"💵 *Banca Inicial:* R$ {banca_atual:.2f}"
            )
            self.enviar_tg_notificacao(msg_inicio)
            self.registrar_log(f"Iniciando operação na mesa: {mesa_selecionada}")
            self.lbl_ia_analise.config(text="ANÁLISE: Conectando à mesa...", fg=self.cyan)
            
            threading.Thread(target=self.loop_monitoramento_mesa, args=(self.links_mesas[mesa_selecionada], mesa_selecionada), daemon=True).start()
        else:
            self.rodando = False
            self.exportar_relatorio_sessao("Encerrada manualmente pelo operador")
            with self.placar_lock:
                self.greens = 0
                self.reds = 0
                self.reds_consecutivos = 0
                self.lucro_virtual = 0.0
                self.entradas_sessao = []

            for est in self.estrategias + self.estrategias_ia_criadas:
                est["greens"] = 0
                est["reds"] = 0
            self.salvar_config()
            self.atualizar_listbox_estrategias()

            self.atualizar_placar()
            self.btn_iniciar.config(text="▶  INICIAR AUTO-BET", bg=self.green)
            self.lbl_sinal_status.config(text="● ROBÔ PAUSADO PELO OPERADOR", fg=self.muted)
            self.lbl_ia_analise.config(text="ANÁLISE: Pausado.", fg=self.muted)
            self.registrar_log("Operações pausadas manualmente.")

    def verificar_sinais_ativos(self, page, mesa_info, tags_rodada, numero_rodada):
        sinais_restantes = []
        nome_mesa = mesa_info["nome"]
        modo_atual = self.var_modo.get()

        try:
            ficha_base_orig = float(self.ent_valor_ficha.get())
        except ValueError:
            ficha_base_orig = 1.0

        if self.var_recuperacao.get() and self.valor_recuperacao > 0:
            incremento_recup = (self.valor_recuperacao / 5.0) 
            if incremento_recup > ficha_base_orig * 2: 
                incremento_recup = ficha_base_orig * 2
            ficha_base = ficha_base_orig + incremento_recup
        else:
            ficha_base = ficha_base_orig

        for sinal in mesa_info["sinais"]:
            est_obj = sinal.get("est_obj")
            max_gales_est = sinal.get("max_gales", 2)
            mults_valores = sinal.get("mults_gales", ["2x", "4x", "8x", "16x", "32x", "64x"])
            
            acertou = False
            tokens_aposta = sinal["aposta_str"].replace(",", " ").split()
            alvos_verificacao = []
            for tk_item in tokens_aposta:
                if tk_item in SETORES_FISICOS:
                    alvos_verificacao.extend([str(n) for n in SETORES_FISICOS[tk_item]])
                elif tk_item in TERMINAIS_MAP:
                    alvos_verificacao.extend(TERMINAIS_MAP[tk_item])
                else:
                    alvos_verificacao.append(tk_item)

            if str(numero_rodada) in alvos_verificacao:
                acertou = True
            elif any(alvo in tags_rodada for alvo in sinal["alvos"]):
                acertou = True

            if acertou:
                with self.placar_lock:
                    self.greens += 1
                    self.reds_consecutivos = 0  
                    
                    # =================================================================
                    # NOVO MOTOR QUANTITATIVO DE PAYOUT (HEDGE E FICHAS MISTAS)
                    # =================================================================
                    total_fichas_apostadas = 0
                    premio_bruto_unitario = 0

                    for tk_item in tokens_aposta:
                        # 1. Mapeia a ficha e o multiplicador exato dela
                        if tk_item in SETORES_FISICOS:
                            fichas_do_token = len(SETORES_FISICOS[tk_item])
                            alvos_do_token = [str(n) for n in SETORES_FISICOS[tk_item]]
                            mult_do_token = 36
                        elif tk_item in TERMINAIS_MAP:
                            fichas_do_token = len(TERMINAIS_MAP[tk_item])
                            alvos_do_token = TERMINAIS_MAP[tk_item]
                            mult_do_token = 36
                        else:
                            fichas_do_token = 1
                            alvos_do_token = [tk_item]
                            if tk_item in ["B", "R", "P", "O", "L", "H"]:
                                mult_do_token = 2
                            elif tk_item in ["D1", "D2", "D3", "C1", "C2", "C3"]:
                                mult_do_token = 3
                            else:
                                mult_do_token = 36
                        
                        total_fichas_apostadas += fichas_do_token

                        # 2. Se ESTA ficha específica ganhou, soma o prêmio dela!
                        if str(numero_rodada) in alvos_do_token or any(alvo in tags_rodada for alvo in alvos_do_token):
                            premio_bruto_unitario += mult_do_token

                    # Calcular custo de todos os níveis de gale acumulados
                    custo_acumulado = 0
                    start_gale = 1 if (self.var_modo_fantasma.get() and modo_atual == "Automático") else 0
                    
                    for g_idx in range(start_gale, sinal["gale_atual"] + 1):
                        if g_idx == 0:
                            f_val = 1
                        else:
                            m_s = mults_valores[g_idx - 1].replace("x", "") if (g_idx - 1) < len(mults_valores) else "2"
                            try: f_val = float(m_s)
                            except ValueError: f_val = 2 ** g_idx
                        custo_acumulado += total_fichas_apostadas * ficha_base * f_val

                    # Fator multiplicador do gale na rodada atual
                    fator_gale_atual = 1
                    if sinal["gale_atual"] > 0:
                        idx_m = sinal["gale_atual"] - 1
                        m_str = mults_valores[idx_m].replace("x", "") if idx_m < len(mults_valores) else "2"
                        try: fator_gale_atual = float(m_str)
                        except ValueError: fator_gale_atual = 2 ** sinal["gale_atual"]

                    if sinal["gale_atual"] == 0 and self.var_modo_fantasma.get() and modo_atual == "Automático":
                        lucro_liquido = 0
                        self.registrar_log("👻 GREEN Virtual (Modo Fantasma).")
                    else:
                        # Cálculo Institucional: Soma real de todos os prêmios * ficha * gale
                        premio_bruto = premio_bruto_unitario * (ficha_base * fator_gale_atual)
                        lucro_liquido = premio_bruto - custo_acumulado
                    # =================================================================
                        
                    self.lucro_virtual += lucro_liquido
                    
                    if self.var_recuperacao.get() and self.valor_recuperacao > 0:
                        self.valor_recuperacao -= lucro_liquido
                        if self.valor_recuperacao < 0: self.valor_recuperacao = 0
                        
                    banca_atual = self.banca_virtual + self.lucro_virtual
                
                if est_obj:
                    est_obj["greens"] = est_obj.get("greens", 0) + 1
                    self.salvar_config()
                    self.root.after(0, self.atualizar_listbox_estrategias)
                
                # Bloqueio de Loop de Cooldown
                if sinal.get("is_termo"):
                    mesa_info["ultimo_alvo_term"] = sinal["alvo_central"]
                    mesa_info["cooldown_term"] = 5
                elif sinal.get("alvo_central") is not None:
                    mesa_info["ultimo_alvo_sniper"] = sinal["alvo_central"]
                    mesa_info["cooldown_sniper"] = 5

                self.registrar_entrada_sessao(
                    sinal.get("nome", sinal.get("gatilho_str", "Estratégia")),
                    numero_rodada, "GREEN", sinal["gale_atual"], lucro_liquido
                )

                sinal_lucro = "+" if lucro_liquido >= 0 else "-"
                origem = "ENTRADA DIRETA" if sinal["gale_atual"] == 0 else f"GALE {sinal['gale_atual']}"
                self.root.after(0, lambda nm=nome_mesa, s=sinal: self.lbl_sinal_status.config(text=f"🟢 GREEN ({nm})! Alvo: {s['aposta_str']}", fg=self.green))
                
                self.registrar_log(f"✅ GREEN! Sorteado: {numero_rodada} | Custo: R$ {custo_acumulado:.2f} | Lucro: {sinal_lucro}R$ {abs(lucro_liquido):.2f}")
                
                msg_green = (
                    f"✅ *GREEN CONFIRMADO!* 🟢\n"
                    f"🎰 *Mesa:* `{nome_mesa}`\n"
                    f"🎯 *Estratégia:* `{sinal['gatilho_str']}`\n"
                    f"💰 *Alvo Vencedor:* `{sinal['aposta_str']}`\n"
                    f"🎲 *Número Sorteado:* `{numero_rodada}`\n"
                    f"💵 *Lucro Líquido:* `{sinal_lucro}R$ {abs(lucro_liquido):.2f}`\n"
                    f"💰 *Banca Atual:* `R$ {banca_atual:.2f}`\n"
                    f"📊 *Placar:* `[G: {self.greens} | R: {self.reds}]`\n"
                    f"📈 *Origem:* `{origem}`"
                )
                self.enviar_tg_notificacao(msg_green)
            else:
                if modo_atual == "Manual":
                    self.registrar_log(f"ℹ️ [Modo Manual] Gale {sinal['gale_atual']} atingido, sem apostas automáticas.")
                    sinais_restantes.append(sinal)
                else:
                    total_fichas_temp = 0
                    for tk_item in tokens_aposta:
                        if tk_item in SETORES_FISICOS:
                            total_fichas_temp += len(SETORES_FISICOS[tk_item])
                        elif tk_item in TERMINAIS_MAP:
                            total_fichas_temp += len(TERMINAIS_MAP[tk_item])
                        else:
                            total_fichas_temp += 1

                    custo_passado = 0
                    start_gale = 1 if self.var_modo_fantasma.get() else 0
                    
                    for g_idx in range(start_gale, sinal["gale_atual"] + 1): 
                        if g_idx == 0:
                            f_val = 1
                        else:
                            m_s = mults_valores[g_idx - 1].replace("x", "") if (g_idx - 1) < len(mults_valores) else "2"
                            try: f_val = float(m_s)
                            except ValueError: f_val = 2 ** g_idx
                        custo_passado += total_fichas_temp * ficha_base * f_val
                        
                    proximo_gale_idx = sinal["gale_atual"] + 1
                    m_prox = mults_valores[proximo_gale_idx - 1].replace("x", "") if (proximo_gale_idx - 1) < len(mults_valores) else "2"
                    try: f_val_prox = float(m_prox)
                    except ValueError: f_val_prox = 2 ** proximo_gale_idx
                    
                    custo_deste_gale = total_fichas_temp * ficha_base * f_val_prox
                    custo_total_ciclo_se_jogar = custo_passado + custo_deste_gale
                    
                    try:
                        limite_stop_loss = float(self.ent_stop_loss_brl.get())
                    except ValueError:
                        limite_stop_loss = 25.0
                        
                    atingiu_stop_flutuante = custo_total_ciclo_se_jogar >= abs(limite_stop_loss)

                    if sinal["gale_atual"] < max_gales_est and not atingiu_stop_flutuante:
                        sinal["gale_atual"] += 1
                        idx_mult = sinal["gale_atual"] - 1
                        mult_atual = mults_valores[idx_mult] if idx_mult < len(mults_valores) else "2x"
                        
                        try:
                            cliques_gale = int(mult_atual.replace("x", ""))
                        except ValueError:
                            cliques_gale = 2 ** sinal["gale_atual"]
                            
                        self.root.after(0, lambda nm=nome_mesa, s=sinal, m=mult_atual: self.lbl_sinal_status.config(text=f"⚠️ GALE {s['gale_atual']} ({m}) [{nm}]! ALVO: {s['aposta_str']}", fg=self.amber))
                        self.tocar_alerta()
                        
                        self.registrar_log(f"⚠️ GALE {sinal['gale_atual']} ({mult_atual}) acionado. Sorteado: {numero_rodada}")
                        
                        lucro_parcial = self.lucro_virtual - custo_passado - custo_deste_gale
                        banca_atual_pos_gale = self.banca_virtual + lucro_parcial
                        
                        msg_gale = (
                            f"⚠️ *ENTRADA EM GALE {sinal['gale_atual']} (Fator {mult_atual})!* 🟠\n"
                            f"🎰 *Mesa:* `{nome_mesa}`\n"
                            f"🎯 *Estratégia:* `{sinal['gatilho_str']}`\n"
                            f"💰 *Alvo Multiplicado ({mult_atual}):* `{sinal['aposta_str']}`\n"
                            f"🎲 *Número Anterior:* `{numero_rodada}`\n"
                            f"💵 *Banca Atual:* `R$ {banca_atual_pos_gale:.2f}`"
                        )
                        self.enviar_tg_notificacao(msg_gale)
                        
                        if not executar_aposta_real(page, sinal["aposta_str"], cliques_gale):
                            self.registrar_log("⚠️ APOSTA FALHOU: Alvos indisponíveis no Chrome.")

                        sinais_restantes.append(sinal)
                    else:
                        motivo_red = "LIMITES DE GALE ATINGIDO" if not atingiu_stop_flutuante else f"STOP LOSS DE R$ {-abs(limite_stop_loss):.2f} IMPEDIU O GALE {proximo_gale_idx} (Custo Total R$ {custo_total_ciclo_se_jogar:.2f})"
                        
                        with self.placar_lock:
                            self.reds += 1
                            self.reds_consecutivos += 1
                            
                            prejuizo_ciclo = custo_passado
                            self.lucro_virtual -= prejuizo_ciclo
                            
                            if self.var_recuperacao.get():
                                self.valor_recuperacao += prejuizo_ciclo
                                
                            banca_atual = self.banca_virtual + self.lucro_virtual
                        
                        if est_obj:
                            est_obj["reds"] = est_obj.get("reds", 0) + 1
                            self.salvar_config()
                            self.root.after(0, self.atualizar_listbox_estrategias)

                        # Bloqueio de Loop de Cooldown
                        if sinal.get("is_termo"):
                            mesa_info["ultimo_alvo_term"] = sinal["alvo_central"]
                            mesa_info["cooldown_term"] = 5
                        elif sinal.get("alvo_central") is not None:
                            mesa_info["ultimo_alvo_sniper"] = sinal["alvo_central"]
                            mesa_info["cooldown_sniper"] = 5

                        self.registrar_entrada_sessao(
                            sinal.get("nome", sinal.get("gatilho_str", "Estratégia")),
                            numero_rodada, "RED", sinal["gale_atual"], -prejuizo_ciclo
                        )

                        self.root.after(0, lambda nm=nome_mesa, s=sinal: self.lbl_sinal_status.config(text=f"🔴 RED ({nm})! Alvo era: {s['aposta_str']}", fg=self.red))
                        
                        motivo_curto = motivo_red.split(' IMPEDIU')[0]
                        self.registrar_log(f"❌ RED! Sorteado: {numero_rodada} | Loss: -R$ {prejuizo_ciclo:.2f} ({motivo_curto})")
                        
                        msg_red = (
                            f"❌ *RED REGISTRADO!* 🔴\n"
                            f"🎰 *Mesa:* `{nome_mesa}`\n"
                            f"🎯 *Estratégia:* `{sinal['gatilho_str']}`\n"
                            f"💰 *Alvo que Falhou:* `{sinal['aposta_str']}`\n"
                            f"🎲 *Número Sorteado:* `{numero_rodada}`\n"
                            f"💸 *Prejuízo do Ciclo:* `-R$ {prejuizo_ciclo:.2f}`\n"
                            f"🛑 *Motivo:* `{motivo_red}`\n"
                            f"💰 *Banca Atual:* `R$ {banca_atual:.2f}`\n"
                            f"📊 *Placar:* `[G: {self.greens} | R: {self.reds}]`"
                        )
                        self.enviar_tg_notificacao(msg_red)
        
        mesa_info["sinais"] = sinais_restantes

    def loop_monitoramento_mesa(self, url_mesa, nome_mesa):
        ok, msg_chrome = iniciar_chrome_automatico()
        if ok: self.registrar_log(f"🌐 {msg_chrome}")
        else: self.registrar_log(f"⚠️ {msg_chrome} (Tentando conectar via CDP mesmo assim...)")

        try: stop_win = float(self.ent_stop_win.get())
        except ValueError: stop_win = 15.0

        try: stop_loss_brl = float(self.ent_stop_loss_brl.get())
        except ValueError: stop_loss_brl = 25.0

        try: max_reds_permitidos = int(self.ent_max_reds.get())
        except ValueError: max_reds_permitidos = 2

        with sync_playwright() as p:
            def _entrar_na_mesa(ctx):
                """Abre a mesa em uma aba nova e confirma o botão Jogar."""
                nova_page = ctx.new_page()
                nova_page.goto(url_mesa, timeout=30000)
                time.sleep(2)
                for _ in range(10):
                    try:
                        jogar_btn = nova_page.locator('text="Jogar"').first
                        if jogar_btn.count() > 0 and jogar_btn.is_visible():
                            jogar_btn.click(force=True)
                            time.sleep(5)
                            break
                    except Exception:
                        pass
                    time.sleep(2)
                return nova_page

            def _reconectar_mesa(page_atual, ctx_atual):
                """Blindagem: recarrega a mesa e, se o frame/contexto caiu, reabre a aba via CDP."""
                try:
                    if page_atual is not None and not page_atual.is_closed():
                        page_atual.reload(timeout=30000)
                        time.sleep(5)
                        for _ in range(3):
                            jb = page_atual.locator('text="Jogar"').first
                            if jb.count() > 0 and jb.is_visible():
                                jb.click(force=True)
                                time.sleep(3)
                                break
                        return page_atual, ctx_atual
                except Exception as e:
                    logging.error(f"Reload da mesa falhou, reabrindo contexto: {e}")

                try:
                    if page_atual is not None and not page_atual.is_closed():
                        page_atual.close()
                except Exception:
                    pass

                try:
                    novo_browser = p.chromium.connect_over_cdp("http://127.0.0.1:9222")
                    novo_ctx = novo_browser.contexts[0]
                    return _entrar_na_mesa(novo_ctx), novo_ctx
                except Exception as e:
                    logging.error(f"Reconexão CDP falhou: {e}")
                    return None, ctx_atual

            try:
                browser = p.chromium.connect_over_cdp("http://127.0.0.1:9222")
                context = browser.contexts[0]
                page = _entrar_na_mesa(context)

                self.root.after(0, lambda: self.lbl_sinal_status.config(text=f"🟢 MONITORANDO: {nome_mesa}", fg=self.green))
            except Exception as e:
                logging.error(f"Erro ao abrir roleta: {e}")
                self.rodando = False
                self.root.after(0, lambda: self.btn_iniciar.config(text="▶  INICIAR AUTO-BET", bg=self.green))
                self.root.after(0, lambda: self.lbl_sinal_status.config(text="❌ ERRO AO ABRIR MESA", fg=self.red))
                return

            mesa_info = {
                "nome": nome_mesa, 
                "historico": [], 
                "historico_numeros_brutos": [], 
                "memoria_ia": [], 
                "ultimo_numero": None, 
                "sinais": [],
                "cooldown_sniper": 0,
                "ultimo_alvo_sniper": None,
                "cooldown_term": 0,
                "ultimo_alvo_term": None
            }
            
            numeros_iniciais = self.extrair_historico_inicial(page)
            if numeros_iniciais:
                self.registrar_log(f"📥 Histórico lido! ({len(numeros_iniciais)} números).")
                mesa_info["historico_numeros_brutos"] = numeros_iniciais
                self.fazer_backtest_inicial(mesa_info)
                
                self.root.after(0, self._desenhar_roleta_ao_vivo, mesa_info)

                memoria_str = " - ".join([str(n) for n in mesa_info["historico_numeros_brutos"][-10:]]) if mesa_info["historico_numeros_brutos"] else " Vazio "
                self.root.after(0, lambda m=memoria_str: self.lbl_ia_memoria.config(text=f"MEMÓRIA RAM VISUAL  •  [ {m} ]"))
            else:
                self.registrar_log("⚠️ Histórico não detectado. Iniciando leitura ao vivo.")

            tempo_ultima_atividade = time.time()

            while self.rodando:
                atingiu_stop_win = self.lucro_virtual >= stop_win
                atingiu_stop_loss_fin = self.lucro_virtual <= (-abs(stop_loss_brl))
                atingiu_max_reds = self.reds_consecutivos >= max_reds_permitidos

                if atingiu_stop_win or atingiu_stop_loss_fin or atingiu_max_reds:
                    if atingiu_stop_win:
                        motivo = f"🏆 Stop Win Virtual (R$ {stop_win:.2f}) Alcançado"
                        cor_status = self.green
                    elif atingiu_stop_loss_fin:
                        motivo = f"🛑 Stop Loss Financeiro (R$ {stop_loss_brl:.2f}) Atingido"
                        cor_status = self.red
                    else:
                        motivo = f"🛑 Stop Operacional ({max_reds_permitidos} Reds Seguidos) Atingido"
                        cor_status = self.red

                    self.root.after(0, lambda m=motivo, c=cor_status: self.lbl_sinal_status.config(text=f"🎉 {m}!", fg=c))
                    self.tocar_alerta()
                    self.salvar_auditoria(motivo)
                    self.enviar_relatorio_sessao(motivo, self.atualizar_placar())
                    self.exportar_relatorio_sessao(motivo)
                    self.rodando = False
                    self.root.after(0, lambda: self.btn_iniciar.config(text="▶  INICIAR AUTO-BET", bg=self.green))
                    break

                # BLINDAGEM: sem leitura nova por muito tempo = frame travado/queda de conexão
                if time.time() - tempo_ultima_atividade > TIMEOUT_SEM_LEITURA:
                    self.registrar_log(f"🔌 CHROME: {TIMEOUT_SEM_LEITURA}s sem novos números. Reconectando a mesa...")
                    page, context = _reconectar_mesa(page, context)
                    tempo_ultima_atividade = time.time()
                    if page is None:
                        self.registrar_log("⚠️ CHROME: reconexão indisponível. Nova tentativa em 10s.")
                        time.sleep(10)
                        continue
                    self.registrar_log("🟢 CHROME: mesa reconectada, leitura retomada.")

                try:
                    if page.is_closed():
                        self.registrar_log("A aba da roleta foi fechada.")
                        break

                    numero = extrair_ultimo_numero(page)
                    if numero is not None and numero != mesa_info["ultimo_numero"]:
                        tempo_ultima_atividade = time.time()
                        mesa_info["ultimo_numero"] = numero
                        tags = classificar_numero(numero)
                        
                        # Respiro do Cooldown
                        if mesa_info.get("cooldown_sniper", 0) > 0:
                            mesa_info["cooldown_sniper"] -= 1
                        if mesa_info.get("cooldown_term", 0) > 0:
                            mesa_info["cooldown_term"] -= 1

                        self.root.after(0, lambda n=numero, t=tags: self.lbl_ia_leitura.config(text=f"{n} | {' '.join(t)}"))
                        
                        mesa_info["historico"].append(tags)
                        mesa_info["memoria_ia"].append(tags)
                        if "historico_numeros_brutos" in mesa_info:
                            mesa_info["historico_numeros_brutos"].append(numero)
                        
                        self.salvar_historico_csv(nome_mesa, numero, tags)

                        try: prof_dinamica = int(self.ent_profundidade_ia.get().strip())
                        except ValueError: prof_dinamica = 250
                            
                        if len(mesa_info["memoria_ia"]) > max(25, prof_dinamica): mesa_info["memoria_ia"].pop(0)
                        if len(mesa_info["historico"]) > prof_dinamica: mesa_info["historico"].pop(0)

                        total_processado_agora = len(mesa_info["historico"])
                        self.root.after(0, lambda p=total_processado_agora, t=prof_dinamica: self.lbl_ia_amostra.config(text=f"{p} / {t} rodadas"))

                        historico_numeros_recentes = [str(tag_list[0]) for tag_list in mesa_info["historico"][-10:]]
                        memoria_str = " - ".join(historico_numeros_recentes)
                        self.root.after(0, lambda m=memoria_str: self.lbl_ia_memoria.config(text=f"MEMÓRIA RAM VISUAL  •  [ {m} ]"))

                        term = next((t for t in tags if t.startswith('T') and len(t) == 2), "")
                        setor = next((t for t in tags if t.startswith('P') and len(t) == 2), "")
                        outros = " ".join([t for t in tags[1:] if t not in (term, setor)])
                        self.registrar_log(f"🎲 Giro: {numero} | {term} | {setor} | {outros}")

                        # 1. PROCESSA SINAIS (WIN/LOSS)
                        if mesa_info["sinais"]:
                            self.verificar_sinais_ativos(page, mesa_info, tags, numero)
                            self.atualizar_placar()

# 2. SE NÃO TEM SINAL, E BATE O SLIDER, TENTA DISPARAR NOVA IA
                        if self.lucro_virtual < stop_win and self.lucro_virtual > (-abs(stop_loss_brl)) and self.reds_consecutivos < max_reds_permitidos:
                            if not mesa_info["sinais"]:
                                sinal_disparo = None

                                # HIERARQUIA DE GATILHOS: 1º customizadas/laboratório, 2º Sniper, 3º IA Termo-Física
                                for est in self.estrategias:
                                    if verificar_gatilho(mesa_info["historico"], est):
                                        sinal_disparo = {
                                            "nome": est.get("nome", est.get("gatilho_str", "Estratégia Custom")),
                                            "gatilho_str": est["gatilho_str"],
                                            "aposta_str": est["aposta_str"],
                                            "alvos": est["alvos"],
                                            "max_gales": est.get("max_gales", 2),
                                            "mults_gales": est.get("mults_gales", ["2x", "4x", "8x", "16x", "32x", "64x"]),
                                            "est_obj": est,
                                            "gale_atual": 0,
                                            "pct": 100.0  # Meramente visual para o painel
                                        }
                                        break
                                
                                if not sinal_disparo and self.var_sniper.get():
                                    sinal_disparo = self.analisar_numeros_plenos_sniper(mesa_info)

                                if not sinal_disparo and hasattr(self, 'var_term_dinamico') and self.var_term_dinamico.get():
                                    sinal_disparo = self.analisar_terminais_dinamicos(mesa_info)
                                    
                                if sinal_disparo:
                                    self.root.after(0, lambda: self.lbl_sinal_status.config(text=f"🔥 SINAL APROVADO! ({nome_mesa})", fg=self.amber))
                                    self.tocar_alerta()
                                    
                                    self.registrar_log(f"🔥 SINAL ENVIADO: {len(sinal_disparo['alvos'])} fichas focadas no alvo {sinal_disparo.get('alvo_central', '')}")

                                    if self.var_modo.get() == "Automático":
                                        msg_analise = (f"🔥 *NOVO SINAL VALIDADO!* 🚀\n"
                                                       f"🎰 *Mesa:* `{nome_mesa}`\n"
                                                       f"🧠 *Gatilho:* `{sinal_disparo['gatilho_str']}`\n"
                                                       f"🎯 *Aposta Escolhida:* `{sinal_disparo['aposta_str']}`\n"
                                                       f"🎲 *Último Número:* `{numero}`")
                                        self.enviar_tg_notificacao(msg_analise)

                                        if self.var_modo_fantasma.get():
                                            pass
                                        else:
                                            if executar_aposta_real(page, sinal_disparo["aposta_str"]):
                                                self.registrar_log("🖱️ CHROME: Aposta Real Confirmada no alvo!")
                                    else:
                                        msg_analise = (f"🎯 *SINAL DE ENTRADA (MODO SINAIS)* 🔔\n"
                                                       f"🎰 *Mesa:* `{nome_mesa}`\n"
                                                       f"🧠 *Gatilho:* `{sinal_disparo['gatilho_str']}`\n"
                                                       f"💰 *Aposta Sugerida:* `{sinal_disparo['aposta_str']}`")
                                        self.enviar_tg_notificacao(msg_analise)

                                    sinal_disparo["gale_atual"] = 0
                                    sinal_disparo["est_obj"] = None
                                    mesa_info["sinais"].append(sinal_disparo)

                        # 3. ATUALIZA A TELA DO RADAR *DEPOIS* DE DECIDIR SE VAI APOSTAR! (SINCRONIA)
                        self.root.after(0, self._desenhar_roleta_ao_vivo, mesa_info)
                                    
                except Exception as e:
                    logging.error(f"Erro no loop de monitoramento: {e}")
                    pass
                
                time.sleep(1.0)
            
            try:
                if page is not None:
                    page.close()
            except Exception: pass
            self.registrar_log("Sessão autônoma finalizada.")

    def abrir_laboratorio_backtest(self):
        """Abre a janela do Laboratório de Backtest"""
        LaboratorioBacktest(self.root, self)

class LaboratorioBacktest:
    def __init__(self, master, app_ref):
        self.app = app_ref
        self.top = tk.Toplevel(master)
        self.top.title(f"{APP_NOME} • Backtest Engine")
        self.top.geometry("600x500")
        self.top.configure(bg="#070A10")
        self.top.protocol("WM_DELETE_WINDOW", self.fechar)

        # Paleta de cores consistente com o app principal
        self.bg = "#070A10"
        self.panel = "#0D111B"
        self.panel2 = "#111827"
        self.panel3 = "#0A0F17"
        self.border = "#1E293B"
        self.text = "#E5E7EB"
        self.muted = "#718096"
        self.cyan = "#22D3EE"
        self.green = "#34D399"
        self.amber = "#FBBF24"
        self.red = "#FB7185"
        self.purple = "#A78BFA"

        # Container principal
        main_frame = tk.Frame(self.top, bg=self.bg)
        main_frame.pack(fill="both", expand=True, padx=16, pady=16)

        # Header
        header = tk.Frame(main_frame, bg=self.bg)
        header.pack(fill="x", pady=(0, 12))
        tk.Label(header, text="🧪 LABORATÓRIO DE BACKTEST", bg=self.bg, fg=self.cyan,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w")
        tk.Label(header, text="MÁQUINA DO TEMPO - SIMULAÇÃO HISTÓRICA", bg=self.bg, fg=self.muted,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", pady=(2, 0))

        # Card de Configuração
        config_card = tk.Frame(main_frame, bg=self.panel, highlightbackground=self.border, highlightthickness=1)
        config_card.pack(fill="x", pady=(0, 10))

        config_body = tk.Frame(config_card, bg=self.panel)
        config_body.pack(fill="x", padx=12, pady=(10, 10))

        # Gatilho
        tk.Label(config_body, text="GATILHO", bg=self.panel, fg=self.muted,
                 font=("Segoe UI", 8, "bold")).grid(row=0, column=0, sticky="w", padx=(0, 8), pady=4)
        self.ent_gatilho = tk.Entry(config_body, bg=self.panel2, fg=self.text, insertbackground=self.cyan,
                                   relief="flat", bd=0, highlightthickness=1, highlightbackground=self.border,
                                   highlightcolor=self.cyan, font=("Segoe UI", 9, "bold"))
        self.ent_gatilho.insert(0, "D3")
        self.ent_gatilho.grid(row=0, column=1, sticky="ew", padx=(0, 12), pady=4)

        # Alvos
        tk.Label(config_body, text="ALVOS", bg=self.panel, fg=self.muted,
                 font=("Segoe UI", 8, "bold")).grid(row=0, column=2, sticky="w", padx=(0, 8), pady=4)
        self.ent_alvos = tk.Entry(config_body, bg=self.panel2, fg=self.amber, insertbackground=self.amber,
                                  relief="flat", bd=0, highlightthickness=1, highlightbackground=self.border,
                                  highlightcolor=self.amber, font=("Segoe UI", 9, "bold"))
        self.ent_alvos.insert(0, "T1 T2 T3")
        self.ent_alvos.grid(row=0, column=3, sticky="ew", pady=4)

        # Gales Máximos
        tk.Label(config_body, text="GALES MÁX", bg=self.panel, fg=self.muted,
                 font=("Segoe UI", 8, "bold")).grid(row=1, column=0, sticky="w", padx=(0, 8), pady=4)
        self.ent_gales = tk.Entry(config_body, bg=self.panel2, fg=self.text, insertbackground=self.cyan,
                                  relief="flat", bd=0, highlightthickness=1, highlightbackground=self.border,
                                  highlightcolor=self.cyan, font=("Segoe UI", 9, "bold"), width=8)
        self.ent_gales.insert(0, "2")
        self.ent_gales.grid(row=1, column=1, sticky="w", padx=(0, 12), pady=4)

        # Amostra
        tk.Label(config_body, text="AMOSTRA", bg=self.panel, fg=self.muted,
                 font=("Segoe UI", 8, "bold")).grid(row=1, column=2, sticky="w", padx=(0, 8), pady=4)
        self.ent_amostra = tk.Entry(config_body, bg=self.panel2, fg=self.text, insertbackground=self.cyan,
                                    relief="flat", bd=0, highlightthickness=1, highlightbackground=self.border,
                                    highlightcolor=self.cyan, font=("Segoe UI", 9, "bold"), width=8)
        self.ent_amostra.insert(0, "500")
        self.ent_amostra.grid(row=1, column=2, columnspan=2, sticky="w", pady=4)

        config_body.columnconfigure(1, weight=1)
        config_body.columnconfigure(3, weight=1)

        # Botão de Simulação
        btn_frame = tk.Frame(main_frame, bg=self.bg)
        btn_frame.pack(fill="x", pady=(0, 10))
        self.btn_simular = tk.Button(btn_frame, text="▶ RODAR SIMULAÇÃO", command=self.rodar_simulacao,
                                      bg=self.green, fg="#061018", activebackground="#6EE7B7",
                                      activeforeground="#061018", relief="flat", bd=0, cursor="hand2",
                                      font=("Segoe UI", 9, "bold"), padx=20, pady=8)
        self.btn_simular.pack(fill="x")

        # Card de Resultados
        results_card = tk.Frame(main_frame, bg=self.panel, highlightbackground=self.border, highlightthickness=1)
        results_card.pack(fill="both", expand=True)

        results_header = tk.Frame(results_card, bg=self.panel)
        results_header.pack(fill="x", padx=12, pady=(10, 5))
        tk.Label(results_header, text="📊 RELATÓRIO DE RESULTADOS", bg=self.panel, fg=self.cyan,
                 font=("Segoe UI", 9, "bold")).pack(side="left")

        results_body = tk.Frame(results_card, bg=self.panel)
        results_body.pack(fill="both", expand=True, padx=12, pady=(0, 10))

        # Labels de resultado
        self.lbl_status = tk.Label(results_body, text="Configure os parâmetros e clique em RODAR SIMULAÇÃO",
                                   bg=self.panel, fg=self.muted, font=("Segoe UI", 9), justify="left")
        self.lbl_status.pack(anchor="w", pady=(0, 8))

        # Grid de métricas
        metrics_grid = tk.Frame(results_body, bg=self.panel)
        metrics_grid.pack(fill="x")

        def metric_box(parent, row, col, title, attr, color):
            box = tk.Frame(parent, bg=self.panel2, highlightbackground=self.border, highlightthickness=1)
            box.grid(row=row, column=col, sticky="nsew", padx=4, pady=4)
            tk.Label(box, text=title, bg=self.panel2, fg=self.muted,
                     font=("Segoe UI", 7, "bold")).pack(anchor="w", padx=8, pady=(4, 2))
            lbl = tk.Label(box, text="--", bg=self.panel2, fg=color,
                           font=("Segoe UI", 11, "bold"), justify="left", anchor="w")
            lbl.pack(fill="both", expand=True, padx=8, pady=(0, 4))
            setattr(self, attr, lbl)

        metric_box(metrics_grid, 0, 0, "TOTAL ENTRADAS", "lbl_total_entradas", self.text)
        metric_box(metrics_grid, 0, 1, "GREENS", "lbl_greens", self.green)
        metric_box(metrics_grid, 0, 2, "REDS", "lbl_reds", self.red)
        metric_box(metrics_grid, 1, 0, "ASSERTIVIDADE", "lbl_assertividade", self.cyan)
        metric_box(metrics_grid, 1, 1, "MAX DRAWDOWN", "lbl_drawdown", self.amber)
        metric_box(metrics_grid, 1, 2, "STATUS", "lbl_status_final", self.text)

        for c in range(3):
            metrics_grid.columnconfigure(c, weight=1)

        # Botão de Aplicação
        self.btn_aplicar = tk.Button(results_body, text="➕ APLICAR AO ROBÔ AO VIVO",
                                     command=self.aplicar_estrategia,
                                     bg=self.purple, fg="#130E21", activebackground="#C4B5FD",
                                     activeforeground="#130E21", relief="flat", bd=0, cursor="hand2",
                                     font=("Segoe UI", 9, "bold"), padx=15, pady=6, state="disabled")
        self.btn_aplicar.pack(fill="x", pady=(10, 0))

        # Resultado do backtest para armazenar
        self.resultado_backtest = None

    def fechar(self):
        self.top.destroy()

    def obter_historico_para_backtest(self, amostra_necessaria):
        """Obtém histórico do CSV ou da memória do bot"""
        # Primeiro tenta usar histórico atual do bot se disponível
        if hasattr(self.app, 'radar') and self.app.radar:
            try:
                mesa_info = getattr(self.app.radar, 'mesa_info_temp', None)
                if mesa_info and 'historico_numeros_brutos' in mesa_info:
                    historico_atual = mesa_info['historico_numeros_brutos']
                    if len(historico_atual) >= amostra_necessaria:
                        return historico_atual[-amostra_necessaria:]
            except Exception:
                pass

        # Se não tiver histórico suficiente, tenta ler do CSV
        csv_file = "banco_dados_roleta.csv"
        if os.path.exists(csv_file):
            try:
                numeros_csv = []
                with open(csv_file, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                    # Pula cabeçalho se existir
                    start_line = 1 if lines and "DataHora" in lines[0] else 0
                    
                    for line in lines[start_line:]:
                        parts = line.strip().split(',')
                        if len(parts) >= 3:
                            try:
                                num = int(parts[2])  # Terceira coluna é o número
                                if 0 <= num <= 36:
                                    numeros_csv.append(num)
                            except ValueError:
                                continue
                
                if len(numeros_csv) >= amostra_necessaria:
                    return numeros_csv[-amostra_necessaria:]
                else:
                    return numeros_csv  # Retorna o que tiver
                    
            except Exception as e:
                logging.error(f"Erro ao ler CSV para backtest: {e}")
        
        return []

    def rodar_simulacao(self):
        """Executa a simulação de backtest em thread separada"""
        # Desabilitar botão durante simulação
        self.btn_simular.config(state="disabled", text="⏳ PROCESSANDO...")
        self.lbl_status.config(text="Carregando dados históricos...", fg=self.amber)

        # Iniciar thread para não travar interface
        threading.Thread(target=self._executar_backtest_thread, daemon=True).start()

    def _executar_backtest_thread(self):
        """Thread de execução do backtest"""
        try:
            # Obter parâmetros
            gatilho_raw = self.ent_gatilho.get().strip().upper()
            alvos_raw = self.ent_alvos.get().strip().upper()
            
            try:
                max_gales = int(self.ent_gales.get().strip())
            except ValueError:
                max_gales = 2
                
            try:
                amostra = int(self.ent_amostra.get().strip())
            except ValueError:
                amostra = 500

            # Processar gatilho
            gatilho_list = gatilho_raw.replace(",", " ").split()
            
            # Processar alvos
            alvos_list = alvos_raw.replace(",", " ").split()
            alvos_expandidos = []
            for alvo in alvos_list:
                if alvo in SETORES_FISICOS:
                    alvos_expandidos.extend([str(n) for n in SETORES_FISICOS[alvo]])
                elif alvo in TERMINAIS_MAP:
                    alvos_expandidos.extend(TERMINAIS_MAP[alvo])
                else:
                    alvos_expandidos.append(alvo)

            # Obter histórico
            self.top.after(0, lambda: self.lbl_status.config(text="Carregando dados históricos...", fg=self.amber))
            historico = self.obter_historico_para_backtest(amostra)
            
            if not historico:
                self.top.after(0, lambda: self._mostrar_erro("Nenhum dado histórico encontrado."))
                return

            self.top.after(0, lambda: self.lbl_status.config(text=f"Processando {len(historico)} rodadas...", fg=self.cyan))

            # Executar backtest
            resultado = self._simular_estrategia(historico, gatilho_list, alvos_expandidos, max_gales)
            
            # Atualizar interface com resultados
            self.top.after(0, lambda: self._atualizar_resultados(resultado))
            
        except Exception as e:
            mensagem_erro = str(e)
            logging.error(f"Erro no backtest: {mensagem_erro}")
            self.top.after(0, lambda msg=mensagem_erro: self._mostrar_erro(f"Erro: {msg}"))

    def _simular_estrategia(self, historico, gatilho_list, alvos_expandidos, max_gales):
        """Simula a estratégia sobre o histórico"""
        greens = 0
        reds = 0
        total_entradas = 0
        max_drawdown = 0
        drawdown_atual = 0
        
        # Converter histórico para tags
        historico_tags = [classificar_numero(num) for num in historico]
        
        tamanho_gatilho = len(gatilho_list)
        i = tamanho_gatilho
        
        while i < len(historico_tags):
            # Verificar gatilho
            match = True
            if i >= tamanho_gatilho:
                sub_hist = historico_tags[i - tamanho_gatilho : i]
                for idx, g_item in enumerate(gatilho_list):
                    if g_item not in sub_hist[idx]:
                        match = False
                        break
            else:
                match = False
            
            if match:
                total_entradas += 1
                
                # Simular gales
                acertou_no_ciclo = False
                gale_usado = 0
                
                for g in range(max_gales + 1):
                    if i + g < len(historico_tags):
                        num_seguinte = str(historico[i + g])
                        tags_seguinte = historico_tags[i + g]
                        
                        # Verificar se acertou
                        if num_seguinte in alvos_expandidos or any(alvo in tags_seguinte for alvo in alvos_expandidos):
                            acertou_no_ciclo = True
                            gale_usado = g
                            break
                    gale_usado = g
                
                if acertou_no_ciclo:
                    greens += 1
                    drawdown_atual = 0
                else:
                    reds += 1
                    drawdown_atual += 1
                    max_drawdown = max(max_drawdown, drawdown_atual)
                
                i += (gale_usado + 1)
            else:
                i += 1
        
        # Calcular assertividade
        total_operacoes = greens + reds
        assertividade = (greens / total_operacoes * 100) if total_operacoes > 0 else 0.0
        
        return {
            "total_entradas": total_entradas,
            "greens": greens,
            "reds": reds,
            "assertividade": assertividade,
            "max_drawdown": max_drawdown,
            "gatilho": gatilho_list,
            "alvos": alvos_expandidos,
            "max_gales": max_gales
        }

    def _atualizar_resultados(self, resultado):
        """Atualiza a interface com os resultados"""
        self.resultado_backtest = resultado
        
        self.lbl_total_entradas.config(text=str(resultado["total_entradas"]))
        self.lbl_greens.config(text=str(resultado["greens"]))
        self.lbl_reds.config(text=str(resultado["reds"]))
        self.lbl_assertividade.config(text=f"{resultado['assertividade']:.1f}%")
        self.lbl_drawdown.config(text=str(resultado["max_drawdown"]))
        
        # Status baseado na assertividade
        if resultado["assertividade"] >= 70:
            status_text = "✅ ESTRATÉGIA VÁLIDA"
            status_color = self.green
            self.btn_aplicar.config(state="normal")
        elif resultado["assertividade"] >= 50:
            status_text = "⚠️ MODERADA"
            status_color = self.amber
            self.btn_aplicar.config(state="normal")
        else:
            status_text = "❌ BAIXA ASSERTIVIDADE"
            status_color = self.red
            self.btn_aplicar.config(state="disabled")
        
        self.lbl_status_final.config(text=status_text, fg=status_color)
        self.lbl_status.config(text=f"Backtest concluído! {resultado['total_entradas']} entradas analisadas.", fg=self.green)
        
        # Reabilitar botão
        self.btn_simular.config(state="normal", text="▶ RODAR SIMULAÇÃO")

    def _mostrar_erro(self, mensagem):
        """Mostra mensagem de erro"""
        self.lbl_status.config(text=mensagem, fg=self.red)
        self.btn_simular.config(state="normal", text="▶ RODAR SIMULAÇÃO")

    def aplicar_estrategia(self):
        """Aplica a estratégia testada ao robô principal"""
        if not self.resultado_backtest:
            return
        
        try:
            # Criar estratégia no formato do bot
            nova_est = {
                "gatilho_str": " ".join(self.resultado_backtest["gatilho"]),
                "gatilho": self.resultado_backtest["gatilho"],
                "ausencia": False,
                "aposta_str": " ".join(self.resultado_backtest["alvos"]),
                "alvos": self.resultado_backtest["alvos"],
                "max_gales": self.resultado_backtest["max_gales"],
                "mults_gales": ["2x", "4x", "8x", "16x", "32x", "64x"][:self.resultado_backtest["max_gales"]],
                "greens": 0,
                "reds": 0
            }
            
            # Adicionar às estratégias do app principal
            self.app.estrategias.append(nova_est)
            self.app.salvar_config()
            self.app.atualizar_listbox_estrategias()
            
            # Feedback visual
            self.lbl_status.config(text="✅ Estratégia aplicada ao robô principal!", fg=self.green)
            self.btn_aplicar.config(state="disabled")
            
            # Mostrar mensagem
            messagebox.showinfo("Sucesso", "Estratégia aplicada com sucesso ao robô principal!")
            
        except Exception as e:
            logging.error(f"Erro ao aplicar estratégia: {e}")
            messagebox.showerror("Erro", f"Erro ao aplicar estratégia: {str(e)}")

class GestaoBancaDashboard:
    def __init__(self, master, app_ref):
        self.app = app_ref
        self.top = tk.Toplevel(master)
        self.top.title("📈 GESTÃO DE BANCA MENSAL")
        self.top.geometry("900x750")
        self.top.configure(bg="#070A10")
        self.top.focus_force()

        self.bg = "#070A10"
        self.card_bg = "#0D111B"
        self.border = "#1E293B"
        self.text = "#FFFFFF"
        self.muted = "#718096"
        self.green = "#00FF88"
        self.red = "#FF1744"
        self.orange = "#F59E0B"
        
        self.canvas = tk.Canvas(self.top, bg=self.bg, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self.top, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg=self.bg)
        
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw", width=880)
        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        def _scroll_mouse(event):
            if event.widget.winfo_toplevel() == self.top:
                self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        self.top.bind_all("<MouseWheel>", _scroll_mouse, add="+")

        # --- HEADER ---
        header = tk.Frame(self.scrollable_frame, bg=self.bg)
        header.pack(fill="x", padx=20, pady=20)
        
        mes_atual = datetime.now().strftime("%b/%Y").upper()
        tk.Label(header, text=f"RÉGIS CUNHA • {mes_atual}", bg=self.bg, fg=self.text, font=("Segoe UI", 16, "bold")).pack(side="left")
        
        btn_zerar = tk.Button(header, text="🔄 ZERAR DIA", command=self.zerar_lucro_dia,
                              bg=self.red, fg="#FFFFFF", activebackground="#7F1D1D", activeforeground="#FFFFFF",
                              relief="flat", bd=0, font=("Segoe UI", 9, "bold"), cursor="hand2", padx=12, pady=4)
        btn_zerar.pack(side="right")
        
        # --- CARDS PRINCIPAIS ---
        cards_frame = tk.Frame(self.scrollable_frame, bg=self.bg)
        cards_frame.pack(fill="x", padx=20)
        for i in range(4): cards_frame.columnconfigure(i, weight=1)

        self.lbl_banca_inicial = self._criar_card(cards_frame, 0, "BANCA INICIAL", "R$ 0.00", self.text)
        self.lbl_banca_atual = self._criar_card(cards_frame, 1, "BANCA ATUAL", "R$ 0.00", self.text)
        self.lbl_pl = self._criar_card(cards_frame, 2, "P&L DO DIA", "R$ 0.00", self.text)
        self.lbl_variacao = self._criar_card(cards_frame, 3, "VARIAÇÃO", "0.00%", self.text)

        # --- CARDS WINS / LOSS ---
        wl_frame = tk.Frame(self.scrollable_frame, bg=self.bg)
        wl_frame.pack(fill="x", padx=20, pady=10)
        for i in range(3): wl_frame.columnconfigure(i, weight=1)

        self.lbl_wins = self._criar_card(wl_frame, 0, "WINS SESSÃO", "0", self.green, bg_color="#0A2218", border_color=self.green)
        self.lbl_loss = self._criar_card(wl_frame, 1, "LOSS SESSÃO", "0", self.red, bg_color="#2A0A10", border_color=self.red)
        self.lbl_winrate = self._criar_card(wl_frame, 2, "WIN RATE", "0.0%", self.text)

        # --- GRÁFICO DE EVOLUÇÃO ---
        graf_frame = tk.Frame(self.scrollable_frame, bg=self.card_bg, highlightbackground=self.border, highlightthickness=1)
        graf_frame.pack(fill="x", padx=20, pady=10, ipadx=10, ipady=10)
        tk.Label(graf_frame, text="EVOLUÇÃO MENSAL DA BANCA", bg=self.card_bg, fg=self.muted, font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 10))
        
        self.canvas_graf = tk.Canvas(graf_frame, height=150, bg=self.card_bg, highlightthickness=0)
        self.canvas_graf.pack(fill="x")

        # --- GRADE DOS 31 DIAS E MEMÓRIA ---
        grid_frame = tk.Frame(self.scrollable_frame, bg=self.bg)
        grid_frame.pack(fill="x", padx=20, pady=10)
        tk.Label(grid_frame, text="RESULTADO POR DIA", bg=self.bg, fg=self.muted, font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 10))

        dias_frame = tk.Frame(grid_frame, bg=self.bg)
        dias_frame.pack(fill="x")
        for i in range(6): dias_frame.columnconfigure(i, weight=1)

        historico_mes = self._carregar_historico_mes()
        self.dia_hoje = datetime.now().day
        
        # 🛡️ TRAVA DE MEMÓRIA ANTI-DUPLICAÇÃO (Corrigida)
        self.lucro_base_banco = historico_mes.get(self.dia_hoje, 0.0) 
        self.lucro_inicial_sessao = self.app.lucro_virtual
        self.ultimo_lucro_salvo = None
        
        for i in range(1, 32):
            row = (i - 1) // 6
            col = (i - 1) % 6
            box = tk.Frame(dias_frame, bg=self.card_bg, highlightbackground=self.border, highlightthickness=1)
            box.grid(row=row, column=col, sticky="nsew", padx=4, pady=4, ipadx=5, ipady=5)
            
            tk.Label(box, text=f"DIA {i}", bg=self.card_bg, fg=self.muted, font=("Segoe UI", 7, "bold")).pack(anchor="w")
            
            if i in historico_mes and i != self.dia_hoje:
                lucro_passado = historico_mes[i]
                cor_val = self.green if lucro_passado >= 0 else self.red
                txt_val = f"{lucro_passado:.0f}"
            else:
                cor_val = self.muted
                txt_val = "-"
                
            lbl_dia = tk.Label(box, text=txt_val, bg=self.card_bg, fg=cor_val, font=("Segoe UI", 10, "bold"))
            lbl_dia.pack(anchor="w", pady=(5,0))
            
            if i == self.dia_hoje:
                self.lbl_dia_hoje = lbl_dia

        self._desenhar_grafico_laranja()
        self.atualizar_dados_ao_vivo()

    def _criar_card(self, parent, col, titulo, valor, cor_valor, bg_color=None, border_color=None):
        bg = bg_color or self.card_bg
        bd = border_color or self.border
        card = tk.Frame(parent, bg=bg, highlightbackground=bd, highlightthickness=1)
        card.grid(row=0, column=col, sticky="nsew", padx=4, pady=4, ipadx=10, ipady=10)
        tk.Label(card, text=titulo, bg=bg, fg=self.muted, font=("Segoe UI", 8, "bold")).pack(anchor="w")
        
        lbl_valor = tk.Label(card, text=valor, bg=bg, fg=cor_valor, font=("Segoe UI", 14, "bold"))
        lbl_valor.pack(anchor="w", pady=(5,0))
        return lbl_valor

    def _carregar_historico_mes(self):
        mes_ano_atual = date.today().strftime("%m/%Y")
        try:
            conn = sqlite3.connect('gestao_banca.db')
            cursor = conn.cursor()
            cursor.execute('SELECT data_registro, lucro FROM historico_diario WHERE mes_ano = ?', (mes_ano_atual,))
            resultados = cursor.fetchall()
            conn.close()
            
            historico = {}
            for linha in resultados:
                data_str, lucro = linha
                dia = int(data_str.split('-')[2])
                historico[dia] = lucro
            return historico
        except Exception:
            return {}

    def _salvar_no_banco(self, lucro):
        hoje = date.today().strftime("%Y-%m-%d")
        mes_ano = date.today().strftime("%m/%Y")
        
        try:
            conn = sqlite3.connect('gestao_banca.db')
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO historico_diario (data_registro, mes_ano, lucro)
                VALUES (?, ?, ?)
                ON CONFLICT(data_registro) DO UPDATE SET lucro=excluded.lucro
            ''', (hoje, mes_ano, lucro))
            conn.commit()
            conn.close()
        except Exception as e:
            pass

    def atualizar_dados_ao_vivo(self):
        if not self.top.winfo_exists():
            return
            
        try:
            banca_inicial = float(self.app.ent_banca_inicial.get())
        except ValueError:
            banca_inicial = self.app.banca_virtual
            
        # 🛡️ CÁLCULO BLINDADO CONTRA LOOP (Subtrai o inicial cravado)
        lucro_adicional_sessao = self.app.lucro_virtual - self.lucro_inicial_sessao
        lucro_total_dia = self.lucro_base_banco + lucro_adicional_sessao
        
        banca_atual = banca_inicial + lucro_total_dia
        roi = (lucro_total_dia / banca_inicial) * 100 if banca_inicial > 0 else 0

        self.lbl_banca_inicial.config(text=f"R$ {banca_inicial:,.2f}")
        self.lbl_banca_atual.config(text=f"R$ {banca_atual:,.2f}")
        
        cor_pl = self.green if lucro_total_dia >= 0 else self.red
        sinal_pl = "+" if lucro_total_dia >= 0 else ""
        self.lbl_pl.config(text=f"{sinal_pl}R$ {lucro_total_dia:,.2f}", fg=cor_pl)
        
        cor_roi = self.green if roi >= 0 else self.red
        sinal_roi = "+" if roi >= 0 else ""
        self.lbl_variacao.config(text=f"{sinal_roi}{roi:.2f}%", fg=cor_roi)

        self.lbl_wins.config(text=str(self.app.greens))
        self.lbl_loss.config(text=str(self.app.reds))
        
        total_entradas = self.app.greens + self.app.reds
        win_rate = (self.app.greens / total_entradas * 100) if total_entradas > 0 else 0
        self.lbl_winrate.config(text=f"{win_rate:.1f}%")

        if hasattr(self, 'lbl_dia_hoje'):
            self.lbl_dia_hoje.config(text=f"{lucro_total_dia:.0f}", fg=cor_pl)

        # Salva no banco de dados sem duplicar
        if lucro_total_dia != getattr(self, 'ultimo_lucro_salvo', None):
            self._salvar_no_banco(lucro_total_dia)
            self.ultimo_lucro_salvo = lucro_total_dia
            # Atualiza o gráfico se o saldo do dia mudar e salvar
            self._desenhar_grafico_laranja()

        self.top.after(1000, self.atualizar_dados_ao_vivo)

    def zerar_lucro_dia(self):
        if messagebox.askyesno("Zerar Dia", "Tem certeza que deseja zerar o lucro e o placar de hoje?\nIsso não pode ser desfeito."):
            with self.app.placar_lock:
                self.app.greens = 0
                self.app.reds = 0
                self.app.reds_consecutivos = 0
                self.app.lucro_virtual = 0.0
                self.app.historico_lucro_chart = [0.0]
                
            # Zera a contabilidade interna atualizada
            self.lucro_base_banco = 0.0
            self.lucro_inicial_sessao = 0.0
            self.ultimo_lucro_salvo = 0.0
            
            hoje = date.today().strftime("%Y-%m-%d")
            try:
                conn = sqlite3.connect('gestao_banca.db')
                cursor = conn.cursor()
                cursor.execute('UPDATE historico_diario SET lucro = 0.0 WHERE data_registro = ?', (hoje,))
                conn.commit()
                conn.close()
            except Exception:
                pass
                
            self.app.atualizar_placar()
            self._desenhar_grafico_laranja()
            messagebox.showinfo("Sucesso", "A sua mesa foi limpa! Lucro e placar zerados para recomeçar.")

    def _desenhar_grafico_laranja(self):
        self.canvas_graf.delete("all")
        historico = self._carregar_historico_mes()
        
        # Força o valor de hoje no gráfico com o que está em tela agora
        lucro_adicional_sessao = self.app.lucro_virtual - getattr(self, 'lucro_inicial_sessao', 0.0)
        historico[self.dia_hoje] = getattr(self, 'lucro_base_banco', 0.0) + lucro_adicional_sessao

        dias = sorted(historico.keys())
        if not dias: return

        # Acumula o lucro mês a mês
        acumulado = 0
        pontos_y = []
        for d in range(1, self.dia_hoje + 1):
            acumulado += historico.get(d, 0)
            pontos_y.append(acumulado)

        if len(pontos_y) < 2: return # O gráfico precisa de no mínimo 2 dias pra ter uma linha legal
        
        canvas_width = 840
        canvas_height = 130
        pad_x = 10
        
        min_y = min(pontos_y + [0])
        max_y = max(pontos_y + [1]) 
        range_y = max_y - min_y if max_y != min_y else 1
        
        step_x = (canvas_width - 2 * pad_x) / (len(pontos_y) - 1)
        pontos = []
        
        for i, val in enumerate(pontos_y):
            px = pad_x + i * step_x
            py = canvas_height - ((val - min_y) / range_y) * (canvas_height - 20)
            pontos.append((px, py))
            
        poly_pontos = [(pontos[0][0], canvas_height + 20)] + pontos + [(pontos[-1][0], canvas_height + 20)]
        self.canvas_graf.create_polygon(poly_pontos, fill="#78350f", outline="")
        self.canvas_graf.create_line(pontos, fill=self.orange, width=3, smooth=True)
        
        # Bolinha brilhante no último dia operado
        ux, uy = pontos[-1]
        self.canvas_graf.create_oval(ux-4, uy-4, ux+4, uy+4, fill=self.orange, outline="#FFFFFF", width=1)

if __name__ == "__main__":
    root = tk.Tk()
    app = BotApp(root)
    root.mainloop()