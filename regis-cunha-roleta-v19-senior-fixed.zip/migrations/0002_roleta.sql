create table if not exists mesas (
  id text primary key,
  label text not null,
  provider text not null,
  provider_label text not null
);

insert into mesas (id, label, provider, provider_label) values
  ('auto-roulette', 'Auto Roulette', 'evolution', 'Evolution'),
  ('immersive-roulette', 'Immersive Roulette', 'evolution', 'Evolution'),
  ('mega-fire-blaze', 'Mega Fire Blaze', 'playtech', 'Playtech'),
  ('mega-roulette', 'Mega Roulette', 'pragmatic', 'Pragmatic')
on conflict (id) do nothing;

create table if not exists sessoes (
  id text primary key,
  mesa_id text not null,
  provedor text not null,
  status text not null,
  started_at timestamptz not null default now(),
  stopped_at timestamptz
);

create index if not exists sessoes_mesa_idx on sessoes (mesa_id, started_at desc);

create table if not exists giros (
  id text primary key,
  source_event_id text not null,
  mesa_id text not null,
  sessao_id text,
  provedor text not null,
  numero integer not null,
  cor text not null,
  paridade text not null,
  duzia integer not null,
  coluna integer not null,
  terminal integer not null,
  faixa text not null,
  horario timestamptz not null,
  multiplicador text,
  ganhadores integer,
  lucky_json text,
  created_at timestamptz not null default now()
);

create unique index if not exists giros_mesa_event_idx on giros (mesa_id, source_event_id);
create index if not exists giros_mesa_horario_idx on giros (mesa_id, horario desc);

create table if not exists sinais_log (
  id text primary key,
  mesa_id text not null,
  sessao_id text,
  tipo text not null,
  titulo text not null,
  alvos_json text not null,
  score text not null,
  filtros_json text not null,
  status text not null,
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  resolved_number integer
);
