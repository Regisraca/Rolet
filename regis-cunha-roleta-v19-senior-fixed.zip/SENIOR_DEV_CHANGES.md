# RÉGIS CUNHA ROLETA v19 — consolidação técnica

Esta versão consolida a lógica V19 baseada no `attachments/newfile.py` e corrige o fluxo do motor web.

## Principais correções

- `src/lib/v19` é a fonte canônica das estratégias V19.
- O motor de estratégias adapta Sniper, Termo e Quant V19 ao contrato comum.
- O fluxo ao vivo passa a avaliar as estratégias antes de decidir pelo sinal.
- O consenso central não conta `MODELO` como voto independente.
- `passesQuality()` deixou de ser stub e valida histórico, score, consenso e candidatos.
- Padrões Quant aplicados pelo usuário continuam operacionais e entram no motor Quant sem virar votos duplicados.
- Estado de sinal, confirmação, cooldown e candidato é persistido pelo Zustand.
- Gestão de banca virtual foi exposta na Visão e nos Ajustes.
- Stop Win, Stop Loss, máximo de reds e multiplicadores G1–G6 foram incorporados ao estado/configuração.
- G0–G6 deixaram de ser truncados no tipo de sinal.
- A auditoria de paridade Python deixou de depender do caminho fixo `/workspace`.
- O teste de paridade Python/TS foi validado localmente.
- O `npm test` agora inclui explicitamente os testes V19 do motor.

## Validação local sem instalação de dependências

Passaram 29 testes de núcleo:

- 12 testes de paridade V19 contra o Python de referência.
- 11 testes do ciclo de sinais, incluindo confirmação, cooldown, GREEN/RED e até 6 gales.
- 6 testes das estratégias independentes/consenso.

Os testes gerais `scripts/*.test.mjs` do workspace original tiveram falhas externas ao motor da roleta (principalmente checks de infraestrutura/artefatos do template). Elas não foram usadas como justificativa para declarar o app 100% pronto.

## Próximo passo obrigatório

Instalar dependências no ambiente do Replit e executar `npm test`, `npm run typecheck` e `npm run build`. Depois abrir o preview no celular e validar manualmente conexão, histórico, painel, Quant Lab, sinal, G0–G6, GREEN/RED e persistência após recarregar.
